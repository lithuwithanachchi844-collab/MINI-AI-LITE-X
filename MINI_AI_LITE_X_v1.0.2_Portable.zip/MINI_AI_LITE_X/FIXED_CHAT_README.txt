MINI AI LITE X v1.0.2 — CHAT FIX
================================

WHAT IS FIXED
- “How are you?” now receives a conversational answer instead of an unrelated saved lesson.
- Small-talk is handled before lesson retrieval, preventing common words such as “you” from selecting an irrelevant lesson.
- Chat no longer stops just because the optional local language model has not loaded. It uses the built-in offline helper instead.
- Default mode is “Automatic (local first)”: it uses the local model when loaded and falls back to built-in offline chat when it is not.
- No message is sent online by the built-in offline fallback.

INSTALL
1. Download this ZIP.
2. Right-click it and select Extract All.
3. Open the extracted MINI_AI_LITE_X folder.
4. Double-click Start_MINI_AI_LITE_X.bat.
5. Try “hello”, “how are you?”, “what can you do?”, or “calculate 12 * 8”.

HONEST LIMITATION
The built-in offline helper is not a full neural language model and cannot answer every open-ended question. For stronger generated answers, internet is needed once to install a compatible local runtime and download the small model from the AI Model tab. The app will still fall back to built-in chat if that setup fails. On older 4 GB laptops, model compatibility and speed are not guaranteed.

Your saved lessons and chats remain in %USERPROFILE%\MINI_AI_LITE_X_Data. This ZIP does not delete that folder.
