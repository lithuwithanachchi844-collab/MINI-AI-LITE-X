@echo off
setlocal
cd /d "%~dp0"
echo MINI AI LITE X v1.0.2
echo Starting from: %CD%
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 mini_ai_lite_x.py
) else (
  python mini_ai_lite_x.py
)
if errorlevel 1 (
  echo.
  echo MINI AI LITE X could not start. Make sure you extracted the ZIP first.
  echo Do not run the launcher from inside the ZIP preview.
  echo If Python or Tkinter is missing, install Python 3.11 or 3.12 from https://www.python.org/downloads/
  pause
)
endlocal
