MINI AI LITE X v1.0.2 — Portable Windows app
==========================================

A local-first desktop companion with chat, saved lessons, notes, tasks, simple tools, webpage reading and optional local language-model support.

QUICK START
1. Right-click this ZIP and choose Extract All. Do not launch from the ZIP preview.
2. Open the extracted MINI_AI_LITE_X folder.
3. Double-click Start_MINI_AI_LITE_X.bat.
4. The app starts in Automatic (local first) mode. If no model is loaded, the built-in offline chat answers common conversation and basic requests rather than stopping.

CHAT FIX IN THIS VERSION
- Fixed the “how are you?” saved-lesson mix-up.
- Built-in chat is used when the optional local model is unavailable.
- The app does not send offline-fallback messages online.

REAL LOCAL LANGUAGE MODEL
A full generative local model is optional and is not bundled. In the AI Model tab, install the runtime, download the approximately 400–500 MB model, then load it. This first setup requires internet. After a successful load, local inference can run offline. Compatibility on older Windows 10 systems and 4 GB RAM is not guaranteed.

STORAGE
Chats, notes and saved knowledge are stored in %USERPROFILE%\MINI_AI_LITE_X_Data. The app does not pre-fill or reserve 200 GB.

See MANUAL.txt and FIXED_CHAT_README.txt for more details.
