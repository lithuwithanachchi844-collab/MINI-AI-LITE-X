@echo off
call "%~dp0Start_MINI_AI.bat"
