"""Offline package checks for MINI AI. Does not modify the user's app database."""
import ast, base64, importlib.util, os, sqlite3, sys, tempfile, zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
checks = []
def check(label, fn):
    try:
        detail = fn()
        checks.append((label, True, str(detail or 'OK')))
    except Exception as exc:
        checks.append((label, False, f'{type(exc).__name__}: {exc}'))

def syntax_check(path):
    ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    return 'valid Python syntax'

def tkinter_check():
    import tkinter
    return f'Tkinter import OK ({tkinter.TkVersion})'

def compression_check():
    original = ('MINI AI saved conversation test. ' * 500).encode('utf-8')
    packed = zlib.compress(original, 9)
    assert zlib.decompress(packed) == original
    return f'lossless round-trip; sample {len(original)} -> {len(packed)} bytes'

def feature_patch_check():
    source = (ROOT / 'mini_ai_lite_x.py').read_text(encoding='utf-8')
    required = ['yolov4-tiny.weights', 'What can I make?', 'Teach boxed object', 'auto_topic_learning', 'auto_topic_interval_minutes', 'Chatbot · Chat only', "self.mode == 'Chatbot'", 'Settings.TLabel', "compresslevel=9"]
    missing = [item for item in required if item not in source]
    assert not missing, 'missing features: ' + ', '.join(missing)
    return 'object detector, teachable labels, five-minute AutoLearn schedule, chat-only mode, high-contrast settings and compact chat archive present'

def archive_layout_check():
    import zipfile
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / 'saved_chats.zip'
        with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            zf.writestr('saved_chats.jsonl', ('test chat\n' * 1000).encode('utf-8'))
        with zipfile.ZipFile(path, 'r') as zf:
            assert zf.namelist() == ['saved_chats.jsonl']
            assert zf.read('saved_chats.jsonl') == ('test chat\n' * 1000).encode('utf-8')
    return 'single history stream round-trips without per-message duplicate entries'

def sqlite_check():
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / 'test.sqlite3'
        with sqlite3.connect(path) as con:
            con.execute('CREATE TABLE t (id INTEGER PRIMARY KEY, body TEXT)')
            con.execute('INSERT INTO t(body) VALUES(?)', ('saved chat test',))
            got = con.execute('SELECT body FROM t').fetchone()[0]
            assert got == 'saved chat test'
    return 'temporary database write/read OK'

print('MINI AI — OFFLINE PACKAGE SELF-TEST')
print('Python:', sys.version.split()[0], '| OS:', sys.platform)
check('Main app syntax', lambda: syntax_check(ROOT / 'mini_ai_lite_x.py'))
check('Local language engine syntax', lambda: syntax_check(ROOT / 'mini_ai_llm.py'))
check('Tkinter availability', tkinter_check)
check('Chat compression round-trip', compression_check)
check('SQLite write/read', sqlite_check)
check('Requested feature presence', feature_patch_check)
check('Compact chat archive layout', archive_layout_check)
for name, ok, detail in checks:
    print(('PASS' if ok else 'FAIL') + ' - ' + name + ': ' + detail)
print('\nResult: {}/{} checks passed.'.format(sum(1 for _, ok, _ in checks if ok), len(checks)))
if any(not ok for _, ok, _ in checks):
    sys.exit(1)
