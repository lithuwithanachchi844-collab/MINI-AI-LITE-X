"""MINI AI's original from-scratch micro-language engine.

This is a lightweight word n-gram / retrieval learner, not a Transformer LLM.
It has no downloaded model weights, no external inference runtime, and uses only
Python's standard library. It learns from the app's local database and chat text.
"""
import os, re, json, sqlite3, math, random, time, urllib.request
from pathlib import Path
from collections import Counter, defaultdict

APP_DIR = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'MiniAILiteX_PersonalAI_Max'
DB_PATH = APP_DIR / 'personal_ai.sqlite3'
MODEL_PATH = APP_DIR / 'mini_ai_llm_model.json'
TOKEN_RE = re.compile(r"[A-Za-z0-9_']+|[^\w\s]", re.UNICODE)
STOP = set('the a an and or but if then than to of in on at for from by with is are was were be been being it this that these those i you we they he she them my your our their what why how when where who which can could would should do does did have has had not no yes as into about please tell explain make build help use using'.split())

class MiniAILLM:
    def __init__(self):
        self.transitions = defaultdict(Counter)
        self.unigrams = Counter()
        self.documents = []
        self.seen = set()
        self.turns = 0
        self._load_model()
        self.learn_app_database()

    def _load_model(self):
        try:
            d=json.loads(MODEL_PATH.read_text(encoding='utf-8'))
            self.unigrams.update(d.get('u', {}))
            for k,v in d.get('t', {}).items(): self.transitions[k].update(v)
            self.seen.update(d.get('seen', []))
            self.turns=int(d.get('turns',0))
        except Exception: pass

    def _save(self):
        try:
            # Bound model size for old 4 GB laptops.
            t={k:dict(c.most_common(32)) for k,c in list(self.transitions.items())[-12000:]}
            data={'u':dict(self.unigrams.most_common(12000)), 't':t, 'seen':list(self.seen)[-3000:], 'turns':self.turns}
            tmp=MODEL_PATH.with_suffix('.tmp'); tmp.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8'); tmp.replace(MODEL_PATH)
        except Exception: pass

    def _tokens(self,text): return [x.lower() for x in TOKEN_RE.findall(str(text)) if x.strip()]

    def learn_text(self,text,source='local'):
        text=str(text or '')[:200000].strip()
        if len(text)<35: return 0
        import hashlib
        digest=hashlib.sha256(text.encode('utf-8','ignore')).hexdigest()
        if digest in self.seen: return 0
        self.seen.add(digest)
        toks=self._tokens(text)
        if len(toks)<8: return 0
        prev=['<s>','<s>']
        for tok in toks+['</s>']:
            self.unigrams[tok]+=1
            key=' '.join(prev[-2:]); self.transitions[key][tok]+=1
            prev.append(tok)
        # Store bounded source text for relevance retrieval.
        self.documents.append((str(source)[:180],text[:12000]))
        if len(self.documents)>120: self.documents=self.documents[-120:]
        return len(toks)

    def learn_app_database(self):
        if not DB_PATH.exists(): return
        try:
            con=sqlite3.connect(str(DB_PATH),timeout=2)
            tables=[r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
            for table in tables:
                if not re.match(r'^[A-Za-z0-9_]+$',table): continue
                try:
                    cols=con.execute('PRAGMA table_info("'+table+'")').fetchall()
                    textcols=[c[1] for c in cols if any(x in c[2].upper() for x in ('TEXT','CHAR','CLOB'))]
                    if not textcols: continue
                    quoted=','.join('"'+c.replace('"','')+'"' for c in textcols[:8])
                    rows=con.execute('SELECT '+quoted+' FROM "'+table+'" ORDER BY rowid DESC LIMIT 150').fetchall()
                    for row in rows:
                        parts=[str(v) for v in row if isinstance(v,str) and len(v)>45]
                        if parts: self.learn_text('\n'.join(parts), 'app:'+table)
                except Exception: continue
            con.close()
            self._save()
        except Exception: pass

    def _retrieve(self,question):
        q=set(w for w in self._tokens(question) if w not in STOP and len(w)>2)
        if not q: return []
        scored=[]
        # Search all text-like columns in the app DB on demand, so AutoLearn research is consumed.
        try:
            con=sqlite3.connect(str(DB_PATH),timeout=2)
            tables=[r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
            for table in tables:
                if not re.match(r'^[A-Za-z0-9_]+$',table): continue
                try:
                    cols=con.execute('PRAGMA table_info("'+table+'")').fetchall()
                    textcols=[c[1] for c in cols if any(x in c[2].upper() for x in ('TEXT','CHAR','CLOB'))]
                    if not textcols: continue
                    quoted=','.join('"'+c.replace('"','')+'"' for c in textcols[:8])
                    for row in con.execute('SELECT '+quoted+' FROM "'+table+'" ORDER BY rowid DESC LIMIT 120').fetchall():
                        txt=' '.join(str(v) for v in row if isinstance(v,str) and len(v)>30)
                        if txt:
                            words=set(w for w in self._tokens(txt) if w not in STOP and len(w)>2)
                            overlap=len(q & words)
                            if overlap: scored.append((overlap/(len(q)**0.65),txt))
                except Exception: pass
            con.close()
        except Exception: pass
        for title,txt in self.documents:
            words=set(w for w in self._tokens(txt) if w not in STOP and len(w)>2); overlap=len(q&words)
            if overlap: scored.append((overlap/(len(q)**0.65),txt))
        scored.sort(key=lambda x:x[0],reverse=True)
        results=[]; seen=set()
        for score,txt in scored:
            if score<=0: continue
            for sent in re.split(r'(?<=[.!?])\s+|\n+',txt):
                sent=sent.strip()
                if len(sent)<35 or len(sent)>450: continue
                words=set(w for w in self._tokens(sent) if w not in STOP and len(w)>2)
                overlap=len(q&words)
                if overlap and sent.lower() not in seen:
                    seen.add(sent.lower()); results.append((overlap/(len(q)**0.65),sent))
            if len(results)>24: break
        results.sort(key=lambda x:x[0],reverse=True)
        return [s for _,s in results[:5]]

    def _generate_from_transitions(self,seed,limit=45):
        if not self.transitions: return ''
        words=self._tokens(seed)
        state=(words[-2:] if len(words)>=2 else ['<s>']*2)
        out=[]
        for _ in range(limit):
            key=' '.join(state[-2:]); choices=self.transitions.get(key)
            if not choices:
                keys=[k for k in self.transitions if any(w in k for w in state if w not in STOP)]
                if not keys: break
                key=random.choice(keys); choices=self.transitions[key]
            total=sum(choices.values()); pick=random.randrange(max(1,total)); token=''
            for word,count in choices.items():
                pick-=count
                if pick<0: token=word; break
            if not token or token=='</s>': break
            out.append(token); state.append(token)
        text=' '.join(out)
        text=re.sub(r'\s+([,.!?;:])',r'\1',text)
        return text[:700]

    def learn_peer_greeting(self):
        """Optionally ask an OpenAI-compatible AI endpoint a greeting and learn its reply.
        No external AI app can be contacted unless the user configures endpoint/key via environment variables.
        """
        endpoint=os.environ.get('MINI_AI_PEER_API_URL','').strip()
        key=os.environ.get('MINI_AI_PEER_API_KEY','').strip()
        model=os.environ.get('MINI_AI_PEER_MODEL','gpt-4o-mini').strip()
        if not endpoint or not key:
            return 'Peer AI not configured; using MINI AI’s own learned greeting pattern.'
        try:
            payload={'model':model,'messages':[{'role':'system','content':'Reply naturally to a friendly greeting in one or two sentences.'},{'role':'user','content':'Hello! How are you, and how could you help me today?'}],'temperature':0.4,'max_tokens':100}
            req=urllib.request.Request(endpoint, data=json.dumps(payload).encode('utf-8'), headers={'Content-Type':'application/json','Authorization':'Bearer '+key,'User-Agent':'MINI-AI-Social-Learner/1.0'}, method='POST')
            with urllib.request.urlopen(req, timeout=20) as response: data=json.loads(response.read(200000).decode('utf-8','replace'))
            reply=str(data['choices'][0]['message']['content']).strip()[:2000]
            if reply:
                own='Hello Lithu! '+re.sub(r'^(hi|hello|hey)[,! ]*','',reply,flags=re.I).strip()
                own=re.sub(r'\bI can help you\b','I can help you with your tasks and projects',own,flags=re.I)
                self.save_knowledge('Peer AI greeting example','peer-ai:'+model,'External AI response: '+reply+'\nMINI AI own-style greeting: '+own)
                self.learn_text('User says hello. MINI AI replies: '+own,'learned-conversation:peer-ai')
                self._save()
                return 'Learned a greeting example from the configured peer AI and saved MINI AI’s own-style version.'
            return 'Peer AI returned no text.'
        except Exception as e:
            return 'Peer AI exchange failed: '+str(e)[:220]

    def answer(self,question,mode='Chat'):
        q=str(question or '').strip()
        if not q: return 'Ask me something and I will try to help.'
        if re.fullmatch(r"(?:hi|hello|hey|hiya|good morning|good afternoon|good evening)[!. ,]*", q.lower()):
            greeting='Hello Lithu! How can I help you with your tasks and projects today?'
            self.learn_text('Conversation pattern: when the user says hello, MINI AI replies: '+greeting,'learned-conversation:greeting')
            self.turns+=1; self._save()
            return greeting
        if re.search(r"\bhow are you\b", q.lower()) and len(q)<100:
            greeting="I'm doing well and ready to help, Lithu! What would you like to work on today?"
            self.learn_text('Conversation pattern: when asked how are you, MINI AI replies: '+greeting,'learned-conversation:greeting')
            self.turns+=1; self._save()
            return greeting
        self.learn_app_database()
        low=q.lower()
        if re.search(r'\b(what is your name|who are you)\b',low):
            return 'I am MINI AI, running on my own small from-scratch language engine. I do not load another LLM or downloaded model weights. I learn patterns from saved local text and retrieve relevant saved knowledge.'
        if re.search(r'\b(are you conscious|are you alive|are you sentient)\b',low):
            return 'No. I am software, not conscious or alive. My language engine learns statistical word patterns from text and searches saved knowledge.'
        found=self._retrieve(q)
        if found:
            answer='Here is the most relevant information I have learned or saved locally:\n\n'+'\n'.join('• '+s for s in found[:4])
            if self.turns<8: answer+='\n\nI will keep learning from new material that MINI AI saves. My from-scratch language engine is small, so this is knowledge retrieval rather than the reasoning quality of a large Transformer LLM.'
        else:
            generated=self._generate_from_transitions(q)
            if generated and len(generated)>45:
                answer='I do not have a strong saved-knowledge match yet. My small language engine generated this from patterns learned in its local text:\n\n'+generated
            else:
                answer='I do not know enough about that yet. AutoLearn can collect public information when internet access is available, and I can use it after it is saved locally. You do not need to enter a webpage address.\n\nI am a small from-scratch language learner, not a modern Transformer LLM, so my answers are limited.'
        self.learn_text('User: '+q+'\nAssistant: '+answer,'chat')
        self.turns+=1; self._save()
        return answer

_ENGINE=None
def respond(prompt,mode='Chat'):
    global _ENGINE
    if _ENGINE is None: _ENGINE=MiniAILLM()
    return _ENGINE.answer(prompt,mode)
