@echo off
setlocal
cd /d "%~dp0"
title MINI AI - Camera Diagnostics
set "CAM_PY=%USERPROFILE%\MINI_AI_CAMERA\Scripts\python.exe"
if exist "%CAM_PY%" (
  "%CAM_PY%" Camera_Diagnostics.py
) else (
  where py >nul 2>nul
  if not errorlevel 1 (py -3 Camera_Diagnostics.py) else (python Camera_Diagnostics.py)
)
pause
