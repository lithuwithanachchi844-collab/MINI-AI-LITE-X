@echo off
setlocal
cd /d "%~dp0"
title MINI AI - Package Self Test
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 MINI_AI_SELF_TEST.py
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python 3 was not found. Install Python 3 with Tcl/Tk included.
    pause
    exit /b 1
  )
  python MINI_AI_SELF_TEST.py
)
echo.
pause
