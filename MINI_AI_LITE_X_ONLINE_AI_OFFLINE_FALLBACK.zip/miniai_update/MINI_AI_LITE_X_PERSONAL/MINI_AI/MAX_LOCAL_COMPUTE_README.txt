MINI AI LITE X — MAX LOCAL COMPUTE PROFILE

This profile sets the target design for using the laptop's available computing power locally.

CPU: Training may use all logical processors. This can make Windows and other applications slow. Close other applications and keep the laptop plugged into power with clear ventilation.
GPU: The NVIDIA Quadro NVS 160M has only 256 MB VRAM and a legacy architecture. It is not a practical accelerator for modern language-model training. The model should use CPU and system RAM; do not install CUDA or claim GPU acceleration without a verified compatible runtime.
RAM: The laptop has 4 GB RAM. Use small batches and small model sizes; using all CPU threads does not mean consuming all RAM.
STORAGE: 200 GB is the requested maximum budget for MINI AI's stored data, not an allocation/reservation. Actual available free space is the hard limit. Previous diagnostics indicated about 117.6 GB free, so 200 GB cannot currently be filled unless more disk space is freed or added. Windows and other apps must retain space too.
ONLINE: Web collection is optional and manual. The fetched text is stored locally. Internet is only needed while fetching pages; training and chat should work offline from saved data.
PRIVACY: No external LLM or cloud inference is used by this scratch prototype. Keep sensitive text out of training files unless you want it permanently stored locally.

IMPORTANT MODEL LIMIT: The included MINI_AI_SCRATCH_LLM.py is a character n-gram pattern learner, not a Transformer LLM. It has no pretrained weights and trains from scratch, but it is not capable of general reasoning. This profile does not magically make it a large language model. A useful LLM trained from random weights requires far more data and compute than this laptop can provide. The previous main app and its KoboldCpp runtime are included separately and are not repaired by this profile.

START: run Start_Scratch_Learner.bat. Existing data is stored in %LOCALAPPDATA%\MiniAILiteX_PersonalAI_Max\. This ZIP does not move or delete existing data.
