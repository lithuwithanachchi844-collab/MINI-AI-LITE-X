MINI AI LITE X PERSONAL -- OWN MINI AI LLM (FROM SCRATCH)

This edition no longer uses Qwen, KoboldCpp, a downloaded model, a local model server, or a hosted AI API for chat. The chat response path calls mini_ai_llm.py directly. The source file is included in this ZIP.

The built-in engine is a tiny word n-gram language learner plus local knowledge retrieval, written from scratch with Python's standard library. It learns word-transition statistics from text it finds in MINI AI's local SQLite database, including saved AutoLearn material and chat text. It automatically checks the app database while answering, so no URL entry is needed.

HONEST LIMITATION: This is not a modern Transformer LLM and cannot match ChatGPT or a trained 0.5B/7B LLM. It has no pretrained neural weights; it is a small statistical language engine. It can save and reuse information, but its generated language and reasoning are limited. Training a capable LLM from scratch is not feasible on a Core 2-era laptop with 4 GB RAM.

AutoLearn still requires internet to discover new public information. Saved local material works offline. Website blocks, network failures, or inaccessible search pages may prevent new learning.

Run Start_MINI_AI_LITE_X.bat. No Setup_Local_LLM.bat is required. The app still needs a compatible installed Python 3 with Tkinter.

Package tests performed: ZIP integrity and Python syntax parsing. Not tested on the user's physical laptop; live web research was not tested.
