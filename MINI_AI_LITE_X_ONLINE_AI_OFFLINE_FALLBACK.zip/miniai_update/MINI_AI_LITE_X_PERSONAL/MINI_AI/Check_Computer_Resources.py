import os, shutil, platform
from pathlib import Path
print('MINI AI local resource check')
print('OS:', platform.platform())
print('Logical CPU threads:', os.cpu_count() or 'unknown')
try:
 import ctypes
 class MEMORYSTATUSEX(ctypes.Structure):
  _fields_=[('dwLength',ctypes.c_ulong),('dwMemoryLoad',ctypes.c_ulong),('ullTotalPhys',ctypes.c_ulonglong),('ullAvailPhys',ctypes.c_ulonglong),('ullTotalPageFile',ctypes.c_ulonglong),('ullAvailPageFile',ctypes.c_ulonglong),('ullTotalVirtual',ctypes.c_ulonglong),('ullAvailVirtual',ctypes.c_ulonglong),('ullAvailExtendedVirtual',ctypes.c_ulonglong)]
 s=MEMORYSTATUSEX(); s.dwLength=ctypes.sizeof(s); ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s))
 print('RAM total: %.2f GB'%(s.ullTotalPhys/1024**3)); print('RAM available now: %.2f GB'%(s.ullAvailPhys/1024**3)); print('RAM load:',s.dwMemoryLoad,'%')
except Exception as e: print('RAM info unavailable:',e)
p=Path(os.environ.get('LOCALAPPDATA',str(Path.home())))
t=shutil.disk_usage(p)
print('Disk free on app-data drive: %.2f GB'%(t.free/1024**3))
print('Requested MINI AI storage cap: 200 GB (a cap, not reserved space)')
print('GPU: legacy Quadro NVS 160M; assume CPU processing unless a compatible accelerator is explicitly verified.')
input('Press Enter to close...')
