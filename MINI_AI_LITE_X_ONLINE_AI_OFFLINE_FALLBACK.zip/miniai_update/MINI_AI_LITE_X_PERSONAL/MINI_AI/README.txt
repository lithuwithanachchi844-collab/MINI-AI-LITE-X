MINI AI LITE X PERSONAL — ALL-FEATURES ONE-APP EDITION
Latitude E6500 / Windows 10 legacy-friendly target
=================================================

WHAT THIS PACKAGE IS
--------------------
One ZIP containing the MINI AI desktop program, one-click launcher, local model setup, and diagnostic self-test. It is a Python/Tkinter desktop application, not a compiled EXE and not a model preloaded into the ZIP.

START HERE
----------
1. Extract this ZIP with Windows Extract All.
2. Open the MINI_AI folder.
3. Double-click Start_MINI_AI.bat.
4. On first launch, setup downloads the local runtime and language model. Keep internet connected and allow it to finish.
5. After setup, restart MINI AI. Local chat can then work without internet.

If the local language model fails, close MINI AI and run Repair_Local_AI.bat. The repair checks for incomplete downloads, validates the GGUF model and Windows runtime, and retries setup. Run Check_Local_AI.bat to inspect the installed files, local server and logs. Runtime logs are saved in %LOCALAPPDATA%\MiniAILiteX_PersonalAI_Max\llm_runtime.log and llm_start_error.txt. See LLM_REPAIR_NOTES.txt.

LOCAL MODEL
-----------
For a typical 4 GB Latitude E6500, setup now chooses the smaller/faster Qwen 2.5 0.5B Instruct Q4 to reduce CPU latency and RAM pressure. Systems with more than 4.5 GB physical RAM can use Qwen 2.5 1.5B Q4. Approximate model sizes: 1.1 GB and 0.4 GB respectively. The installer also downloads a legacy-CPU-compatible runtime, validates its Windows executable header and validates the GGUF model header and minimum size. The app waits for the local server and retries temporary connection failures. These downloads are not inside this small ZIP.

The E6500's old CPU may generate text slowly. Close other apps and keep Windows virtual memory enabled. The app uses a small context and up to two CPU threads on low-memory systems. These are conservative settings, not a speed guarantee. The 1.5B model may still be too slow or unstable on some E6500 configurations; use the smaller model if needed.

FEATURES INCLUDED IN THE APP
----------------------------
- Local LLM chat and task-focused AI Agent mode.
- Persistent SQLite chat history with lossless compression plus a compact saved_chats.zip archive. The ZIP contains one ordered history file; duplicate per-message archive copies were removed to reduce storage. The database remains the working copy.
- Retrieval of relevant prior conversation exchanges and locally saved knowledge.
- Teach AI / save lessons; search, view and delete saved knowledge.
- Automatic multi-engine search for common factual questions (enabled by default), plus on-demand research, readable-page extraction and source comparison where sites permit access.
- Optional attempts to read publicly available YouTube transcripts/captions.
- File import and folder import for readable text; chat export.
- Offline Studio for drafting content from saved/local information (not offline image generation).
- Developer tools / code lab with templates and basic validation helpers.
- Notes and knowledge journal, tasks/checklists, flashcards/study mode, text toolbox and quick tools/calculator.
- Hardware diagnostics and hardware/model-fit advice.
- Backup and restore, storage quota settings, privacy/offline settings, persona settings and research settings.
- MINI AI Eyes with live webcam object boxes using YOLOv4-tiny trained for 80 common COCO categories. On first use it automatically downloads the detector files into the private app data folder (internet required once); you do not enter links. It is a category detector, not a general-purpose image-understanding model.
- When no trained category is detected, the camera marks the scene UNKNOWN so you can press “Teach boxed object”. Teaching stores a compressed example image and colour-histogram signature locally. It may match visually similar examples, but this is not neural-model training and can misidentify objects when lighting/backgrounds change.
- The “Analyze snapshot offline” button uses the built-in local detector and saved visual notes. It never asks you for a vision URL. It reports detected categories and uncertainty; detailed free-form image understanding still requires a separate vision-capable model and is not falsely advertised as included.
- AutoLearn is enabled by default for factual-question searches, explicit research requests and imported documents. Rotating-topic AutoLearn also starts after about one minute, then researches one topic at the configured interval (default 5 minutes) while online research and AutoLearn are enabled. It cycles through electronics, Arduino, weather, computing, astronomy, biology, physics, maths, security, energy, geography and source evaluation. It pauses in Offline-only mode; disable “Automatically research a rotating topic” in Settings to stop it. Search sites can block results. Background topic notes keep shorter source excerpts to limit storage.
- Simulated conversational expression/status indicators; these are UI features, not consciousness.

DATA AND PRIVACY
----------------
App data is stored locally in:
%LOCALAPPDATA%\MiniAILiteX_PersonalAI_Max
No API key, account, paid AI subscription or hosted AI inference is required. Web research needs internet and is only performed through the app's research workflows/settings. Saved chat retrieval is memory retrieval, not retraining the underlying model. Saved chats are also written to saved_chats.zip inside this folder; the ZIP is refreshed when new chat messages are saved. Make a backup before replacing files or restoring a backup.

RUN SELF-TEST
-------------
Double-click Run_Self_Test.bat. This checks the Python version, Tkinter availability, app/setup syntax, chat compression round-trip and a temporary SQLite read/write test. It does not download or run the AI model and does not test the physical laptop's performance.

LIMITATIONS / TEST STATUS
------------------------
- The local model is downloaded separately; this is not a self-contained EXE.
- The package syntax and offline tests can be checked here, but the live runtime/model download and real Windows GUI/webcam on the physical Latitude E6500 have not been verified in this environment.
- Windows 10 version 1607 may have TLS, certificate, CPU instruction or runtime compatibility problems. A failed setup is possible on this old system.
- Small local models cannot match the strongest ChatGPT models in general reasoning. This app does not bundle image/video generation, speech recognition, a full browser-driving agent, or unrestricted autonomous computer control.
- Online research results can be blocked, incomplete or inaccurate; source availability is not guaranteed.


MINI AI EYES (OPTIONAL CAMERA)
- Open “MINI AI Eyes · Camera” in the left workspace.
- On the Dell E6500, the launcher uses %USERPROFILE%\MINI_AI_CAMERA\Scripts\python.exe when available, matching the tested NumPy 1.26.4 and OpenCV 4.10.0 environment.
- The first object-detection run downloads the MobileNet-SSD prototxt and weights (roughly 23 MB total) into %LOCALAPPDATA%\MiniAILiteX_PersonalAI_Max\vision_models. Keep internet connected for this first setup. Detection runs locally on CPU and may be slow on the Core 2 Duo.
- Capture snapshots and save a private image plus your description into the local visual journal. The camera stops when the Eyes window closes.
- Saved visual notes and user-taught labels stay in the local app data folder. Camera frames are processed locally; snapshots are only sent if you explicitly configure and invoke a vision endpoint.
- Detector classes are limited; a full-frame UNKNOWN box is a fallback, not proof that a single object has been segmented. Detailed image conversation still needs a separate local multimodal vision server/model.
- The camera feature stops when Eyes closes and does not silently record in the background.


CAMERA ACCESS WITHOUT A CAMERA APP
- MINI AI opens the webcam device directly through OpenCV; you do not need the Windows Camera app.
- If OpenCV is missing, the Eyes window can install it into the same Python interpreter running MINI AI.
- Run Camera_Diagnostics.bat to check whether Windows can deliver a webcam frame to Python.
- If no frame is found, check Settings > Privacy > Camera, the webcam driver, and any app holding the camera.

CHAT AND LOCAL MODEL
- The chat composer remains available while local inference runs; requests are queued one at a time to avoid overlapping model work on older CPUs.
- Auto Search avoids ordinary personal/conversational questions so those can go to the local model.
- A successful package self-test does not prove the local model downloads or the physical webcam work on the target laptop.


CAMERA COMPATIBILITY NOTE
For older CPUs such as Intel Core 2 Duo, use Install_Camera_Support.bat. It installs NumPy 1.26.4 and OpenCV 4.10.0.84 into %USERPROFILE%\MINI_AI_CAMERA using Python 3.11, and the main launcher prefers that interpreter. This avoids the incompatible NumPy 2.x wheel in Python 3.13.

REPAIR NOTES (2026-10-25)
- Start_MINI_AI.bat now opens the application immediately; it no longer blocks startup by trying to download a language model first. Use the in-app model setup option when you choose to install the local language model.
- Ordinary chat no longer automatically diverts every factual question into an online search by default. Explicit Research commands still use the research workflow.
- Camera detector upgraded from the old 20-category MobileNet-SSD to YOLOv4-tiny (80 COCO categories). First camera use automatically downloads the model; no URLs need to be typed by the user. Internet access is needed for that first download.
- Camera adds “What can I make?” suggestions based on visible detector labels and saved taught labels.
- The visual-label database supports searching up to 10,000 saved taught examples. This is NOT a pre-trained 10,000-class neural detector: the bundled detector recognizes 80 standard categories, and extra labels are example-based and can be inaccurate. No one can honestly promise reliable 10,000-object recognition on this 4 GB, old-CPU laptop without a much larger model/database and evaluation.
- Static syntax and package tests do not prove the GUI, detector download, or local model works on every Windows computer. The camera was previously confirmed to capture frames in the user's Python 3.11 camera environment; the repaired YOLO detector still needs a real Windows run to verify.


CHAT AND IMAGE FIXES (2026-10-25)
- Camera snapshot analysis no longer asks for a local vision-server URL or model name. “Analyze snapshot offline” reports the built-in detector results, confidence estimates and uncertainty.
- If the local language model is absent, chat now provides clear built-in help and directs the user to the one-click model installer; it does not claim a full neural chatbot is working when the model is missing.
- To enable genuine open-ended offline text chat, use “Set up / change AI model” once while internet is available. The setup chooses and downloads the compatible runtime/model automatically; no URL, API key, or account is required. The model then runs locally when available.
- Offline tools remain available without the model, but scripted fallback replies are not equivalent to a real language model.

AUTOLEARN: This updated edition can research rotating built-in topics automatically; no webpage URL entry is needed. See AUTOLEARN_NO_URL.txt.


SINGLE MODEL EDITION
This package exposes one default model only: MINI AI AutoLearn LLM (Qwen 2.5 0.5B quantized local engine). Scratch learner and alternate model profile files have been removed. AutoLearn stores web-derived knowledge locally; it does not fine-tune model weights.


LIVE AI DESK SCENE UPDATE
- Live AI includes a lightweight vector room with a chair, robot, desk, laptop chat screen, keyboard and mouse.
- When you send a message in Live AI, the robot visibly walks to the computer, moves its arms over the keyboard, animates the on-screen chat/cursor, reacts, then walks back to its chair.
- After roughly three minutes sitting idle, it performs a brief animated stretch and returns to the desk area. Sending a message interrupts the break.
- Animation is local Tkinter vector drawing, approximately 8 frames per second. It does not send real Windows mouse or keyboard input, and it is not consciousness.
- The scene is designed to be lightweight; camera/model processing and web research may use additional CPU independently.


ONLINE AI REASONING + OFFLINE FALLBACK UPDATE
Open MINI AI Settings and find "ONLINE AI REASONING + OFFLINE FALLBACK".
This is opt-in. Enable it, enter an OpenAI-compatible HTTPS API base URL,
provider model name, and your own API key, then Save Settings. For example,
the base URL for an OpenAI-compatible endpoint can be https://api.openai.com.
The provider/model availability and pricing depend on your chosen provider.
Never share your API key. It is stored locally in the app settings file.
When online AI is disabled, Offline-only is enabled, or the request fails,
MINI AI falls back to its bundled local language engine. Local fallback quality
is much more limited than a modern hosted model and requires the local engine
to be working. This does not retrain the local model. Online providers receive
the prompt text sent for processing.
