@echo off
cd /d "%~dp0"
echo MINI AI LLM is built into this app. No external model download or server is needed.
echo Start MINI AI with Start_MINI_AI_LITE_X.bat
pause
