@echo off
setlocal
cd /d "%~dp0"
title MINI AI - Local model diagnostic
where py >nul 2>nul
if not errorlevel 1 (
  py -3 check_local_ai.py
) else (
  python check_local_ai.py
)
echo.
pause
