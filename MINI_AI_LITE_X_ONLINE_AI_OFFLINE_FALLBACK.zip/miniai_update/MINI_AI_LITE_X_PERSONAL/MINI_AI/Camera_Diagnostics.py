import os, sys, importlib.util, platform
print('MINI AI CAMERA DIAGNOSTICS')
print('Python:', sys.executable)
print('Version:', sys.version)
print('OS:', platform.platform())
try:
 import cv2
 print('OpenCV:', cv2.__version__)
 backends=[('DirectShow',getattr(cv2,'CAP_DSHOW',0)),('Media Foundation',getattr(cv2,'CAP_MSMF',0)),('Default',getattr(cv2,'CAP_ANY',0))] if os.name=='nt' else [('Default',getattr(cv2,'CAP_ANY',0))]
 found=False
 for idx in range(5):
  for label,backend in backends:
   cap=None
   try:
    cap=cv2.VideoCapture(idx,backend)
    if not cap.isOpened(): continue
    ok,frame=cap.read()
    if ok and frame is not None and getattr(frame,'size',0)>0:
     print(f'WORKING CAMERA: device={idx}, backend={label}, frame={frame.shape[1]}x{frame.shape[0]}')
     found=True; break
   except Exception as e: print(f'Device {idx} {label}: {type(e).__name__}: {e}')
   finally:
    if cap is not None: cap.release()
  if found: break
 if not found: print('No camera returned a frame. Check Windows camera privacy, driver, and whether another app is using it.')
except Exception as e:
 print('OpenCV import failed:',repr(e))
 print('Install with this interpreter:')
 print('"'+sys.executable+'" -m pip install --user opencv-python==4.10.0.84')
input('\nPress Enter to close...')
