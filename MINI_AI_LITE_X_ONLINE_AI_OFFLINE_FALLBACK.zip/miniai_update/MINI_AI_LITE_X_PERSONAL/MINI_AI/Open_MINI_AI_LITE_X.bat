@echo off
cd /d "%~dp0"
call Start_MINI_AI.bat
