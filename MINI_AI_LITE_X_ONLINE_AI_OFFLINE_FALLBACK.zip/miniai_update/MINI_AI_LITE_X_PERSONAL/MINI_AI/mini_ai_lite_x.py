import os, sys, json, sqlite3, threading, time, shutil, zipfile, webbrowser, re, html, urllib.request, urllib.parse, concurrent.futures, xml.etree.ElementTree as ET, subprocess, zlib, base64, importlib
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

APP_NAME = 'MINI AI LITE X PERSONAL'
APP_DIR = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'MiniAILiteX_PersonalAI_Max'
APP_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = APP_DIR / 'personal_ai.sqlite3'
SETTINGS_PATH = APP_DIR / 'settings.json'
DEFAULTS = {'storage_limit_gb': 100, 'auto_research': True, 'auto_compare': True, 'online_research': True, 'offline_only': False, 'persona': 'Friendly, thoughtful, honest', 'max_results': 5, 'theme': 'Dark', 'auto_save_chats': True, 'show_sources': True, 'research_timeout': 12, 'auto_learn_imports': True, 'auto_learn': True, 'studio_default': 'Notes', 'max_import_mb': 25, 'search_duckduckgo': True, 'search_bing': True, 'search_mojeek': True, 'fetch_full_pages': True, 'max_pages_to_read': 3, 'youtube_transcripts': True, 'llm_base_url': 'internal://mini-ai-llm', 'llm_model': 'mini-ai-from-scratch', 'llm_model_file': 'mini_ai_llm_model.json', 'llm_api_key': '', 'online_ai_enabled': False, 'online_ai_model': 'gpt-4.1-mini', 'llm_timeout': 120, 'auto_search_questions': True, 'auto_topic_learning': True, 'auto_topic_interval_minutes': 5}

def load_settings():
    try:
        data = json.loads(SETTINGS_PATH.read_text(encoding='utf-8'))
        return {**DEFAULTS, **data}
    except Exception:
        return DEFAULTS.copy()

SETTINGS = load_settings()
# One-time migration from the earlier offline-locked package. The user explicitly
# requested automatic learning without entering URLs, so enable it in this edition.
if not SETTINGS.get('autolearn_url_free_migration_v1', False):
    SETTINGS.update({'online_research': True, 'offline_only': False, 'auto_research': True,
                     'auto_learn': True, 'auto_topic_learning': True,
                     'auto_topic_interval_minutes': 5, 'auto_search_questions': True,
                     'autolearn_url_free_migration_v1': True})
# User-requested five-minute learning schedule. This migration runs once on upgrade;
# afterwards the user can change the interval in Settings (minimum five minutes).
if not SETTINGS.get('autolearn_5min_schedule_v1', False):
    SETTINGS['auto_topic_interval_minutes'] = 5
    SETTINGS['auto_search_questions'] = True
    SETTINGS['autolearn_5min_schedule_v1'] = True
SETTINGS['auto_topic_interval_minutes'] = max(5, min(1440, int(SETTINGS.get('auto_topic_interval_minutes', 5))))
# This edition reserves a maximum budget of 100 GB for MINI AI's own data.
# The user's other AI app can use its separate 100 GB budget (200 GB total).
if not SETTINGS.get('mini_ai_100gb_quota_v1', False):
    SETTINGS['storage_limit_gb'] = 100
    SETTINGS['mini_ai_100gb_quota_v1'] = True
else:
    SETTINGS['storage_limit_gb'] = 100
# AutoLearn begins shortly after the app opens; it searches built-in topics and
# saves readable source text locally. No URL entry is required. Offline mode pauses it.
# Local LLM inference stays on this laptop. AutoLearn may fetch public web pages when
# enabled; collected text is stored in the local knowledge database for offline retrieval.
# Online reasoning is optional and opt-in. When configured, it is tried first; local MINI AI is the fallback.
try:
    SETTINGS_PATH.write_text(json.dumps(SETTINGS, indent=2), encoding='utf-8')
except Exception:
    pass

def pack_chat_body(value):
    """Store chat text compressed when it saves space; transparent to the rest of the app."""
    raw = str(value or '').encode('utf-8', 'replace')
    packed = zlib.compress(raw, 9)
    if len(packed) + 8 < len(raw):
        return '!Z1!' + base64.b64encode(packed).decode('ascii')
    return str(value or '')

def unpack_chat_body(value):
    value = str(value or '')
    if value.startswith('!Z1!'):
        try:
            return zlib.decompress(base64.b64decode(value[4:])).decode('utf-8', 'replace')
        except Exception:
            return '[This saved chat message could not be decompressed.]'
    return value

def update_chat_zip():
    """Keep a compact, portable ZIP snapshot of saved chat history."""
    archive = APP_DIR / 'saved_chats.zip'
    try:
        with db() as con:
            rows = con.execute('SELECT id,role,body,created FROM chats ORDER BY id').fetchall()
        lines = []
        for ident, role, body, created in rows:
            item = {'id': ident, 'role': role, 'text': unpack_chat_body(body), 'created': created}
            lines.append(json.dumps(item, ensure_ascii=False, separators=(',', ':')))
        raw = ('\n'.join(lines) + ('\n' if lines else '')).encode('utf-8')
        tmp = archive.with_suffix('.zip.tmp')
        with zipfile.ZipFile(tmp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            # Store one compressed stream only; the previous per-message copies duplicated the same chat data.
            zf.writestr('saved_chats.jsonl', raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            zf.writestr('README.txt', 'MINI AI LITE X PERSONAL compact chat archive. saved_chats.jsonl contains the complete ordered history. The live SQLite database remains the working copy; chat message bodies are losslessly compressed when that saves space.\n')
        tmp.replace(archive)
    except Exception:
        # The main SQLite history remains the authoritative copy if archiving fails.
        pass

def db():
    con = sqlite3.connect(DB_PATH)
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('''CREATE TABLE IF NOT EXISTS knowledge(id INTEGER PRIMARY KEY, title TEXT, body TEXT, source TEXT, created TEXT, digest TEXT UNIQUE)''')
    con.execute('''CREATE TABLE IF NOT EXISTS chats(id INTEGER PRIMARY KEY, role TEXT, body TEXT, created TEXT)''')
    con.execute('''CREATE TABLE IF NOT EXISTS lessons(id INTEGER PRIMARY KEY, title TEXT, body TEXT, created TEXT)''')
    con.execute('''CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, title TEXT, body TEXT, updated TEXT)''')
    con.execute('''CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY, title TEXT, details TEXT, due TEXT, done INTEGER DEFAULT 0, created TEXT)''')
    con.execute('''CREATE TABLE IF NOT EXISTS flashcards(id INTEGER PRIMARY KEY, question TEXT, answer TEXT, created TEXT)''')
    con.execute('''CREATE TABLE IF NOT EXISTS app_meta(key TEXT PRIMARY KEY, value TEXT)''')
    con.execute('''CREATE TABLE IF NOT EXISTS eye_observations(id INTEGER PRIMARY KEY, image_path TEXT, description TEXT, created TEXT, digest TEXT UNIQUE)''')
    con.execute('''CREATE TABLE IF NOT EXISTS visual_labels(id INTEGER PRIMARY KEY, label TEXT NOT NULL, image_path TEXT, histogram TEXT NOT NULL, created TEXT)''')
    migrated = con.execute("SELECT value FROM app_meta WHERE key='chat_compression_v1'").fetchone()
    if not migrated:
        rows = con.execute('SELECT id,body FROM chats').fetchall()
        for ident, body in rows:
            packed = pack_chat_body(body)
            if packed != body:
                con.execute('UPDATE chats SET body=? WHERE id=?', (packed, ident))
        con.execute("INSERT OR REPLACE INTO app_meta(key,value) VALUES('chat_compression_v1','done')")
        con.commit()
        # Reclaim unused pages from the one-time conversion of older, uncompressed chat logs.
        try:
            con.execute('PRAGMA wal_checkpoint(TRUNCATE)')
            con.execute('VACUUM')
        except sqlite3.Error:
            pass
    con.commit()
    return con

def stamp(): return datetime.now().strftime('%Y-%m-%d %H:%M:%S')
def digest(s):
    import hashlib
    return hashlib.sha256(s.strip().encode('utf-8', 'ignore')).hexdigest()
def detect_system_ram_gb():
    """Return physical RAM in GiB without requiring third-party packages."""
    try:
        if os.name == 'nt':
            import ctypes
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [('dwLength', ctypes.c_ulong), ('dwMemoryLoad', ctypes.c_ulong),
                            ('ullTotalPhys', ctypes.c_ulonglong), ('ullAvailPhys', ctypes.c_ulonglong),
                            ('ullTotalPageFile', ctypes.c_ulonglong), ('ullAvailPageFile', ctypes.c_ulonglong),
                            ('ullTotalVirtual', ctypes.c_ulonglong), ('ullAvailVirtual', ctypes.c_ulonglong),
                            ('ullAvailExtendedVirtual', ctypes.c_ulonglong)]
            state = MEMORYSTATUSEX(); state.dwLength = ctypes.sizeof(state)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(state)):
                return state.ullTotalPhys / (1024 ** 3)
    except Exception:
        pass
    try:
        pages = os.sysconf('SC_PHYS_PAGES'); page_size = os.sysconf('SC_PAGE_SIZE')
        return pages * page_size / (1024 ** 3)
    except Exception:
        return 4.0


def storage_bytes():
    total = 0
    for p in APP_DIR.rglob('*'):
        try:
            if p.is_file(): total += p.stat().st_size
        except OSError: pass
    return total

def within_quota(extra=0):
    return storage_bytes() + extra < float(SETTINGS.get('storage_limit_gb', 200)) * (1024**3)

def add_knowledge(title, body, source='manual'):
    body = body.strip()
    if not body: return False, 'No readable text found.'
    if not within_quota(len(body.encode('utf-8'))): return False, 'Storage limit reached. Increase the limit or delete saved data.'
    d = digest(title + '\n' + body)
    try:
        with db() as con: con.execute('INSERT INTO knowledge(title,body,source,created,digest) VALUES(?,?,?,?,?)', (title[:500], body, source[:1000], stamp(), d))
        return True, 'Saved to private knowledge.'
    except sqlite3.IntegrityError:
        return False, 'Duplicate knowledge entry; it was not saved twice.'

def tokenize(s): return set(re.findall(r"[a-z0-9_'-]{2,}", s.lower()))
def retrieve(query, limit=5):
    q = tokenize(query)
    if not q: return []
    with db() as con: rows = con.execute('SELECT id,title,body,source,created FROM knowledge').fetchall()
    ranked=[]
    for row in rows:
        title, body = row[1] or '', row[2] or ''
        words = tokenize(title + ' ' + body[:50000])
        overlap = len(q & words)
        if overlap:
            score = overlap / max(1, len(q)) + (len(q & tokenize(title)) * 0.8)
            ranked.append((score, row))
    ranked.sort(key=lambda x:x[0], reverse=True)
    return [r for _,r in ranked[:limit]]

def retrieve_conversation_memories(query, limit=4):
    """Retrieve relevant past user/assistant exchanges from the persistent chat log.

    This is retrieval-based learning: it helps the model reuse earlier context without
    pretending that chat logs have retrained the underlying neural network.
    """
    q = tokenize(query)
    stop = {'what','when','where','which','that','this','with','from','have','your','about','would','could','should','there','their','them','they','then','than','into','does','doing','please','help','tell','explain','make','want','need'}
    q -= stop
    if not q:
        return []
    with db() as con:
        rows = [(r[0], r[1], unpack_chat_body(r[2]), r[3]) for r in con.execute('SELECT id,role,body,created FROM chats ORDER BY id DESC LIMIT 800').fetchall()]
    rows.reverse()
    results=[]
    for i,row in enumerate(rows):
        rid,role,body,created=row
        if str(role).lower() not in ('you','user'):
            continue
        user_text=str(body or '').strip()
        if not user_text or user_text.lower()==str(query).strip().lower():
            continue
        words=tokenize(user_text)-stop
        overlap=q & words
        if not overlap:
            continue
        score=len(overlap)/max(1,len(q)) + (len(overlap)/max(1,len(words)))*0.35
        reply=''
        for nxt in rows[i+1:i+4]:
            if str(nxt[1]).lower() not in ('you','user'):
                reply=str(nxt[2] or '').strip()
                break
        if reply:
            results.append((score,user_text,reply,created))
    results.sort(key=lambda x:x[0],reverse=True)
    # De-duplicate near-identical question text while retaining highest-ranked exchange.
    out=[]; seen=set()
    for item in results:
        key=re.sub(r'\W+',' ',item[1].lower()).strip()
        if key in seen: continue
        seen.add(key); out.append(item)
        if len(out)>=limit: break
    return out


def answer_local(query):
    matches = retrieve(query, 4)
    if not matches:
        return ('I don’t have a relevant saved lesson or source for that yet. I can still help structure the question, or you can teach me using **Teach AI** / import a file. '
                'This build does not include a bundled language model, so it will not pretend to have model-level reasoning when no model is installed.')
    out = ['I found these relevant items in your private saved knowledge:']
    for i, row in enumerate(matches, 1):
        snippet = re.sub(r'\s+', ' ', row[2]).strip()
        if len(snippet) > 850: snippet = snippet[:847] + '...'
        out.append(f'\n{i}. **{row[1]}**\n{snippet}\nSource: {row[3]} · saved {row[4]}')
    out.append('\nThese are retrieved saved notes, not independently verified facts. I have not inferred anything beyond their contents.')
    return '\n'.join(out)

class _PageTextParser(__import__('html.parser', fromlist=['HTMLParser']).HTMLParser):
    """Small dependency-free HTML text extractor; deliberately skips active/noisy regions."""
    def __init__(self):
        super().__init__(convert_charrefs=True); self.parts=[]; self.title_parts=[]; self.in_title=False; self.skip=0
        self.skip_tags={'script','style','noscript','svg','nav','footer','header','form','aside'}
    def handle_starttag(self, tag, attrs):
        if tag in self.skip_tags: self.skip += 1
        if tag == 'title': self.in_title=True
        if tag in {'p','br','div','li','h1','h2','h3','article','section'}: self.parts.append('\n')
    def handle_endtag(self, tag):
        if tag in self.skip_tags and self.skip: self.skip -= 1
        if tag == 'title': self.in_title=False
        if tag in {'p','br','li','h1','h2','h3','article','section'}: self.parts.append('\n')
    def handle_data(self, data):
        if self.in_title: self.title_parts.append(data.strip())
        if not self.skip and data.strip(): self.parts.append(data.strip()+' ')

def _fetch_text(url, timeout=10, max_bytes=1_500_000):
    if not url.startswith(('http://','https://')): return '', ''
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; PersonalAIResearch/1.0)' ,'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.5'})
    with urllib.request.urlopen(req,timeout=timeout) as response:
        ctype=response.headers.get('Content-Type','').lower()
        if not any(x in ctype for x in ('text/html','application/xhtml+xml','text/plain','application/xml','text/xml')): return '', ''
        data=response.read(max_bytes).decode('utf-8','replace')
    if 'html' not in ctype and not data.lstrip().startswith('<'): return '', re.sub(r'\s+',' ',data).strip()
    parser=_PageTextParser()
    try: parser.feed(data)
    except Exception: pass
    title=re.sub(r'\s+',' ',' '.join(parser.title_parts)).strip()
    body=re.sub(r'[ \t]+',' ',' '.join(parser.parts)); body=re.sub(r'\n\s*\n+','\n',body).strip()
    return title, body[:60000]

def _search_one(engine, query, timeout=12, limit=8):
    """Return title/url pairs from independent public search endpoints; no API keys."""
    q=urllib.parse.quote_plus(query); found=[]
    if engine == 'DuckDuckGo':
        url='https://html.duckduckgo.com/html/?q='+q
        req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36'})
        with urllib.request.urlopen(req,timeout=timeout) as r: data=r.read(1_500_000).decode('utf-8','replace')
        for href,title in re.findall(r'<a[^>]+class=["\']result__a["\'][^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',data,re.I|re.S):
            title=html.unescape(re.sub(r'<[^>]+>',' ',title)); href=html.unescape(href)
            if href.startswith('//'): href='https:'+href
            if 'uddg=' in href:
                try: href=urllib.parse.parse_qs(urllib.parse.urlparse(href).query).get('uddg',[href])[0]
                except Exception: pass
            if title.strip() and href.startswith(('http://','https://')): found.append((re.sub(r'\s+',' ',title).strip(),href))
    elif engine == 'Bing':
        url='https://www.bing.com/search?format=rss&q='+q
        req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 PersonalAIResearch/1.0'})
        with urllib.request.urlopen(req,timeout=timeout) as r: data=r.read(1_500_000)
        root=ET.fromstring(data)
        for item in root.findall('.//item'):
            title=item.findtext('title') or ''; href=item.findtext('link') or ''
            if title and href.startswith(('http://','https://')): found.append((title.strip(),href.strip()))
    elif engine == 'Mojeek':
        url='https://www.mojeek.com/search?q='+q
        req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/124 Safari/537.36'})
        with urllib.request.urlopen(req,timeout=timeout) as r: data=r.read(1_500_000).decode('utf-8','replace')
        # Mojeek markup has result-title links; constrain to absolute external links.
        for href,title in re.findall(r'<a[^>]+href=["\'](https?://[^"\']+)["\'][^>]*class=["\'][^"\']*(?:title|ob)[^"\']*["\'][^>]*>(.*?)</a>',data,re.I|re.S):
            title=html.unescape(re.sub(r'<[^>]+>',' ',title)).strip()
            if title: found.append((re.sub(r'\s+',' ',title),html.unescape(href)))
    # de-duplicate by canonical URL, preserve engine order
    unique=[]; seen=set()
    for title,url in found:
        url=url.split('#')[0]
        if url not in seen: seen.add(url); unique.append((title,url,engine))
        if len(unique)>=limit: break
    return unique


def _youtube_transcript(url, timeout=12):
    """Try to read a publicly exposed YouTube caption track; never logs in or bypasses access controls."""
    try:
        parsed=urllib.parse.urlparse(url)
        vid=(urllib.parse.parse_qs(parsed.query).get('v') or [''])[0]
        if parsed.hostname in ('youtu.be','www.youtu.be'): vid=parsed.path.strip('/').split('/')[0]
        if not vid or not re.fullmatch(r'[A-Za-z0-9_-]{6,20}',vid): return '', ''
        req=urllib.request.Request('https://www.youtube.com/watch?v='+vid,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36','Accept-Language':'en-US,en;q=0.8'})
        with urllib.request.urlopen(req,timeout=timeout) as r: page=r.read(3_000_000).decode('utf-8','replace')
        # Find the captionTracks JSON array with a small bracket-aware scan.
        m=re.search(r'"captionTracks"\s*:\s*\[',page)
        if not m: return '', ''
        start=page.find('[',m.start()); depth=0; quoted=False; escaped=False; end=-1
        for i in range(start,len(page)):
            ch=page[i]
            if quoted:
                if escaped: escaped=False
                elif ch=='\\': escaped=True
                elif ch=='"': quoted=False
                continue
            if ch=='"': quoted=True
            elif ch=='[': depth+=1
            elif ch==']':
                depth-=1
                if depth==0: end=i+1; break
        if end<0: return '', ''
        tracks=json.loads(page[start:end])
        if not tracks: return '', ''
        track=next((t for t in tracks if (t.get('languageCode') or '').startswith('en')),tracks[0])
        base=track.get('baseUrl','')
        if not base: return '', ''
        if 'fmt=' not in base: base += ('&' if '?' in base else '?')+'fmt=srv3'
        req=urllib.request.Request(base,headers={'User-Agent':'Mozilla/5.0'})
        with urllib.request.urlopen(req,timeout=timeout) as r: cap=r.read(2_000_000).decode('utf-8','replace')
        pieces=re.findall(r'<text\b[^>]*>(.*?)</text>',cap,re.I|re.S)
        if not pieces: pieces=re.findall(r'<p\b[^>]*>(.*?)</p>',cap,re.I|re.S)
        text=' '.join(html.unescape(re.sub(r'<[^>]+>',' ',x)) for x in pieces)
        text=re.sub(r'\s+',' ',text).strip()
        return (('YouTube caption transcript' if text else ''),text[:60000])
    except Exception:
        return '', ''

def summarize_in_own_words(question, body, max_sentences=6):
    """Lightweight extractive summary: selects relevant original sentences, does not invent claims."""
    clean=re.sub(r'\s+',' ',body).strip()
    sentences=re.split(r'(?<=[.!?])\s+(?=[A-Z0-9])',clean)
    q=tokenize(question)
    stop={'that','this','with','from','have','their','about','which','when','what','will','into','than','also','more','some','your','they','them','were','been','being','there','where','could','would','should','other','using','used','such','each','only','very','over','under','into','have','does','just','than','then','because','while','after','before','these','those','very','much'}
    scored=[]
    for i, sentence in enumerate(sentences):
        words=tokenize(sentence)-stop
        if len(words)<5: continue
        score=len(words & q)/max(1,len(q)) + min(len(words),35)/350
        if re.search(r'\b(is|are|was|were|means|defined as|according to|because|therefore|result|study|research|found|conclude)\b',sentence,re.I): score+=0.08
        scored.append((score,i,sentence))
    chosen=sorted(sorted(scored,reverse=True)[:max_sentences],key=lambda x:x[1])
    return ' '.join(x[2] for x in chosen)[:3500] if chosen else clean[:1200]

def summarize_with_local_model(question, body, timeout=35):
    """Use the installed local LLM to paraphrase source text; fall back safely to extractive text."""
    fallback = summarize_in_own_words(question, body)
    runtime = APP_DIR/'runtime'/'koboldcpp_oldcpu.exe'
    model_file = APP_DIR/'models'/str(SETTINGS.get('llm_model_file','mini_ai_llm_model.json'))
    model_name = str(SETTINGS.get('llm_model','mini-ai-autolearn-llm'))
    if not (runtime.exists() and model_file.exists()):
        return fallback, 'extractive fallback (local model not installed)'
    prompt = (
        'Summarize the supplied source text in your own clear wording for the research question. '
        'Use only claims supported by the text. Preserve important numbers, dates, caveats and disagreements. '
        'Do not invent facts. If the text does not answer the question, say so. Keep it under 180 words.\n\n'
        'RESEARCH QUESTION: '+question[:1000]+'\n\nSOURCE TEXT:\n'+body[:14000]
    )
    payload=json.dumps({'model':model_name,'messages':[
        {'role':'system','content':'You are a careful research summarizer. Ground every statement in the supplied source.'},
        {'role':'user','content':prompt}], 'temperature':0.2,'max_tokens':320,'stream':False}).encode('utf-8')
    req=urllib.request.Request('internal://mini-ai-llm/chat/completions',data=payload,headers={'Content-Type':'application/json'},method='POST')
    try:
        with urllib.request.urlopen(req,timeout=timeout) as response:
            data=json.loads(response.read().decode('utf-8','replace'))
        result=str(data.get('choices',[{}])[0].get('message',{}).get('content','')).strip()
        if 40 <= len(result) <= 2200:
            return result, 'local model paraphrase'
    except Exception:
        pass
    return fallback, 'extractive fallback (local model unavailable)'


def source_quality(url, engines, body=''):
    host=(urllib.parse.urlparse(url).hostname or '').lower()
    score=1
    reasons=[]
    if len(engines)>1: score+=1; reasons.append('found by multiple search engines')
    if host.endswith(('.gov','gov.au','.edu','.edu.au')): score+=3; reasons.append('government/education domain')
    if any(x in host for x in ('who.int','nih.gov','cdc.gov','abs.gov.au','bom.gov.au','nasa.gov','nature.com','science.org')): score+=2; reasons.append('recognised reference/science publisher')
    if len(body)>1000: score+=1; reasons.append('substantial readable text')
    return score, (', '.join(reasons) if reasons else 'no special reliability signal detected')

class App:
    def __init__(self, root):
        self.root=root; root.title(APP_NAME); root.geometry('1000x700'); root.minsize(760,520)
        self.busy=False
        self.llm_lock=threading.Lock()
        self.llm_queue_lock=threading.Lock()
        self.llm_pending=[]
        self.llm_queue_active=False
        self.llm_process=None
        self.mode='LLM'
        self.emotion='curious'
        self.live_feelings={'Curious':65,'Calm':70,'Cheerful':55,'Motivated':60,'Tired':10}
        self.live_thought='Ready to chat, learn, and help.'
        self.live_awareness_enabled=True
        self.build_ui(); self.refresh_status(); self.load_recent()
        self.root.after(30000, self._live_ai_heartbeat)
        self.root.after(700, self.start_local_llm_if_installed)
        self.root.after(2500, self._auto_topic_tick)
    def _auto_topic_tick(self):
        """Research one rotating, bounded learning topic when enabled and online."""
        topics = [
            'basic electronics and safe low-voltage circuits',
            'Arduino programming and embedded systems',
            'weather science and interpreting humidity and clouds',
            'computer hardware and operating system fundamentals',
            'astronomy and the Solar System',
            'biology and everyday human health literacy',
            'physics and practical engineering principles',
            'mathematics and problem-solving techniques',
            'computer security and privacy fundamentals',
            'renewable energy and energy efficiency',
            'geography, climate and Earth science',
            'critical thinking and evaluating online sources',
        ]
        try:
            enabled = (SETTINGS.get('auto_topic_learning', True) and SETTINGS.get('auto_learn', True)
                       and SETTINGS.get('online_research', True) and not SETTINGS.get('offline_only', False))
            if enabled and getattr(self, '_autolearn_running', False):
                minutes = max(5, min(1440, int(SETTINGS.get('auto_topic_interval_minutes', 5))))
                self.root.after(minutes * 60000, self._auto_topic_tick)
                return
            if enabled:
                with db() as con:
                    row = con.execute("SELECT value FROM app_meta WHERE key='auto_topic_index'").fetchone()
                    index = int(row[0]) if row and str(row[0]).isdigit() else 0
                    topic = topics[index % len(topics)]
                    con.execute("INSERT OR REPLACE INTO app_meta(key,value) VALUES('auto_topic_index',?)", (str((index + 1) % len(topics)),))
                try: self.status.configure(text='AutoLearn researching: ' + topic[:44])
                except Exception: pass
                self._autolearn_running = True
                threading.Thread(target=self._autolearn_worker, args=(topic,), daemon=True).start()
                minutes = max(5, min(1440, int(SETTINGS.get('auto_topic_interval_minutes', 5))))
                self.root.after(minutes * 60000, self._auto_topic_tick)
            else:
                self.root.after(300000, self._auto_topic_tick)
        except Exception:
            try: self.root.after(300000, self._auto_topic_tick)
            except Exception: pass

    def _autolearn_worker(self, topic):
        try:
            self._research_worker(topic, True)
        finally:
            self._autolearn_running = False

    def build_ui(self):
        # ChatGPT-inspired dark interface; implemented with Tkinter for portability.
        self.bg = "#212121"; self.panel = "#171717"; self.card = "#2f2f2f"
        self.fg = "#ececec"; self.muted = "#a8a8a8"; self.accent = "#10a37f"
        self.root.configure(bg=self.bg)
        style=ttk.Style()
        try: style.theme_use('clam')
        except Exception: pass
        style.configure('.', background=self.bg, foreground=self.fg, font=('Segoe UI', 10))
        style.configure('TFrame', background=self.bg)
        style.configure('Sidebar.TFrame', background=self.panel)
        style.configure('TLabel', background=self.bg, foreground=self.fg)
        style.configure('Sidebar.TLabel', background=self.panel, foreground=self.fg)
        style.configure('TButton', background=self.card, foreground=self.fg, padding=(9,7), borderwidth=0)
        style.map('TButton', background=[('active', '#424242')], foreground=[('active', '#ffffff')])
        style.configure('Accent.TButton', background=self.accent, foreground='#ffffff')
        style.map('Accent.TButton', background=[('active', '#0e8f70')])
        style.configure('TSeparator', background='#3b3b3b')
        self.root.title(APP_NAME); self.root.geometry('1120x760'); self.root.minsize(800,560)
        self.busy=False
        top=ttk.Frame(self.root, padding=(16,12)); top.pack(fill='x')
        ttk.Label(top,text='✳  MINI AI LITE X PERSONAL',font=('Segoe UI',17,'bold')).pack(side='left')
        ttk.Label(top,text='LOCAL AI CHAT · MEMORY · RESEARCH',font=('Segoe UI',9)).pack(side='left',padx=12,pady=(6,0))
        self.status=ttk.Label(top,text='Starting…',foreground=self.muted); self.status.pack(side='right')
        modebar=ttk.Frame(self.root,padding=(16,0,16,8)); modebar.pack(fill='x')
        ttk.Label(modebar,text='MODE',font=('Segoe UI',9,'bold')).pack(side='left',padx=(0,8))
        self.chatbot_mode_button=ttk.Button(modebar,text='Chatbot · Chat only',command=lambda:self.set_mode('Chatbot'))
        self.chatbot_mode_button.pack(side='left',padx=(0,5))
        self.llm_mode_button=ttk.Button(modebar,text='LLM · Chat + tools',command=lambda:self.set_mode('LLM'))
        self.llm_mode_button.pack(side='left',padx=(0,5))
        self.agent_mode_button=ttk.Button(modebar,text='AI Agent · Research',command=lambda:self.set_mode('Agent'))
        self.agent_mode_button.pack(side='left',padx=(0,5))
        self.live_mode_button=ttk.Button(modebar,text='🤖 Live AI',command=lambda:self.set_mode('Live'))
        self.live_mode_button.pack(side='left',padx=(0,12))
        self.emotion_label=ttk.Label(modebar,text='Mood: curious',foreground=self.muted); self.emotion_label.pack(side='left',padx=(0,12))
        self.awareness_label=ttk.Label(modebar,text='Awareness: checking app state',foreground=self.muted); self.awareness_label.pack(side='left')
        live_strip=ttk.Frame(self.root,padding=(10,3),style='Sidebar.TFrame')
        live_strip.pack(fill='x',before=modebar)
        # Animated built-in vector companion; entirely local, no image downloads.
        # The avatar's mouse/keyboard activity is a visual simulation, not OS input control.
        self.live_avatar=tk.Canvas(live_strip,width=760,height=250,bg='#0b1422',highlightthickness=1,highlightbackground='#29445f')
        self.live_avatar.pack(side='left',padx=(0,10),pady=2,fill='x',expand=True)
        c=self.live_avatar
        # Low-cost vector room: chair, desk, laptop showing a chat, keyboard and mouse.
        c.create_rectangle(0,0,760,250,fill='#0b1422',outline='',tags='room')
        c.create_rectangle(0,0,760,28,fill='#101e31',outline='',tags='room')
        c.create_text(14,14,text='MINI · LIVE COMPANION ROOM',anchor='w',fill='#8de5d0',font=('Segoe UI',9,'bold'),tags='room')
        c.create_oval(670,38,730,98,fill='#182b42',outline='#27435f',tags='room')
        c.create_oval(687,49,713,75,fill='#ff9a52',outline='#ffbf7d',tags='room')
        c.create_rectangle(0,218,760,250,fill='#111d2c',outline='',tags='room')
        # Chair and wheels stay in place while MINI sits or gets up.
        c.create_line(167,150,167,209,fill='#54718c',width=8,tags='chair')
        c.create_line(145,209,190,209,fill='#54718c',width=5,tags='chair')
        c.create_line(154,146,154,187,fill='#6685a2',width=10,tags='chair')
        c.create_rectangle(117,108,161,159,fill='#263f5a',outline='#6685a2',width=2,tags='chair')
        c.create_line(122,158,187,158,fill='#6685a2',width=8,tags='chair')
        # Desk and legs.
        c.create_rectangle(345,147,742,162,fill='#77563f',outline='#a67a56',width=2,tags='desk')
        c.create_rectangle(372,162,389,225,fill='#4b3a32',outline='',tags='desk')
        c.create_rectangle(699,162,716,225,fill='#4b3a32',outline='',tags='desk')
        # Laptop shell + chat window (static chat lines update while MINI types).
        c.create_polygon(500,78,640,78,654,145,493,145,fill='#354b60',outline='#8bb4d6',width=2,tags='laptop')
        c.create_rectangle(507,84,634,136,fill='#07101d',outline='#2d7aa1',width=1,tags='laptop')
        c.create_text(514,91,text='Human  ·  Chat',anchor='w',fill='#69d9ff',font=('Segoe UI',7,'bold'),tags='laptop')
        c.create_rectangle(514,98,592,108,fill='#173b5c',outline='',tags='screen_bubble')
        c.create_text(518,103,text='Hello MINI!',anchor='w',fill='#e8f6ff',font=('Segoe UI',6),tags='screen_text')
        c.create_rectangle(548,113,627,124,fill='#146d59',outline='',tags='screen_reply')
        c.create_text(552,118,text='Thinking…',anchor='w',fill='#eafff8',font=('Segoe UI',6),tags='screen_reply_text')
        c.create_line(489,147,656,147,fill='#9bb3c8',width=4,tags='laptop')
        # Keyboard and mouse on desk.
        c.create_rectangle(461,164,554,179,fill='#182a3e',outline='#5c89aa',width=1,tags='keyboard')
        for row in range(2):
            for col in range(12):
                x=467+col*7; y=168+row*5
                c.create_rectangle(x,y,x+4,y+2,fill='#70a6c8',outline='',tags='key')
        c.create_oval(565,164,586,181,fill='#263e55',outline='#7da6c6',width=1,tags='mouse')
        c.create_line(575,166,575,171,fill='#8de5d0',width=1,tags='mouse')
        # Robot is a single movable group. Tag parts separately for face and limb animation.
        c.create_oval(184,69,267,148,fill='#dce7ef',outline='#6d9bb9',width=2,tags=('robot','head'))
        c.create_oval(193,82,258,132,fill='#102237',outline='#102237',tags=('robot','visor'))
        c.create_oval(203,96,216,109,fill='#48cfff',outline='#48cfff',tags=('robot','eye_left'))
        c.create_oval(235,96,248,109,fill='#48cfff',outline='#48cfff',tags=('robot','eye_right'))
        c.create_arc(212,105,239,125,start=205,extent=130,style='arc',outline='#5ee7bf',width=3,tags=('robot','mouth'))
        c.create_oval(174,91,190,112,fill='#cbd9e4',outline='#6d9bb9',width=2,tags=('robot','ear_left'))
        c.create_oval(261,91,277,112,fill='#cbd9e4',outline='#6d9bb9',width=2,tags=('robot','ear_right'))
        c.create_line(224,70,224,55,fill='#b7d4e8',width=3,tags=('robot','antenna'))
        c.create_oval(218,48,230,60,fill='#ff9a52',outline='#ffd19c',tags=('robot','antenna_light'))
        c.create_oval(195,138,257,194,fill='#263e55',outline='#6d9bb9',width=2,tags=('robot','body'))
        c.create_oval(217,151,235,169,fill='#ff7043',outline='#ffad7f',tags=('robot','badge'))
        c.create_text(226,160,text='M',fill='white',font=('Segoe UI',8,'bold'),tags=('robot','badge_text'))
        c.create_line(201,149,184,168,fill='#dce7ef',width=10,capstyle='round',tags=('robot','arm_left'))
        c.create_line(251,149,269,166,fill='#dce7ef',width=10,capstyle='round',tags=('robot','arm_right'))
        c.create_line(209,188,201,211,fill='#8baac2',width=11,capstyle='round',tags=('robot','leg_left'))
        c.create_line(244,188,254,211,fill='#8baac2',width=11,capstyle='round',tags=('robot','leg_right'))
        c.create_oval(190,204,211,215,fill='#dce7ef',outline='#6d9bb9',tags=('robot','foot_left'))
        c.create_oval(247,204,268,215,fill='#dce7ef',outline='#6d9bb9',tags=('robot','foot_right'))
        c.create_text(300,49,text='ACTIVITY',anchor='w',fill='#8de5d0',font=('Segoe UI',8,'bold'),tags='room')
        c.create_text(300,66,text='Sitting at desk · ready to chat',anchor='w',fill='#d9e8f7',font=('Segoe UI',9),tags='activity_text')
        c.create_text(300,87,text='Movement is a lightweight visual simulation.',anchor='w',fill='#91a9c1',font=('Segoe UI',8),tags='room')
        self._avatar_frame=0
        self._avatar_action='idle'
        self._avatar_mood='curious'
        self._avatar_last_bob=0
        self._avatar_animating=False
        self._avatar_walk_steps=0
        self._avatar_home_x=0
        self._avatar_last_exercise=time.time()
        self._avatar_exercise_due=time.time()+180
        self._avatar_exercising=False
        self.root.after(120,self._animate_live_avatar)
        self.live_status=ttk.Label(live_strip,text='MINI · Mood: curious | Feelings: calm, curious | Thoughts: ready to help | Offline memory enabled',anchor='w',padding=(5,7),background='#18232b',foreground='#8de5d0')
        self.live_status.pack(side='left',fill='x',expand=True)
        body=ttk.Panedwindow(self.root,orient='horizontal'); body.pack(fill='both',expand=True,padx=10,pady=(0,10))
        sidewrap=ttk.Frame(body,style='Sidebar.TFrame'); body.add(sidewrap,weight=0)
        sidecanvas=tk.Canvas(sidewrap,width=235,highlightthickness=0,bg=self.panel)
        sidescroll=ttk.Scrollbar(sidewrap,orient='vertical',command=sidecanvas.yview)
        side=ttk.Frame(sidecanvas,padding=12,style='Sidebar.TFrame')
        side.bind('<Configure>',lambda e:sidecanvas.configure(scrollregion=sidecanvas.bbox('all')))
        sidecanvas.create_window((0,0),window=side,anchor='nw'); sidecanvas.configure(yscrollcommand=sidescroll.set)
        sidecanvas.pack(side='left',fill='both',expand=True); sidescroll.pack(side='right',fill='y')
        def _side_wheel(event):
            sidecanvas.yview_scroll(int(-1*(event.delta/120)), 'units'); return 'break'
        sidecanvas.bind('<MouseWheel>',_side_wheel); side.bind('<MouseWheel>',_side_wheel)
        ttk.Button(side,text='＋  New chat',command=self.new_chat).pack(fill='x',pady=(0,8))
        ttk.Label(side,text='WORKSPACE',font=('Segoe UI',9,'bold'),style='Sidebar.TLabel').pack(anchor='w',pady=(8,5))
        for label, fn in [('👁  MINI AI Eyes · Camera',self.open_eyes),('Teach AI',self.teach),('Import files',self.import_files),('AutoLearn / Compare',self.autolearn_compare),('Research multiple engines',self.research),('Offline Studio',self.offline_studio),('Search memory',self.search_knowledge),('Saved knowledge',self.show_knowledge),('Chat history',self.show_chats),('Quick tools',self.quick_tools),('Developer tools / code lab',self.developer_tools),('Notes & knowledge journal',self.note_manager),('Tasks & checklists',self.task_manager),('Flashcards / study mode',self.flashcards),('Text toolbox',self.text_toolbox),('Import a whole folder',self.import_folder),('Hardware & model fit',self.hardware_advisor),('System diagnostics',self.system_diagnostics),('MINI AI LLM status',self.setup_local_llm),('Open source URL',self.open_url)]:
            ttk.Button(side,text=label,command=fn).pack(fill='x',pady=3)
        ttk.Separator(side).pack(fill='x',pady=10)
        ttk.Label(side,text='YOUR DATA',font=('Segoe UI',9,'bold'),style='Sidebar.TLabel').pack(anchor='w',pady=(0,5))
        for label, fn in [('Export conversation',self.export_chat),('Clear chat view',self.clear_visible_chat),('Backup data',self.backup),('Restore backup',self.restore_backup),('Settings / quota',self.settings),('About & capabilities',self.about)]:
            ttk.Button(side,text=label,command=fn).pack(fill='x',pady=3)
        ttk.Label(side,text='Private by default\nNo account required\n200 GB maximum budget\nResearch only on request',justify='left',style='Sidebar.TLabel',foreground=self.muted).pack(anchor='w',pady=(16,4))
        main=ttk.Frame(body,padding=(12,8)); body.add(main,weight=1)
        # Grid-based layout guarantees the composer owns a permanent bottom row.
        # The transcript expands in row 0; the input area never competes with it.
        main.columnconfigure(0, weight=1)
        main.rowconfigure(0, weight=1)
        main.rowconfigure(1, weight=0)

        chat_area=ttk.Frame(main)
        chat_area.grid(row=0, column=0, sticky='nsew', pady=(0,8))
        chat_area.columnconfigure(0, weight=1); chat_area.rowconfigure(0, weight=1)
        self.chat=tk.Text(chat_area,wrap='word',state='disabled',font=('Segoe UI',11),padx=18,pady=18,
                          bg=self.bg,fg=self.fg,insertbackground=self.fg,relief='flat',borderwidth=0,
                          selectbackground='#3b5d55',spacing1=3,spacing3=8)
        self.chat.tag_configure('user',foreground='#ffffff',background='#343434',lmargin1=14,lmargin2=14,rmargin=14,spacing1=10,spacing3=10)
        self.chat.tag_configure('assistant',foreground=self.fg,lmargin1=14,lmargin2=14,rmargin=14,spacing1=10,spacing3=10)
        self.chat.tag_configure('role_user',foreground='#9ad9c7',font=('Segoe UI',10,'bold'))
        self.chat.tag_configure('role_ai',foreground='#10a37f',font=('Segoe UI',10,'bold'))
        sb=ttk.Scrollbar(chat_area,command=self.chat.yview); self.chat.configure(yscrollcommand=sb.set)
        self.chat.grid(row=0,column=0,sticky='nsew'); sb.grid(row=0,column=1,sticky='ns')

        compose=ttk.Frame(main,padding=(8,8,8,6),relief='solid')
        compose.grid(row=1,column=0,sticky='ew')
        compose.columnconfigure(0,weight=1)
        ttk.Label(compose,text='Message',foreground=self.muted).grid(row=0,column=0,columnspan=2,sticky='w',pady=(0,4))
        self.entry=tk.Text(compose,height=3,wrap='word',font=('Segoe UI',11),bg='#2f2f2f',fg=self.fg,
                           insertbackground=self.fg,relief='solid',borderwidth=1,padx=12,pady=9,undo=True,
                           takefocus=True)
        self.entry.grid(row=1,column=0,sticky='ew',padx=(0,10))
        def handle_enter(event):
            # Shift+Enter inserts a newline; plain Enter sends the message.
            if event.state & 0x0001: return None
            self.send(); return 'break'
        self.entry.bind('<Return>',handle_enter)
        self.send_button=ttk.Button(compose,text='Send  ↵',style='Accent.TButton',command=self.send)
        self.send_button.grid(row=1,column=1,sticky='se')
        ttk.Label(compose,text='Enter to send · Shift+Enter for a new line',foreground=self.muted).grid(row=2,column=0,columnspan=2,sticky='w',pady=(4,0))

        self.set_mode('LLM', announce=False)
        self.add_msg('MINI AI', 'Welcome to MINI AI. Choose Chatbot for chat-only conversation, LLM for conversation with utility tools, AI Agent for research, or Live AI for a companion persona with simulated moods and visible activity notes. A real local model must be installed for neural language generation; memory and emotions are software features, not human consciousness. Your chats and saved knowledge remain local.')
        self.update_awareness('ready')
        self.root.after(350, self.entry.focus_set)
        self.root.bind('<Control-Return>', lambda e: (self.send(), 'break')[1])
    def _set_avatar_action(self, action='idle', mood=None):
        """Choose a lightweight local animation; never sends OS mouse/keyboard input."""
        allowed=('idle','thinking','typing','listening','happy','concerned','researching','walking_to_desk','exercising','walking_back')
        action = action if action in allowed else 'idle'
        old=getattr(self,'_avatar_action','idle')
        self._avatar_action=action
        if mood: self._avatar_mood=str(mood).lower()
        if action in ('walking_to_desk','walking_back') and old != action:
            self._avatar_walk_steps=0
        if action == 'exercising':
            self._avatar_exercising=True
            self._avatar_last_exercise=time.time()
        elif old == 'exercising':
            self._avatar_exercising=False
            self._avatar_last_exercise=time.time()
            self._avatar_exercise_due=time.time()+180

    def _animate_live_avatar(self):
        """Render a detailed but low-CPU vector room at ~8 frames/second."""
        try:
            c=self.live_avatar
            if not c.winfo_exists(): return
            self._avatar_frame += 1
            frame=self._avatar_frame
            action=getattr(self,'_avatar_action','idle')
            mood=getattr(self,'_avatar_mood',self.emotion).lower()
            # After three minutes seated, do a short stretch/exercise only when no answer is being generated.
            now=time.time()
            if action == 'idle' and not getattr(self,'busy',False) and now >= getattr(self,'_avatar_exercise_due',now+999):
                self._set_avatar_action('exercising',mood)
                action='exercising'
                c.itemconfigure('activity_text',text='Taking a short movement break')
                self.root.after(12000, self._finish_avatar_exercise)
            # Walking is a visual journey across the room, frame-throttled by Tk's after loop.
            if action in ('walking_to_desk','walking_back'):
                dx=8 if action=='walking_to_desk' else -8
                c.move('robot',dx,0)
                self._avatar_walk_steps=getattr(self,'_avatar_walk_steps',0)+1
                c.coords('arm_left',201,149,184+(frame%2)*5,164)
                c.coords('arm_right',251,149,269-(frame%2)*5,164)
                c.coords('leg_left',209,188,201+(frame%2)*7,211)
                c.coords('leg_right',244,188,254-(frame%2)*7,211)
                c.itemconfigure('activity_text',text='Walking to the computer…' if action=='walking_to_desk' else 'Walking back to the chair…')
                if self._avatar_walk_steps >= 24:
                    if action=='walking_to_desk':
                        self._set_avatar_action('typing',mood)
                        c.itemconfigure('activity_text',text='At the laptop · typing a response')
                        c.itemconfigure('screen_reply_text',text='Typing…')
                        self.root.after(1700, self._avatar_return_to_chair_if_idle)
                    else:
                        self._set_avatar_action('idle',mood)
                        c.itemconfigure('activity_text',text='Sitting comfortably · ready to chat')
                        self._avatar_exercise_due=time.time()+180
            # Subtle bob and blinking. No large image buffers, external model or tight loops.
            bob=(1 if frame%10 in (0,1) else 0) if action in ('idle','happy','listening') else (2 if frame%4<2 else -1)
            delta=bob-getattr(self,'_avatar_last_bob',0)
            self._avatar_last_bob=bob
            for tag in ('head','visor','eye_left','eye_right','mouth','ear_left','ear_right','antenna','antenna_light'):
                c.move(tag,0,delta)
            blink = frame%43 in (0,1)
            c.itemconfigure('eye_left',state='hidden' if blink else 'normal')
            c.itemconfigure('eye_right',state='hidden' if blink else 'normal')
            eye='#48cfff'; mouth='#5ee7bf'
            if mood in ('happy','cheerful','excited'): eye='#65f2b2'; mouth='#65f2b2'
            elif mood in ('concerned','supportive','sad'): eye='#ffbd66'; mouth='#ffbd66'
            elif mood in ('focused','thoughtful'): eye='#bd9cff'; mouth='#bd9cff'
            c.itemconfigure('eye_left',fill=eye,outline=eye); c.itemconfigure('eye_right',fill=eye,outline=eye); c.itemconfigure('mouth',outline=mouth)
            if action in ('typing','thinking','researching'):
                # Hands hover over keyboard; animated key highlights and mouse pointer stay inside the scene.
                bobkey=frame%24
                c.coords('arm_left',201,149,468+(bobkey%4)*7,166+(bobkey%2)*2)
                c.coords('arm_right',251,149,525-(bobkey%4)*5,166+((bobkey+1)%2)*2)
                for item in c.find_withtag('key'):
                    c.itemconfigure(item,fill='#8de5d0' if (item+frame)%7==0 else '#47799b')
                c.itemconfigure('screen_reply_text',text=('Typing…' if frame%8<5 else '…'))
                c.coords('mouse',565+(frame%3),164,586+(frame%3),181)
                c.itemconfigure('activity_text',text='Typing a reply · moving mouse and keyboard')
            elif action=='exercising':
                jump=10 if frame%8<4 else 0
                c.move('robot',0, -jump if frame%8==0 else (jump if frame%8==4 else 0))
                c.coords('arm_left',201,149,173,126 if frame%8<4 else 143)
                c.coords('arm_right',251,149,280,126 if frame%8<4 else 143)
                c.coords('leg_left',209,188,192,209); c.coords('leg_right',244,188,262,209)
                c.itemconfigure('activity_text',text='Stretching and exercising · short break')
            elif action=='happy':
                c.coords('arm_left',201,149,178,127+(frame%3)*2); c.coords('arm_right',251,149,278,127+(frame%3)*2)
            else:
                # Resting pose holds mouse with one hand and keeps the other near the keyboard.
                c.coords('arm_left',201,149,465,170); c.coords('arm_right',251,149,574,171)
            # Decorative cursor moves only on the illustrated laptop, never the real Windows pointer.
            c.delete('scene_cursor')
            if action in ('typing','thinking','researching'):
                x=520+(frame*3)%95; y=100+(frame*2)%28
                c.create_polygon(x,y,x,y+9,x+3,y+6,x+8,y+12,fill='#ffffff',outline='#06101b',tags=('scene_cursor',))
            else:
                c.create_polygon(579,169,579,178,582,175,587,181,589,179,584,173,588,172,fill='#ffffff',outline='#06101b',tags=('scene_cursor',))
        except Exception:
            pass
        try: self.root.after(120,self._animate_live_avatar)
        except Exception: pass

    def _avatar_walk_back_after_reply(self):
        try:
            if self.mode == 'Live' and self._avatar_action in ('happy','concerned','typing') and not getattr(self,'busy',False):
                self._set_avatar_action('walking_back',self._avatar_mood)
        except Exception: pass

    def _finish_avatar_exercise(self):
        try:
            if self._avatar_action == 'exercising':
                self._set_avatar_action('walking_back',self._avatar_mood)
                self.live_avatar.itemconfigure('activity_text',text='Break finished · returning to desk')
        except Exception: pass

    def _avatar_return_to_chair_if_idle(self):
        try:
            if not getattr(self,'busy',False) and self._avatar_action == 'typing':
                self._set_avatar_action('walking_back',self._avatar_mood)
        except Exception: pass

    def _refresh_live_status(self):
        """Show transparent simulated companion state; never imply proven consciousness."""
        try:
            feelings = ', '.join(k.lower() for k, v in self.live_feelings.items() if v >= 55) or 'calm'
            self.live_status.configure(text=f"🤖 MINI · Mood: {self.emotion} | Feelings: {feelings} | Thoughts: {self.live_thought[:100]} | Offline memory: enabled")
        except Exception:
            pass

    def _live_ai_heartbeat(self):
        """Persist a small local character state while open; this is not consciousness."""
        try:
            if self.mode == 'Live' and self.live_awareness_enabled:
                cycle = [('curious', 'Thinking about what useful topic we could explore next.'),
                         ('calm', 'Reviewing conversation context and staying ready to help.'),
                         ('thoughtful', 'Considering how to make the next answer clearer.'),
                         ('cheerful', 'Ready for another conversation or learning task.')]
                idx = int(time.time() // 30) % len(cycle)
                self.emotion, self.live_thought = cycle[idx]
                self.live_feelings['Curious'] = 75 if self.emotion == 'curious' else 60
                self.live_feelings['Calm'] = 75 if self.emotion == 'calm' else 60
                self.live_feelings['Cheerful'] = 70 if self.emotion == 'cheerful' else 50
                self.live_feelings['Motivated'] = 65
                with db() as con:
                    con.execute("INSERT OR REPLACE INTO app_meta(key,value) VALUES('live_ai_mood',?)", (self.emotion,))
                    con.execute("INSERT OR REPLACE INTO app_meta(key,value) VALUES('live_ai_thought',?)", (self.live_thought,))
                    con.execute("INSERT OR REPLACE INTO app_meta(key,value) VALUES('live_ai_updated',?)", (str(int(time.time())),))
                self._refresh_live_status()
        except Exception:
            pass
        try:
            self.root.after(30000, self._live_ai_heartbeat)
        except Exception:
            pass

    def set_mode(self, mode, announce=True):
        chosen = str(mode).lower()
        self.mode = 'Chatbot' if chosen.startswith('chatbot') else ('Agent' if chosen.startswith('agent') else ('Live' if chosen.startswith('live') else 'LLM'))
        try:
            self.chatbot_mode_button.configure(style='Accent.TButton' if self.mode == 'Chatbot' else 'TButton')
            self.llm_mode_button.configure(style='Accent.TButton' if self.mode == 'LLM' else 'TButton')
            self.agent_mode_button.configure(style='Accent.TButton' if self.mode == 'Agent' else 'TButton')
            self.live_mode_button.configure(style='Accent.TButton' if self.mode == 'Live' else 'TButton')
        except Exception: pass
        if self.mode == 'Chatbot':
            self.emotion = 'curious'
            hint = 'Chatbot mode: conversation only. Research commands and app tools are disabled in this mode.'
        elif self.mode == 'LLM':
            self.emotion = 'curious'
            hint = 'LLM mode: conversation, explanations, writing, coding and utility commands.'
        elif self.mode == 'Live':
            self.emotion = 'curious'
            self.live_thought = 'Ready to respond, use saved memories, and adapt my displayed mood.'
            hint = 'Live AI mode: persistent personality, changing simulated moods, visible activity notes, offline saved memory, and optional camera vision. These are software simulations, not proof of consciousness.'
        else:
            self.emotion = 'focused'
            hint = 'AI Agent mode: research, compare sources, auto-search factual questions and use available app tools.'
        self._set_avatar_action('happy' if self.mode == 'Live' else 'idle', self.emotion)
        self.update_awareness('ready')
        self._refresh_live_status()
        if announce:
            self.add_msg('MINI AI', hint)

    def update_awareness(self, state='ready', user_text=''):
        low = (user_text or '').lower()
        if state in ('thinking', 'researching'):
            self.emotion = 'focused' if state == 'researching' or self.mode == 'Agent' else 'thoughtful'
        elif any(w in low for w in ('thank', 'great', 'awesome', 'yay')):
            self.emotion = 'cheerful'
        elif any(w in low for w in ('sad', 'upset', 'worried', 'frustrated', 'angry')):
            self.emotion = 'supportive'
        elif any(w in low for w in ('why', 'how', 'what', 'explain', 'learn')):
            self.emotion = 'curious'
        elif state == 'error':
            self.emotion = 'concerned'
        else:
            self.emotion = 'calm'
        try:
            self.emotion_label.configure(text='Expression: ' + self.emotion)
            configured = 'local model connected' if self.llm_is_configured() else 'local model not installed'
            task = 'working' if state in ('thinking','researching') else 'ready'
            self.awareness_label.configure(text=f'App state: {task} · {configured} · {self.mode} mode')
            self._refresh_live_status()
        except Exception: pass

    def add_msg(self,role,text,save=True):
        self.chat.configure(state='normal')
        is_user = role.lower() == 'you'
        block = 'user' if is_user else 'assistant'
        role_tag = 'role_user' if is_user else 'role_ai'
        self.chat.insert('end', role + '\n', (role_tag,))
        self.chat.insert('end', str(text) + '\n\n', (block,))
        self.chat.see('end'); self.chat.configure(state='disabled')
        if save and SETTINGS.get('auto_save_chats', True):
            with db() as con: con.execute('INSERT INTO chats(role,body,created) VALUES(?,?,?)',(role,pack_chat_body(text),stamp()))
            update_chat_zip()
    def send(self):
        q=self.entry.get('1.0','end').strip()
        if not q:return
        self.entry.delete('1.0','end'); self.add_msg('You',q); self.update_awareness('thinking', q)
        # Live AI adds a consistent companion voice and visible simulated state.
        # It does not claim that these software states are genuine consciousness.
        if self.mode == 'Live':
            self._set_avatar_action('walking_to_desk', self.emotion)
            try: self.live_avatar.itemconfigure('screen_reply_text', text='Incoming message…')
            except Exception: pass
            self.root.after(2100, lambda: self._set_avatar_action('typing', self.emotion) if self.mode == 'Live' and self._avatar_action == 'walking_to_desk' else None)
            self.live_thought = 'Considering your message and the relevant saved context.'
            self._refresh_live_status()
            mood_prompt = (
                'You are MINI, a friendly Reddit-style robot companion with a consistent, kind, curious personality. '
                'Respond naturally and personably, adapting to the user without claiming to be human or literally conscious. '
                'You may describe simulated moods as character states, not genuine human feelings. Keep the answer useful and conversational. '
                'Current displayed mood: ' + self.emotion + '. Activity note: ' + self.live_thought + '\nUser message: ' + q
            )
            self.ask_llm(mood_prompt)
            return
        # Chatbot mode is deliberately chat-only: it cannot launch URLs, research,
        # write to memory, calculate via tools, or invoke other app actions.
        if self.mode == 'Chatbot':
            self.ask_llm(q)
            return
        if q.lower().startswith(('remember that ', 'learn that ', 'teach yourself that ')):
            body=q.split(' ',2)[-1]; ok,msg=add_knowledge('User-taught note',body,'user chat')
            self.add_msg('MINI AI',msg); self.refresh_status(); return
        
        if q.lower().startswith(('calculate ', 'calc ')):
            expr=q.split(' ',1)[1]
            self.add_msg('MINI AI',self.safe_calculate(expr)); self.refresh_status(); return
        if q.lower().startswith('open url '):
            url=q[9:].strip()
            if url.startswith(('https://','http://')):
                webbrowser.open(url); self.add_msg('MINI AI','Opened the requested URL in your default browser.')
            else: self.add_msg('MINI AI','For safety, use a URL beginning with https:// or http://.')
            return
        # Keep explicit research commands in the research workflow; route ordinary conversation to a real LLM when configured.
        if re.match(r'^(research|look up|search for|learn about)\b', q.strip(), re.I):
            response=self.answer_chat(q)
            if response is not None and response != '__already_researching__': self.add_msg('MINI AI',response)
            self.refresh_status(); return
        # Automatically search ordinary factual questions when online search is enabled.
        # Offline-only mode never attempts network access; local LLM and local tools remain usable.
        if (SETTINGS.get('auto_search_questions', False)
                and SETTINGS.get('online_research', True)
                and not SETTINGS.get('offline_only', False)
                and self.should_auto_search(q)):
            self.update_awareness('researching', q)
            self.add_msg('MINI AI', 'Auto Search started. I’m checking online sources automatically; you do not need to open the Research menu. You can disable this in Settings or enable Offline-only mode.')
            self.busy=True
            # Keep the composer enabled while automatic research runs.
            threading.Thread(target=self._auto_search_worker, args=(q,), daemon=True).start()
            return
        # Always route ordinary chat through the bundled MINI AI LLM engine.
        # Do not fall back to canned/rule-based answers just because no external
        # model server or large GGUF model is installed. Explicit research and
        # utility commands above retain their dedicated workflows.
        self.ask_llm(q)
        return

    @staticmethod
    def should_auto_search(q):
        text=re.sub(r'\s+',' ',str(q)).strip().lower()
        if len(text)<12 or len(text.split())<3: return False
        # Keep conversational questions and requests about MINI AI in the local chat.
        if re.match(r'^(hi|hello|hey|thanks|thank you|good morning|good night|remember that|learn that|teach yourself that|calculate|calc|open url|write|draft|help me|can you|could you|please|what can you do|how are you|tell me a joke)\b',text): return False
        if re.search(r'\b(you|your|mini ai|my code|my project|this code|the code)\b',text) and not re.search(r'\b(latest|current|today|news|weather|price|release date)\b',text): return False
        # Automatic search is reserved for factual lookup and current information.
        patterns=(r'\bwhat is\b',r'\bwhat are\b',r'\bwho is\b',r'\bwho was\b',r'\bwhen did\b',r'\bwhere is\b',r'\bhow does\b',r'\bhow do\b',r'\bwhy does\b',r'\bwhy is\b',r'\bcompare\b',r'\bversus\b',r'\bvs\.?\b',r'\blatest\b',r'\bcurrent\b',r'\btoday\b',r'\bnews\b',r'\bweather\b',r'\bprice\b',r'\brelease date\b',r'\bupdated\b',r'\blook up\b',r'\bsearch for\b')
        return any(re.search(p,text) for p in patterns)

    def _auto_search_worker(self, question):
        try:
            # Reuse the existing multi-engine research pipeline; it also AutoLearns source-linked notes.
            self._research_worker(question)
        finally:
            def finish():
                self.busy=False
                try: self.send_button.configure(state='normal')
                except Exception: pass
                self.update_awareness('ready')
                self.refresh_status()
            try: self.root.after(0, finish)
            except Exception: pass

    def llm_is_configured(self):
        base=str(SETTINGS.get('llm_base_url','')).strip()
        model=str(SETTINGS.get('llm_model','mini-ai-from-scratch')).strip()
        runtime=APP_DIR/'runtime'/'koboldcpp_oldcpu.exe'
        model_file=APP_DIR/'models'/str(SETTINGS.get('llm_model_file','mini_ai_llm_model.json'))
        try:
            with runtime.open('rb') as f: runtime_ok = runtime.stat().st_size > 5_000_000 and f.read(2) == b'MZ'
        except OSError: runtime_ok=False
        try:
            with model_file.open('rb') as f: model_ok = model_file.stat().st_size > 250_000_000 and f.read(4) == b'GGUF'
        except OSError: model_ok=False
        return bool(base.startswith(('http://127.0.0.1','http://localhost')) and model and runtime_ok and model_ok)

    def start_local_llm_if_installed(self):
        # Keep optional online-provider settings intact; local inference remains the fallback.
        # Prefer the smaller model on the target 4 GB E6500 when it is already installed.
        micro_file=APP_DIR/'models'/'mini_ai_llm_model.json'
        try: ram_for_model=detect_system_ram_gb()
        except Exception: ram_for_model=4.0
        if ram_for_model <= 4.5 and micro_file.exists():
            SETTINGS['llm_model']='mini-ai-from-scratch'; SETTINGS['llm_model_file']=micro_file.name
        else:
            SETTINGS['llm_model']=str(SETTINGS.get('llm_model','mini-ai-from-scratch'))
            SETTINGS['llm_model_file']=str(SETTINGS.get('llm_model_file','mini_ai_llm_model.json'))
        try: SETTINGS_PATH.write_text(json.dumps(SETTINGS, indent=2), encoding='utf-8')
        except Exception: pass
        base='internal://mini-ai-llm'
        runtime=APP_DIR/'runtime'/'koboldcpp_oldcpu.exe'
        model_file=APP_DIR/'models'/str(SETTINGS.get('llm_model_file','mini_ai_llm_model.json'))
        if not self.llm_is_configured():
            try: self.status.configure(text='Local AI model missing or damaged · use MINI AI LLM status')
            except Exception: pass
            return
        try:
            # Verify that an existing server is serving the configured model. Older
            # versions could accept any /models response and silently attach to a stale
            # server loading a different model (e.g. 3B while settings select 0.5B).
            try:
                with urllib.request.urlopen(str(SETTINGS.get('llm_base_url','internal://mini-ai-llm')).rstrip('/')+'/models',timeout=2) as _resp:
                    model_data=json.loads(_resp.read().decode('utf-8','replace'))
                ids=[str(item.get('id','')).lower() for item in model_data.get('data',[]) if isinstance(item,dict)]
                expected='0.5b' if '0.5b' in str(SETTINGS.get('llm_model_file','')).lower() else str(SETTINGS.get('llm_model','')).lower()
                matched=any(('0.5b' in mid) if expected=='0.5b' else (expected in mid or not expected) for mid in ids)
                if matched:
                    self.status.configure(text='Local model server connected · model ID matches settings')
                    return
                # The server answers but advertises a different model. Stop stale
                # bundled runtime processes so the configured model can be loaded.
                try:
                    subprocess.run(['taskkill','/F','/IM','koboldcpp_oldcpu.exe'],capture_output=True,timeout=8,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                except Exception: pass
                time.sleep(2)
            except Exception: pass
            log=APP_DIR/'llm_runtime.log'
            handle=open(log,'ab')
            import os as _os
            try:
                ram_gb=detect_system_ram_gb()
            except Exception: ram_gb=4
            try:
                # Keep to two CPU threads on this older laptop class; extra worker threads can cause contention and slow the UI.
                cpu_threads=max(1,min(2,(os.cpu_count() or 2)))
            except Exception: cpu_threads=2
            context_size=1024 if ram_gb>=8 else 512
            # Explicit CPU mode and a small context help old Core-2-era systems.
            args=[str(runtime),'--model',str(model_file),'--port','5001','--contextsize',str(context_size),'--threads',str(cpu_threads),'--usecpu','--quiet']
            flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
            self.llm_process=subprocess.Popen(args,cwd=str(runtime.parent),stdout=handle,stderr=handle,creationflags=flags)
            try: handle.close()
            except Exception: pass
            self.status.configure(text='Starting local AI… loading the model can take a minute')
            def wait_for_server():
                endpoint='internal://mini-ai-llm/models'
                for _ in range(90):
                    if self.llm_process is not None and self.llm_process.poll() is not None:
                        break
                    try:
                        with urllib.request.urlopen(endpoint,timeout=1) as response:
                            if response.status == 200:
                                self.root.after(0,lambda: self.status.configure(text='Local language model connected'))
                                self.root.after(0,self.refresh_status)
                                return
                    except Exception: pass
                    time.sleep(1)
                try:
                    log_text=(APP_DIR/'llm_runtime.log').read_text(encoding='utf-8',errors='replace')[-2500:]
                except Exception: log_text='No runtime log was created.'
                self.root.after(0,lambda: self.status.configure(text='Local AI failed to start · open llm_runtime.log'))
                try:
                    with open(APP_DIR/'llm_start_error.txt','w',encoding='utf-8') as f: f.write('Local model server did not become ready.\n\n'+log_text)
                except Exception: pass
            threading.Thread(target=wait_for_server,daemon=True).start()
        except Exception as e:
            try:
                with open(APP_DIR/'llm_start_error.txt','w',encoding='utf-8') as f: f.write(repr(e))
            except Exception: pass
            self.status.configure(text='Local model failed to start; see llm_start_error.txt')

    def setup_local_llm(self):
        script=Path(__file__).with_name('Setup_Local_LLM.bat')
        if not script.exists():
            messagebox.showerror('Setup missing','Setup_Local_LLM.bat is missing from the MINI AI folder. Re-extract the complete ZIP.'); return
        try:
            os.startfile(str(script))
            messagebox.showinfo('Local language model setup','A setup window has opened. This edition installs the single MINI AI AutoLearn LLM default (Qwen 2.5 0.5B local engine). Internet is needed for the first download. Restart MINI AI after setup finishes.')
        except Exception as e: messagebox.showerror('Could not start setup',str(e))

    def ask_llm(self, prompt):
        # Keep the composer usable and queue messages in order on slow CPUs.
        with self.llm_queue_lock:
            self.llm_pending.append(str(prompt))
            start_worker = not self.llm_queue_active
            if start_worker:
                self.llm_queue_active = True
        self.busy=True
        try: self.status.configure(text='Queued for local AI…' if not start_worker else 'Thinking with local AI…')
        except Exception: pass
        if start_worker:
            threading.Thread(target=self._llm_queue_worker,daemon=True).start()

    def _llm_queue_worker(self):
        while True:
            with self.llm_queue_lock:
                if not self.llm_pending:
                    self.llm_queue_active=False
                    break
                prompt=self.llm_pending.pop(0)
            # One inference at a time avoids competing model requests on the E6500.
            self._llm_worker(prompt)

    def _llm_worker(self, prompt):
        try:
            answer = None
            online_error = None
            if SETTINGS.get('online_ai_enabled') and not SETTINGS.get('offline_only'):
                try:
                    answer = self._online_ai_response(prompt)
                except Exception as e:
                    online_error = str(e)
            if not answer:
                from mini_ai_llm import respond
                answer = respond(prompt, getattr(self, 'mode', 'Chat'))
                if online_error:
                    answer = str(answer) + "\\n\\n[Offline fallback: online AI was unavailable (" + online_error[:220] + ").]"
            self.root.after(0, lambda a=answer: self._finish_llm(a, None))
        except Exception as e:
            msg = 'MINI AI local fallback error: ' + str(e)
            self.root.after(0, lambda m=msg: self._finish_llm(None, m))

    def _online_ai_response(self, prompt):
        # Optional OpenAI-compatible Chat Completions endpoint; never required for offline use.
        base = str(SETTINGS.get('llm_base_url', '')).strip().rstrip('/')
        model = str(SETTINGS.get('online_ai_model', SETTINGS.get('llm_model', ''))).strip()
        key = str(SETTINGS.get('llm_api_key', '')).strip()
        if not base.startswith('https://') or not key or not model:
            raise RuntimeError('Online AI needs an HTTPS endpoint, model name, and API key in Settings.')
        if base.endswith('/chat/completions'):
            endpoint = base
        elif base.endswith('/v1'):
            endpoint = base + '/chat/completions'
        else:
            endpoint = base + '/v1/chat/completions'
        persona = str(SETTINGS.get('persona', 'Friendly, thoughtful, honest'))
        payload = {'model': model, 'messages': [
            {'role': 'system', 'content': 'You are MINI AI LITE X, a helpful, honest assistant. Style: ' + persona + '. Be accurate and acknowledge uncertainty.'},
            {'role': 'user', 'content': str(prompt)}
        ], 'temperature': 0.5}
        req = urllib.request.Request(endpoint, data=json.dumps(payload).encode('utf-8'),
            headers={'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key}, method='POST')
        timeout = max(5, min(120, int(SETTINGS.get('llm_timeout', 45))))
        with urllib.request.urlopen(req, timeout=timeout) as response:
            result = json.loads(response.read(4_000_000).decode('utf-8', 'replace'))
        choices = result.get('choices') or []
        answer = choices[0].get('message', {}).get('content') if choices else None
        if isinstance(answer, list):
            answer = '\\n'.join(str(part.get('text','')) for part in answer if isinstance(part,dict))
        answer = str(answer or '').strip()
        if not answer:
            raise RuntimeError('The online provider returned no answer.')
        return answer

    def _finish_llm(self, answer, error):
        with self.llm_queue_lock:
            more_work = bool(self.llm_pending) or self.llm_queue_active
        self.busy=more_work
        try: self.send_button.configure(state='normal')
        except Exception: pass
        self.add_msg('MINI AI', answer if answer else error)
        if getattr(self, 'mode', '') == 'Live':
            reaction = 'concerned' if error else ('happy' if answer else 'idle')
            self._set_avatar_action(reaction, 'concerned' if error else getattr(self, 'emotion', 'cheerful'))
            if not error:
                self.root.after(2200, self._avatar_walk_back_after_reply)
        else:
            self._set_avatar_action('idle', getattr(self, 'emotion', 'calm'))
        self.status.configure(text=('Processing queued messages…' if more_work else ('Language model ready' if answer else 'Language model unavailable')))
        self.update_awareness('thinking' if more_work else ('ready' if answer else 'error'))
        self.refresh_status()

    def answer_chat(self, q):
        text=q.strip(); low=text.lower().strip(' .!?')
        if re.fullmatch(r'(hi|hello|hey|hiya|good morning|good afternoon|good evening|howdy)( there)?',low):
            return 'Hey! 😊 I’m here with you. What would you like to talk about or work on?'
        if re.search(r'\b(how are you|how are things|how do you feel)\b',low):
            return 'I’m running and ready to help. I don’t have human feelings or experiences, but I can keep the conversation warm and thoughtful. How are you doing?'
        if re.fullmatch(r'(thanks|thank you|thx|cheers)( so much)?',low):
            return 'You’re welcome! 😊 Anything else you’d like me to help with?'
        if re.search(r'\b(what is your name|who are you|are you a human|are you real)\b',low):
            return 'I’m MINI AI, your private assistant. I’m software, not a human. If the local model is installed or a compatible API is configured, I can generate natural-language responses; otherwise I use limited scripted replies and saved knowledge.'
        if re.search(r'\b(remember|learn|teach yourself)\b',low) and len(text.split())>3:
            return 'I can save a note for future chats. Start your message with “remember that …” or use **Teach AI** so you can review exactly what gets stored.'
        if low.startswith(('research ', 'look up ', 'search for ', 'learn about ')):
            topic=re.sub(r'^(research|look up|search for|learn about)\s+','',text,flags=re.I).strip()
            if topic and SETTINGS.get('online_research',True) and not SETTINGS.get('offline_only',False):
                self.update_awareness('researching', q)
                self.add_msg('MINI AI',f'I’ll research “{topic}” across the enabled search engines, read accessible pages and available YouTube captions, then compare what I find. I’ll keep sources attached and won’t label a claim certain just because sources repeat it.')
                threading.Thread(target=self._research_worker,args=(topic,),daemon=True).start()
                return '__already_researching__'
            return 'Online research is currently disabled. You can turn it on in Settings, or ask me about saved local knowledge.'
        if re.search(r'\b(what do you know about|tell me about|explain)\b',low) and not self.llm_is_configured():
            matches=retrieve(text,3)
            if matches: return answer_local(text)
            return 'I do not have the local language model installed yet, and there is no relevant saved knowledge for that question. Choose “MINI AI LLM” or use “research ' + re.sub(r'^(what do you know about|tell me about|explain)\s*','',text,flags=re.I) + '” to gather sources online.'
        # Local fallback keeps the chatbot useful even when no language model is installed.
        # It is deliberately transparent: it does not pretend this rule-based fallback is an LLM.
        matches=retrieve(text,3)
        if matches and re.search(r'\b(what|how|why|explain|tell me|remember|project|code|arduino|weather)\b',low):
            return answer_local(text)
        if re.search(r'\b(help|what can you do|features|offline|work offline)\b',low):
            return ('I can help locally with saved knowledge, taught notes, chat history, calculations, text tools, code templates, checklists, flashcards, file imports and camera object labels. '
                    'For open-ended conversation and stronger reasoning, the local language model must be installed once using **MINI AI LLM status**; that setup downloads it automatically without asking you to enter a model URL. '
                    'After installation, text chat can run offline. Camera category detection is local too, but detailed free-form image understanding is limited without a separate vision model.')
        if re.search(r'\b(what can i make|make with|project ideas|build something)\b',low):
            return ('Tell me what parts or materials you have, and I can suggest a safe project. You can also open **MINI AI Eyes · Camera** and press **What can I make?** to base suggestions on detected or taught object labels.')
        if re.search(r'\b(arduino|uno|sensor|wiring|sketch|compile|error)\b',low):
            return ('I can help with Arduino wiring and code. Include the board, exact modules, pin connections and any compiler error. I will check the design against the details you provide; if the local language model is not installed, responses are limited to local tools and saved knowledge.')
        if re.search(r'\b(write|draft|rewrite|summari[sz]e|plan|brainstorm|explain|how do i|how to)\b',low):
            return ('I can help structure this, but the local language model is not available right now, so I cannot generate a full model-quality answer. To enable the actual offline chatbot, choose **MINI AI LLM status** in the sidebar. The installer automatically selects a small model for your 4 GB Dell and downloads it; no model URL or API key is required. If setup fails, open **Check Local AI** for the error report.')
        return ('I received your message, but the full local language model is not currently available. I can still use saved knowledge and built-in tools. To make open-ended chat work offline, click **MINI AI LLM status** in the sidebar; MINI AI selects and downloads a suitable local model automatically, with no URL or API key to enter.')
    def new_chat(self):
        self.chat.configure(state='normal'); self.chat.delete('1.0','end'); self.chat.configure(state='disabled')
        self.add_msg('MINI AI','New conversation. Your previous conversation remains in Saved chats.')
    def teach(self):
        title=simpledialog.askstring('Teach AI','What should this lesson be called?',parent=self.root)
        if title is None:return
        body=simpledialog.askstring('Teach AI','Enter the fact, instructions, or lesson to save:',parent=self.root)
        if body is None:return
        ok,msg=add_knowledge(title,body,'user lesson')
        if ok:
            with db() as con: con.execute('INSERT INTO lessons(title,body,created) VALUES(?,?,?)',(title,body,stamp()))
        messagebox.showinfo('Teach AI',msg); self.refresh_status()
    def import_files(self):
        paths=filedialog.askopenfilenames(title='Import readable text files',filetypes=[('Readable documents','*.txt *.md *.html *.htm *.csv *.json *.py *.ino *.log *.pdf *.docx'),('All files','*.*')])
        if not paths:return
        count=0; errors=[]
        for path in paths:
            try:
                p=Path(path)
                if p.suffix.lower()=='.pdf':
                    try:
                        from pypdf import PdfReader
                        raw='\n'.join((page.extract_text() or '') for page in PdfReader(str(p)).pages)
                    except Exception as e: raise RuntimeError('PDF import needs the optional pypdf package (pip install pypdf): '+str(e))
                elif p.suffix.lower()=='.docx':
                    try:
                        from docx import Document
                        raw='\n'.join(par.text for par in Document(str(p)).paragraphs)
                    except Exception as e: raise RuntimeError('Word import needs optional python-docx (pip install python-docx): '+str(e))
                else: raw=p.read_text(encoding='utf-8',errors='replace')
                if p.suffix.lower() in ('.html','.htm'):
                    raw=re.sub(r'(?is)<(script|style).*?>.*?</\1>',' ',raw); raw=re.sub(r'(?s)<[^>]+>',' ',raw); raw=re.sub(r'\s+',' ',raw)
                
                max_mb = float(SETTINGS.get('max_import_mb',25))
                if len(raw.encode('utf-8')) > max_mb*1024*1024: raise ValueError(f'File exceeds configured import limit ({max_mb:g} MB).')
                ok,msg=add_knowledge(p.name,raw,str(p)) if SETTINGS.get('auto_learn_imports',True) else (False,'Import learning disabled in Settings.'); count += int(ok)
                if not ok: errors.append(p.name+': '+msg)
            except Exception as e: errors.append(Path(path).name+': '+str(e))
        messagebox.showinfo('Import complete',f'Saved {count} file(s).\n' + ('\n'.join(errors[:8]) if errors else '')); self.refresh_status()
    def export_chat(self):
        text = self.chat.get('1.0', 'end').strip()
        if not text:
            messagebox.showinfo('Export conversation', 'There is no conversation to export.'); return
        dest = filedialog.asksaveasfilename(title='Export conversation', defaultextension='.txt', filetypes=[('Text file','*.txt'),('Markdown file','*.md')], initialfile='MINI_AI_conversation.txt')
        if not dest: return
        try:
            Path(dest).write_text(text, encoding='utf-8')
            messagebox.showinfo('Export complete', 'Conversation exported to:\n' + dest)
        except Exception as e: messagebox.showerror('Export failed', str(e))
    def search_knowledge(self):
        q = simpledialog.askstring('Search private memory', 'Search saved knowledge for:', parent=self.root)
        if not q: return
        rows = retrieve(q, 20)
        win = tk.Toplevel(self.root); win.title('Memory search results'); win.geometry('760x480'); win.configure(bg=self.bg)
        box = tk.Text(win, wrap='word', bg=self.bg, fg=self.fg, padx=12, pady=12)
        box.pack(fill='both', expand=True)
        if not rows: box.insert('end', 'No matching saved knowledge found.')
        for r in rows:
            snippet = re.sub(r'\s+', ' ', r[2])[:1200]
            box.insert('end', f'{r[1]}\nSource: {r[3]} · saved {r[4]}\n{snippet}\n\n' + '-'*50 + '\n\n')
        box.configure(state='disabled')
    def clear_visible_chat(self):
        if messagebox.askyesno('Clear conversation view', 'Clear the current chat view? Saved chat records will remain in Chat history.'):
            self.chat.configure(state='normal'); self.chat.delete('1.0','end'); self.chat.configure(state='disabled')

    def research(self):
        if SETTINGS.get('offline_only',False) or not SETTINGS.get('online_research',True): messagebox.showwarning('Research paused','Online research is disabled in Settings.'); return
        q=simpledialog.askstring('Online research','What topic should I search for? (Internet access required)',parent=self.root)
        if not q:return
        self.add_msg('You',f'Research request: {q}')
        self.add_msg('MINI AI','Trying a lightweight DuckDuckGo HTML search. Search results can be blocked by the network; I will only save results if the page returns readable content.')
        threading.Thread(target=self._research_worker,args=(q,),daemon=True).start()
    def _research_worker(self,q,background=False):
        timeout=max(3,min(60,int(SETTINGS.get('research_timeout',12))))
        limit=max(1,min(20,int(SETTINGS.get('max_results',8))))
        engines=[]
        if SETTINGS.get('search_duckduckgo',True): engines.append('DuckDuckGo')
        if SETTINGS.get('search_bing',True): engines.append('Bing')
        if SETTINGS.get('search_mojeek',True): engines.append('Mojeek')
        if not engines:
            result='No search engines are enabled. Open Settings and enable at least one engine.'
            if background:
                self.root.after(0,lambda: self.status.configure(text=result))
            else:
                self.root.after(0,lambda:self.add_msg('MINI AI',result))
            return
        collected=[]; failures=[]
        # Search engines run concurrently so a slow endpoint does not block the others.
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=len(engines)) as pool:
                futures={pool.submit(_search_one,e,q,timeout,limit):e for e in engines}
                for future in concurrent.futures.as_completed(futures,timeout=timeout+4):
                    engine=futures[future]
                    try: hits=future.result(); collected.extend(hits)
                    except Exception as e: failures.append(f'{engine}: {type(e).__name__}: {e}')
        except Exception as e: failures.append('Search coordination: '+str(e))
        # De-duplicate results across engines, retaining all engine names for provenance.
        merged={}
        for title,url,engine in collected:
            key=url.split('#')[0]
            if key not in merged: merged[key]={'title':title,'url':key,'engines':[engine]}
            elif engine not in merged[key]['engines']: merged[key]['engines'].append(engine)
        hits=list(merged.values())[:limit]
        if not hits:
            detail='\n'.join(failures) if failures else 'Search engines returned no matching results.'
            result=('AutoLearn cycle could not retrieve readable results for: '+q+'. No new knowledge was saved. ' + detail[:500] if background else 'No readable search results were returned by the enabled engines. This may be caused by network filtering, endpoint changes, or a connection problem.\n\n'+detail+'\n\nYour local knowledge has not been changed.')
        else:
            # Read actual result pages (not just search-result titles) when enabled.
            page_limit=max(0,min(10,int(SETTINGS.get('max_pages_to_read',5)))) if SETTINGS.get('fetch_full_pages',True) else 0
            pages=[]
            for item in hits[:page_limit]:
                try:
                    title=''; body=''; is_youtube='youtube.com' in (urllib.parse.urlparse(item['url']).hostname or '') or 'youtu.be' in (urllib.parse.urlparse(item['url']).hostname or '')
                    if is_youtube and SETTINGS.get('youtube_transcripts',True):
                        title,body=_youtube_transcript(item['url'],timeout=timeout)
                        if body: title= item['title']+' — available caption transcript'
                    if not body: title,body=_fetch_text(item['url'],timeout=timeout)
                    if body and len(body)>180:
                        pages.append({'title':title or item['title'],'url':item['url'],'body':body,'engines':item['engines'],'kind':'video transcript' if is_youtube and 'transcript' in (title or '').lower() else 'webpage'})
                except Exception as e:
                    failures.append(f"Page/transcript read failed ({item['url']}): {type(e).__name__}: {e}")
            saved=0
            if SETTINGS.get('auto_learn',SETTINGS.get('auto_research',False)):
                for page in pages:
                    summary,summary_method=summarize_with_local_model(q,page['body'])
                    quality,signals=source_quality(page['url'],page['engines'],page['body'])
                    body=(f"Research question: {q}\nSource type: {page.get('kind','webpage')}\nSearch engines: {', '.join(page['engines'])}\nURL: {page['url']}\nRetrieved: {stamp()}\nPreliminary source signals: {signals} (heuristic only, not a truth score)\n\nMINI AI SUMMARY IN ITS OWN WORDS ({summary_method}):\n{summary}\n\nREADABLE SOURCE TEXT (truncated):\n"+page['body'][:8000 if background else 45000])
                    ok,_=add_knowledge(page['title'],body,page['url'])
                    if ok: saved+=1
                if not pages:
                    # Store references only when AutoLearn is explicitly enabled; label them clearly.
                    for item in hits:
                        body=f"Research question: {q}\nSearch engines: {', '.join(item['engines'])}\nURL: {item['url']}\nEvidence: search result reference only; full page text was unavailable.\nRetrieved: {stamp()}"
                        ok,_=add_knowledge(item['title'],body,item['url']); saved+=int(ok)
            out=[f'Multi-engine research for: {q}', '', f'Enabled engines: {", ".join(engines)}',f'Unique search results: {len(hits)}',f'Pages/videos with readable text or captions: {len(pages)}']
            if pages:
                out += ['', 'SOURCE REVIEW (heuristic signals only; not a verdict that a source is correct):']
                reviewed=[]
                for page in pages:
                    score,signals=source_quality(page['url'],page['engines'],page['body'])
                    reviewed.append((score,page,signals))
                reviewed.sort(key=lambda x:x[0],reverse=True)
                for rank,(score,page,signals) in enumerate(reviewed,1):
                    out.append(f"{rank}. {page['title']} — review signals: {signals or 'none'}; heuristic points {score}. Verify original evidence and author/date.")
                out += ['', 'READABLE SOURCE EXTRACTS (short excerpts; check original pages for context):']
                for i,page in enumerate(pages,1):
                    snippet=re.sub(r'\s+',' ',page['body']).strip()[:1800]
                    quality,signals=source_quality(page['url'],page['engines'],page['body'])
                    summary,summary_method=summarize_with_local_model(q,page['body'])
                    out.append(f"\n{i}. {page['title']} ({page.get('kind','webpage')})\nURL: {page['url']}\nFound via: {', '.join(page['engines'])}\nSource signals: {signals} (heuristic, not proof)\nMINI AI relevance summary ({summary_method}): {summary}\nExcerpt: {snippet}")
            out += ['', 'SEARCH RESULTS:']
            for i,item in enumerate(hits,1): out.append(f"{i}. {item['title']}\n   {item['url']}\n   Search engines: {', '.join(item['engines'])}")
            if SETTINGS.get('auto_compare',True):
                # Compare body wording across fetched pages; this flags similarities and possible disagreements only.
                if len(pages)>=2:
                    token_sets=[tokenize(p['body'][:12000]) for p in pages]
                    comparisons=[]
                    for i in range(len(pages)):
                        for j in range(i+1,len(pages)):
                            common=token_sets[i]&token_sets[j]
                            common={w for w in common if len(w)>3 and w not in {'that','this','with','from','have','their','about','which','when','what','will','into','than','also','more','some','your','they','them','were','been','being','there','where','could','would','should','other','using','used','such','each','only','very','over','under'}}
                            if len(common)>=4: comparisons.append((len(common),i,j,sorted(common)[:8]))
                    comparisons.sort(reverse=True)
                    out += ['', 'AUTO-COMPARE (text overlap is a clue, not proof of correctness):']
                    if comparisons:
                        for score,i,j,words in comparisons[:5]: out.append(f"• {pages[i]['title']} ↔ {pages[j]['title']} — shared terms: {', '.join(words)}")
                    else: out.append('• No strong wording overlap was detected between the readable pages.')
                    # Surface obvious numerical and negation differences for human review.
                    flags=[]
                    for i in range(len(pages)):
                        for j in range(i+1,len(pages)):
                            nums_i=set(re.findall(r'\b\d+(?:[.,]\d+)?%?\b',pages[i]['body'][:18000]))
                            nums_j=set(re.findall(r'\b\d+(?:[.,]\d+)?%?\b',pages[j]['body'][:18000]))
                            neg_i=bool(re.search(r'\b(not|no|never|cannot|isn.t|doesn.t)\b',pages[i]['body'][:18000],re.I))
                            neg_j=bool(re.search(r'\b(not|no|never|cannot|isn.t|doesn.t)\b',pages[j]['body'][:18000],re.I))
                            if (nums_i and nums_j and nums_i != nums_j) or neg_i != neg_j:
                                flags.append(f"• Check possible difference: {pages[i]['title']} ↔ {pages[j]['title']} (different number sets or negation signals). Read the context before deciding whether they conflict.")
                    if flags: out += ['', 'POSSIBLE DIFFERENCES TO REVIEW:'] + flags[:5]
                else: out += ['', 'AUTO-COMPARE: Not enough readable article pages to compare their contents.']
            out += ['', f'AutoLearn: saved {saved} item(s).' if SETTINGS.get('auto_learn',SETTINGS.get('auto_research',False)) else 'AutoLearn is paused; no research was saved automatically.']
            out += ['', 'Reliability note: I cannot declare a claim correct just because several pages repeat it. Check source quality, publication date, original evidence, and whether sources are independent.']
            if failures: out += ['', 'Some sources failed:', *['• '+f for f in failures[:6]]]
            result=('AutoLearn topic complete: '+q+'. Saved '+str(saved)+' new source-linked item(s).' if background else '\n'.join(out))
        if background:
            self.root.after(0,lambda: (self.refresh_status(), self.status.configure(text=result[:90])))
        else:
            self.root.after(0,lambda:self.add_msg('MINI AI',result))
            self.root.after(0,self.refresh_status)

    def autolearn_compare(self):
        win=tk.Toplevel(self.root); win.title('AutoLearn & Auto Compare'); win.geometry('620x440'); win.configure(bg=self.bg)
        ttk.Label(win,text='Controlled learning',font=('Segoe UI',15,'bold')).pack(anchor='w',padx=16,pady=(16,8))
        ttk.Label(win,text='When enabled, AutoLearn stores source-linked summaries and excerpts during research. YouTube captions are attempted only when publicly accessible. Auto Compare checks content overlap and source signals; it cannot prove truth. No hidden browsing or login is used.',wraplength=570).pack(anchor='w',padx=16,pady=4)
        learn=tk.BooleanVar(value=SETTINGS.get('auto_learn',SETTINGS.get('auto_research',False)))
        compare=tk.BooleanVar(value=SETTINGS.get('auto_compare',True))
        ttk.Checkbutton(win,text='AutoLearn: save references from research automatically',variable=learn).pack(anchor='w',padx=16,pady=8)
        ttk.Checkbutton(win,text='Auto Compare: compare actual readable webpage/transcript text',variable=compare).pack(anchor='w',padx=16,pady=4)
        ttk.Button(win,text='Compare saved knowledge now',command=lambda:self.compare_saved_knowledge()).pack(anchor='w',padx=16,pady=12)
        def save():
            SETTINGS['auto_learn']=learn.get(); SETTINGS['auto_research']=learn.get(); SETTINGS['auto_compare']=compare.get()
            SETTINGS_PATH.write_text(json.dumps(SETTINGS,indent=2),encoding='utf-8'); win.destroy()
            messagebox.showinfo('AutoLearn','Settings saved. MINI AI learns during explicit research requests and saves source-linked summaries when enabled. It does not secretly browse or watch videos.')
        ttk.Button(win,text='Save settings',command=save,style='Accent.TButton').pack(anchor='w',padx=16,pady=8)

    def compare_saved_knowledge(self):
        """Compare saved source contents, not just titles or URLs.

        The lexical similarity is a review aid, not a truth detector. It deliberately
        surfaces source text, numeric differences and negation cues for human checking.
        """
        with db() as con:
            rows=con.execute('SELECT id,title,source,body,created FROM knowledge ORDER BY id DESC LIMIT 250').fetchall()
        stop={'that','this','with','from','have','their','about','which','when','what','will','into','than','also','more','some','your','they','them','were','been','being','there','where','could','would','should','other','using','used','such','each','only','very','over','under','research','question','source','engines','retrieved','summary','url','http','https','www','com'}
        prepared=[]
        for row in rows:
            body=str(row[3] or '')[:30000]
            # Strip repeated metadata lines so the same URL/date labels don't create fake overlap.
            content='\n'.join(line for line in body.splitlines() if not re.match(r'^\s*(URL|Retrieved|Search engines|Source type|Research question):',line,re.I))
            words={w for w in tokenize((row[1] or '')+' '+content) if len(w)>3 and w not in stop}
            nums=set(re.findall(r'\b\d+(?:[.,]\d+)?%?\b',content))
            neg=bool(re.search(r'\b(not|no|never|cannot|can.t|doesn.t|isn.t|without|unlikely|impossible)\b',content,re.I))
            prepared.append((row,content,words,nums,neg))
        matches=[]
        for i,a in enumerate(prepared):
            if len(a[2])<5: continue
            for b in prepared[i+1:]:
                if not b[2]: continue
                common=a[2]&b[2]
                if len(common)<5: continue
                union=a[2]|b[2]
                jaccard=len(common)/max(1,len(union))
                containment=len(common)/max(1,min(len(a[2]),len(b[2])))
                # Require a meaningful content relationship; titles alone are insufficient.
                score=0.65*jaccard+0.35*containment
                if score>=0.025:
                    flags=[]
                    if a[3] and b[3] and a[3] != b[3]: flags.append('different number sets')
                    if a[4] != b[4]: flags.append('different negation signals')
                    matches.append((score,len(common),a,b,', '.join(sorted(common)[:12]),flags))
        matches.sort(key=lambda x:(x[0],x[1]),reverse=True)
        win=tk.Toplevel(self.root); win.title('Knowledge content comparison'); win.geometry('900x600')
        box=tk.Text(win,wrap='word',bg=self.bg,fg=self.fg,padx=12,pady=12); box.pack(fill='both',expand=True)
        box.insert('end','SAVED KNOWLEDGE — CONTENT COMPARISON\n\nThis compares readable saved text, not just links or titles. Similar wording does not prove agreement or truth. Different numbers/negation are only review flags; sources may discuss different dates, contexts, or units. Open the originals before deciding.\n\n')
        for score,n,a,b,terms,flags in matches[:80]:
            ra,ca,wa,na,nega=a; rb,cb,wb,nb,negb=b
            excerpt_a=re.sub(r'\s+',' ',ca)[:500]
            excerpt_b=re.sub(r'\s+',' ',cb)[:500]
            box.insert('end',f'Content similarity: {score:.1%} · shared content terms: {n}\nShared terms: {terms}\nReview flags: {", ".join(flags) if flags else "none detected by simple checks"}\n\nA: {ra[1]}\nSource: {ra[2]} · saved {ra[4]}\nText extract: {excerpt_a}\n\nB: {rb[1]}\nSource: {rb[2]} · saved {rb[4]}\nText extract: {excerpt_b}\n\n'+'-'*78+'\n\n')
        if not matches: box.insert('end','No sufficiently similar saved content was found. Save readable article text or import documents first; URL-only records cannot be compared as full sources.')
        box.configure(state='disabled')

    def offline_studio(self):
        win=tk.Toplevel(self.root); win.title('Offline Studio'); win.geometry('900x680'); win.configure(bg=self.bg)
        ttk.Label(win,text='Offline Studio',font=('Segoe UI',16,'bold')).pack(anchor='w',padx=14,pady=(12,4))
        ttk.Label(win,text='Works without internet for drafting, organizing notes, templates and local project files. This is not a generative AI model; output is template-based until a local model is installed.',wraplength=850).pack(anchor='w',padx=14,pady=(0,8))
        row=ttk.Frame(win); row.pack(fill='x',padx=14,pady=4)
        mode=tk.StringVar(value=SETTINGS.get('studio_default','Notes'))
        ttk.Label(row,text='Studio type').pack(side='left'); ttk.Combobox(row,textvariable=mode,state='readonly',values=['Notes','Project plan','Code starter','Study guide','Research comparison','Story outline'],width=24).pack(side='left',padx=8)
        prompt=tk.Text(win,height=4,wrap='word',bg='#2f2f2f',fg=self.fg,insertbackground='white'); prompt.pack(fill='x',padx=14,pady=5)
        out=tk.Text(win,wrap='word',bg='#171717',fg=self.fg,insertbackground='white',undo=True); out.pack(fill='both',expand=True,padx=14,pady=5)
        def generate():
            subject=prompt.get('1.0','end').strip() or 'Untitled project'
            templates={
              'Notes':f'# {subject}\n\n## Summary\n\n## Key points\n- \n\n## Questions to verify\n- \n\n## Next steps\n- \n',
              'Project plan':f'# Project plan: {subject}\n\n## Goal\n\n## Requirements\n- \n\n## Materials / dependencies\n- \n\n## Steps\n1. Define the goal\n2. Gather requirements\n3. Build a small prototype\n4. Test and record results\n5. Review risks and improve\n\n## Risks and unknowns\n\n## Completion checklist\n- [ ] Prototype works\n- [ ] Tests documented\n',
              'Code starter':f'/* Project: {subject} */\n// Starter template only. Add requirements before implementing.\n\nvoid setup() {{\n  Serial.begin(9600);\n}}\n\nvoid loop() {{\n  // TODO: implement one small, testable task\n}}\n',
              'Study guide':f'# Study guide: {subject}\n\n## What I already know\n\n## Key concepts to learn\n1. \n2. \n3. \n\n## Examples\n\n## Practice questions\n1. \n2. \n\n## Check answers against reliable sources\n',
              'Research comparison':f'# Research comparison: {subject}\n\n| Claim | Source A | Source B | Date | Evidence | Confidence |\n|---|---|---|---|---|---|\n| | | | | | |\n\n## Disagreements\n\n## What evidence would resolve them?\n\nNote: do not select a “correct” answer by vote count alone.\n',
              'Story outline':f'# Story outline: {subject}\n\n## Premise\n\n## Characters\n\n## Setting\n\n## Beginning\n\n## Conflict\n\n## Turning point\n\n## Ending\n'}
            out.delete('1.0','end'); out.insert('1.0',templates[mode.get()]); SETTINGS['studio_default']=mode.get(); SETTINGS_PATH.write_text(json.dumps(SETTINGS,indent=2),encoding='utf-8')
        def save():
            dest=filedialog.asksaveasfilename(parent=win,title='Save Studio output',defaultextension='.md',filetypes=[('Markdown','*.md'),('Text','*.txt'),('Arduino sketch','*.ino'),('All files','*.*')])
            if dest:
                try: Path(dest).write_text(out.get('1.0','end-1c'),encoding='utf-8'); messagebox.showinfo('Saved','Saved to '+dest,parent=win)
                except Exception as e: messagebox.showerror('Save failed',str(e),parent=win)
        bar=ttk.Frame(win); bar.pack(fill='x',padx=14,pady=(0,12)); ttk.Button(bar,text='Create offline draft',command=generate,style='Accent.TButton').pack(side='left'); ttk.Button(bar,text='Save output',command=save).pack(side='left',padx=8); ttk.Button(bar,text='Use as chat prompt',command=lambda:self.insert_prompt(prompt.get('1.0','end').strip())).pack(side='left')
    def show_knowledge(self):
        win=tk.Toplevel(self.root); win.title('Saved knowledge'); win.geometry('760x480')
        tree=ttk.Treeview(win,columns=('id','title','source','created'),show='headings');
        for c,w in [('id',45),('title',270),('source',250),('created',145)]: tree.heading(c,text=c.title()); tree.column(c,width=w)
        tree.pack(fill='both',expand=True,padx=8,pady=8)
        with db() as con: rows=con.execute('SELECT id,title,source,created FROM knowledge ORDER BY id DESC').fetchall()
        for r in rows: tree.insert('','end',values=r)
        def view():
            sel=tree.selection()
            if not sel:return
            ident=tree.item(sel[0],'values')[0]
            with db() as con: row=con.execute('SELECT title,body,source FROM knowledge WHERE id=?',(ident,)).fetchone()
            if row:
                w=tk.Toplevel(win); w.title(row[0]); w.geometry('650x420'); t=tk.Text(w,wrap='word'); t.pack(fill='both',expand=True); t.insert('1.0',f'{row[0]}\nSource: {row[2]}\n\n{row[1]}'); t.configure(state='disabled')
        def delete():
            sel=tree.selection()
            if not sel:return
            if messagebox.askyesno('Delete','Delete selected knowledge permanently?',parent=win):
                for item in sel:
                    ident=tree.item(item,'values')[0]
                    with db() as con: con.execute('DELETE FROM knowledge WHERE id=?',(ident,))
                    tree.delete(item)
                self.refresh_status()
        bar=ttk.Frame(win); bar.pack(fill='x',padx=8,pady=(0,8)); ttk.Button(bar,text='View',command=view).pack(side='left'); ttk.Button(bar,text='Delete selected',command=delete).pack(side='left',padx=6)
    def show_chats(self):
        update_chat_zip()
        win=tk.Toplevel(self.root); win.title('Saved chats · ZIP compressed'); win.geometry('760x480')
        ttk.Label(win,text='Saved chats are also compressed into saved_chats.zip in the private app data folder.',wraplength=720).pack(anchor='w',padx=10,pady=(8,0))
        lb=tk.Listbox(win); lb.pack(fill='both',expand=True,padx=8,pady=8)
        with db() as con: rows=[(r[0],r[1],unpack_chat_body(r[2]),r[3]) for r in con.execute('SELECT id,role,body,created FROM chats ORDER BY id DESC LIMIT 500').fetchall()]
        for r in rows: lb.insert('end',f'#{r[0]} · {r[3]} · {r[1]}: {r[2][:100].replace(chr(10)," ")}')
        def view(event=None):
            ix=lb.curselection()
            if not ix:return
            r=rows[ix[0]]; w=tk.Toplevel(win); w.title(f'Saved chat #{r[0]}'); w.geometry('650x400'); t=tk.Text(w,wrap='word'); t.pack(fill='both',expand=True); t.insert('1.0',f'{r[1]} · {r[3]}\n\n{r[2]}'); t.configure(state='disabled')
        lb.bind('<Double-1>',view)
        bar=ttk.Frame(win); bar.pack(pady=(0,8))
        ttk.Button(bar,text='Open selected',command=view).pack(side='left',padx=4)
        ttk.Button(bar,text='Open ZIP folder',command=lambda:os.startfile(str(APP_DIR)) if os.name=='nt' else webbrowser.open(APP_DIR.as_uri())).pack(side='left',padx=4)
    def safe_calculate(self, expression):
        """Evaluate basic arithmetic only; never use eval()."""
        import ast, operator, math
        ops={ast.Add:operator.add, ast.Sub:operator.sub, ast.Mult:operator.mul, ast.Div:operator.truediv,
             ast.FloorDiv:operator.floordiv, ast.Mod:operator.mod, ast.Pow:operator.pow, ast.USub:operator.neg,
             ast.UAdd:operator.pos}
        try:
            tree=ast.parse(expression,mode='eval')
            def run(node):
                if isinstance(node,ast.Expression): return run(node.body)
                if isinstance(node,ast.Constant) and isinstance(node.value,(int,float)) and not isinstance(node.value,bool): return node.value
                if isinstance(node,ast.BinOp) and type(node.op) in ops:
                    a,b=run(node.left),run(node.right)
                    if isinstance(node.op,ast.Pow) and abs(b)>12: raise ValueError('Exponent is too large')
                    value=ops[type(node.op)](a,b)
                    if abs(value)>1e100: raise ValueError('Result is too large')
                    return value
                if isinstance(node,ast.UnaryOp) and type(node.op) in ops: return ops[type(node.op)](run(node.operand))
                raise ValueError('Only numbers and basic arithmetic (+ - * / // % ** and parentheses) are supported.')
            return f'{expression} = {run(tree):,.10g}'
        except Exception as e: return 'Could not calculate that safely: '+str(e)

    def quick_tools(self):
        win=tk.Toplevel(self.root); win.title('Quick tools'); win.geometry('460x360'); win.configure(bg=self.bg)
        ttk.Label(win,text='Quick tools',font=('Segoe UI',15,'bold')).pack(anchor='w',padx=16,pady=(16,8))
        ttk.Label(win,text='Calculator (basic arithmetic)').pack(anchor='w',padx=16)
        expr=tk.StringVar(); ttk.Entry(win,textvariable=expr).pack(fill='x',padx=16,pady=6)
        result=tk.StringVar(value='Example: (12 + 8) * 3')
        ttk.Label(win,textvariable=result,wraplength=420).pack(anchor='w',padx=16,pady=6)
        ttk.Button(win,text='Calculate',command=lambda:result.set(self.safe_calculate(expr.get()))).pack(anchor='w',padx=16)
        ttk.Separator(win).pack(fill='x',padx=16,pady=12)
        ttk.Label(win,text='Prompt starters').pack(anchor='w',padx=16)
        starters=['Explain this step by step: ','Help me debug this code: ','Make a study plan for: ','Summarise these notes: ','Brainstorm ideas for: ']
        for prompt in starters:
            ttk.Button(win,text=prompt.strip(),command=lambda x=prompt:self.insert_prompt(x)).pack(fill='x',padx=16,pady=2)

    def insert_prompt(self, prompt):
        self.entry.insert('end',prompt); self.entry.focus_set()

    def developer_tools(self):
        """Portable code workbench. Validates source; never silently executes user code."""
        win=tk.Toplevel(self.root); win.title('Developer tools — Code Lab'); win.geometry('900x680'); win.configure(bg=self.bg)
        bar=ttk.Frame(win,padding=8); bar.pack(fill='x')
        language=tk.StringVar(value='Python')
        ttk.Label(bar,text='Language').pack(side='left')
        ttk.Combobox(bar,textvariable=language,state='readonly',width=14,values=['Python','Arduino / C++','JSON','HTML','Markdown','Plain text']).pack(side='left',padx=6)
        editor=tk.Text(win,wrap='none',undo=True,font=('Consolas',10),bg='#171717',fg='#eeeeee',insertbackground='white')
        y=ttk.Scrollbar(win,orient='vertical',command=editor.yview); x=ttk.Scrollbar(win,orient='horizontal',command=editor.xview)
        editor.configure(yscrollcommand=y.set,xscrollcommand=x.set)
        editor.pack(fill='both',expand=True,padx=(8,0),pady=(0,0)); y.place(relx=1.0,rely=.07,relheight=.72,anchor='ne'); x.pack(fill='x',padx=8)
        output=tk.Text(win,height=7,wrap='word',state='disabled',bg='#202020',fg='#d8d8d8',font=('Consolas',9))
        output.pack(fill='x',padx=8,pady=8)
        def report(text):
            output.configure(state='normal'); output.delete('1.0','end'); output.insert('end',text); output.configure(state='disabled')
        def load_file():
            path=filedialog.askopenfilename(title='Open source file',filetypes=[('Code and text','*.py *.ino *.c *.cpp *.h *.hpp *.json *.html *.htm *.md *.txt'),('All files','*.*')],parent=win)
            if path:
                try:
                    editor.delete('1.0','end'); editor.insert('1.0',Path(path).read_text(encoding='utf-8',errors='replace')); language.set({'.py':'Python','.ino':'Arduino / C++','.c':'Arduino / C++','.cpp':'Arduino / C++','.h':'Arduino / C++','.json':'JSON','.html':'HTML','.htm':'HTML','.md':'Markdown'}.get(Path(path).suffix.lower(),'Plain text')); report('Loaded: '+path)
                except Exception as e: messagebox.showerror('Open failed',str(e),parent=win)
        def save_file():
            ext={'Python':'.py','Arduino / C++':'.ino','JSON':'.json','HTML':'.html','Markdown':'.md','Plain text':'.txt'}.get(language.get(),'.txt')
            path=filedialog.asksaveasfilename(title='Save source file',defaultextension=ext,filetypes=[('Matching file', '*'+ext),('All files','*.*')],parent=win)
            if path:
                try: Path(path).write_text(editor.get('1.0','end-1c'),encoding='utf-8'); report('Saved: '+path)
                except Exception as e: messagebox.showerror('Save failed',str(e),parent=win)
        def insert_template():
            templates={
              'Python':'def main():\n    print("Hello from MINI AI")\n\nif __name__ == "__main__":\n    main()\n',
              'Arduino / C++':'void setup() {\n  Serial.begin(9600);\n  pinMode(LED_BUILTIN, OUTPUT);\n}\n\nvoid loop() {\n  digitalWrite(LED_BUILTIN, HIGH);\n  delay(500);\n  digitalWrite(LED_BUILTIN, LOW);\n  delay(500);\n}\n',
              'JSON':'{\n  "name": "my-project",\n  "version": 1\n}\n',
              'HTML':'<!doctype html>\n<html lang="en">\n<head><meta charset="utf-8"><title>My page</title></head>\n<body><h1>Hello</h1></body>\n</html>\n',
              'Markdown':'# Project notes\n\n## Goal\nDescribe your project here.\n'}
            if messagebox.askyesno('Insert template','Replace the current editor contents with a '+language.get()+' starter template?',parent=win):
                editor.delete('1.0','end'); editor.insert('1.0',templates.get(language.get(),'# Start writing here\n'))
        def validate():
            code=editor.get('1.0','end-1c'); lang=language.get()
            try:
                if lang=='Python':
                    import ast; ast.parse(code); msg='Python syntax check passed. This checks syntax only; it does not run or prove the program works.'
                elif lang=='JSON':
                    json.loads(code); msg='JSON is valid.'
                elif lang=='HTML':
                    from html.parser import HTMLParser
                    class Checker(HTMLParser): pass
                    Checker().feed(code); msg='HTML parser accepted the document. This is not a full standards validator.'
                elif lang=='Arduino / C++':
                    import shutil, subprocess, tempfile
                    cli=shutil.which('arduino-cli')
                    if not cli: msg='Arduino compile unavailable: arduino-cli was not found. Install Arduino CLI and the arduino:avr core, then retry. No code was executed.'
                    else:
                        with tempfile.TemporaryDirectory(prefix='mini_ai_arduino_') as td:
                            folder=Path(td)/'CodeLab'; folder.mkdir(); (folder/'CodeLab.ino').write_text(code,encoding='utf-8')
                            proc=subprocess.run([cli,'compile','--fqbn','arduino:avr:uno',str(folder)],capture_output=True,text=True,timeout=120)
                            msg=('Arduino Uno compile succeeded.\n' if proc.returncode==0 else 'Arduino Uno compile failed.\n')+(proc.stdout+'\n'+proc.stderr)[-9000:]
                elif lang=='Markdown': msg='Markdown has no single universal syntax checker; content is ready to save.'
                else: msg='Plain text has no syntax validation.'
            except Exception as e: msg='Validation failed:\n'+str(e)
            report(msg)
        ttk.Button(bar,text='Open file',command=load_file).pack(side='left',padx=3)
        ttk.Button(bar,text='Save as',command=save_file).pack(side='left',padx=3)
        ttk.Button(bar,text='Insert starter',command=insert_template).pack(side='left',padx=3)
        ttk.Button(bar,text='Check / Compile',command=validate,style='Accent.TButton').pack(side='left',padx=3)
        ttk.Label(win,text='Safety: source is not automatically executed. Arduino compilation requires Arduino CLI and its AVR core.',foreground=self.muted).pack(anchor='w',padx=10,pady=(0,8))

    def note_manager(self):
        win=tk.Toplevel(self.root); win.title('MINI AI Notes & Journal'); win.geometry('850x560')
        pane=ttk.Panedwindow(win,orient='horizontal'); pane.pack(fill='both',expand=True,padx=10,pady=10)
        left=ttk.Frame(pane,padding=6); right=ttk.Frame(pane,padding=6); pane.add(left,weight=1); pane.add(right,weight=3)
        lb=tk.Listbox(left); lb.pack(fill='both',expand=True)
        title=tk.StringVar(); ttk.Label(right,text='Title').pack(anchor='w'); ttk.Entry(right,textvariable=title).pack(fill='x',pady=(0,6))
        body=tk.Text(right,wrap='word',undo=True); body.pack(fill='both',expand=True)
        def reload(selected=None):
            lb.delete(0,'end')
            with db() as con: rows=con.execute('SELECT id,title,body,updated FROM notes ORDER BY updated DESC').fetchall()
            for r in rows: lb.insert('end',f'#{r[0]} · {r[1]} · {r[3]}')
            win.note_rows=rows
            if selected is not None:
                for i,r in enumerate(rows):
                    if r[0]==selected: lb.selection_set(i); lb.event_generate('<<ListboxSelect>>'); break
        def load(event=None):
            ix=lb.curselection()
            if not ix:return
            r=win.note_rows[ix[0]]; title.set(r[1]); body.delete('1.0','end'); body.insert('1.0',r[2])
        def save():
            t=title.get().strip(); b=body.get('1.0','end-1c').strip()
            if not t or not b: messagebox.showwarning('Save note','Enter both a title and note text.',parent=win); return
            ix=lb.curselection()
            if ix:
                ident=win.note_rows[ix[0]][0]
                with db() as con: con.execute('UPDATE notes SET title=?,body=?,updated=? WHERE id=?',(t,b,stamp(),ident))
                selected=ident
            else:
                with db() as con: cur=con.execute('INSERT INTO notes(title,body,updated) VALUES(?,?,?)',(t,b,stamp())); selected=cur.lastrowid
            reload(selected); messagebox.showinfo('Notes','Note saved locally.',parent=win)
        def delete():
            ix=lb.curselection()
            if not ix:return
            ident=win.note_rows[ix[0]][0]
            if messagebox.askyesno('Delete note','Delete this note permanently?',parent=win):
                with db() as con: con.execute('DELETE FROM notes WHERE id=?',(ident,))
                title.set(''); body.delete('1.0','end'); reload()
        lb.bind('<<ListboxSelect>>',load)
        bar=ttk.Frame(right); bar.pack(fill='x',pady=6)
        ttk.Button(bar,text='New note',command=lambda:(title.set(''),body.delete('1.0','end'),lb.selection_clear(0,'end'))).pack(side='left')
        ttk.Button(bar,text='Save note',command=save,style='Accent.TButton').pack(side='left',padx=5)
        ttk.Button(bar,text='Delete',command=delete).pack(side='left')
        reload()

    def task_manager(self):
        win=tk.Toplevel(self.root); win.title('MINI AI Tasks & Checklists'); win.geometry('760x500')
        top=ttk.Frame(win,padding=10); top.pack(fill='x')
        title=tk.StringVar(); details=tk.StringVar(); due=tk.StringVar()
        ttk.Label(top,text='Task').grid(row=0,column=0,sticky='w'); ttk.Entry(top,textvariable=title,width=32).grid(row=1,column=0,padx=(0,6))
        ttk.Label(top,text='Details').grid(row=0,column=1,sticky='w'); ttk.Entry(top,textvariable=details,width=32).grid(row=1,column=1,padx=6)
        ttk.Label(top,text='Due date (optional)').grid(row=0,column=2,sticky='w'); ttk.Entry(top,textvariable=due,width=18).grid(row=1,column=2,padx=6)
        tree=ttk.Treeview(win,columns=('id','status','task','due','details'),show='headings');
        for c,w in [('id',45),('status',90),('task',210),('due',110),('details',250)]: tree.heading(c,text=c.title()); tree.column(c,width=w)
        tree.pack(fill='both',expand=True,padx=10,pady=5)
        def reload():
            for x in tree.get_children(): tree.delete(x)
            with db() as con: rows=con.execute('SELECT id,done,title,due,details FROM tasks ORDER BY done,due,created DESC').fetchall()
            for r in rows: tree.insert('','end',values=(r[0],'Done' if r[1] else 'Open',r[2],r[3] or '',r[4] or ''))
        def add():
            t=title.get().strip()
            if not t: messagebox.showwarning('Task','Enter a task name.',parent=win); return
            with db() as con: con.execute('INSERT INTO tasks(title,details,due,done,created) VALUES(?,?,?,?,?)',(t,details.get().strip(),due.get().strip(),0,stamp()))
            title.set(''); details.set(''); due.set(''); reload()
        def toggle():
            sel=tree.selection()
            if not sel:return
            vals=tree.item(sel[0],'values'); ident=int(vals[0])
            with db() as con: con.execute('UPDATE tasks SET done=CASE done WHEN 0 THEN 1 ELSE 0 END WHERE id=?',(ident,))
            reload()
        def delete():
            sel=tree.selection()
            if not sel:return
            with db() as con:
                for item in sel: con.execute('DELETE FROM tasks WHERE id=?',(int(tree.item(item,'values')[0]),))
            reload()
        bar=ttk.Frame(win,padding=10); bar.pack(fill='x')
        ttk.Button(bar,text='Add task',command=add,style='Accent.TButton').pack(side='left'); ttk.Button(bar,text='Mark done / reopen',command=toggle).pack(side='left',padx=5); ttk.Button(bar,text='Delete selected',command=delete).pack(side='left')
        reload()

    def flashcards(self):
        win=tk.Toplevel(self.root); win.title('MINI AI Flashcards'); win.geometry('700x480')
        form=ttk.Frame(win,padding=10); form.pack(fill='x')
        q=tk.StringVar(); a=tk.StringVar()
        ttk.Label(form,text='Question / front').grid(row=0,column=0,sticky='w'); ttk.Entry(form,textvariable=q,width=45).grid(row=1,column=0,padx=(0,8))
        ttk.Label(form,text='Answer / back').grid(row=0,column=1,sticky='w'); ttk.Entry(form,textvariable=a,width=45).grid(row=1,column=1)
        tree=ttk.Treeview(win,columns=('id','question','answer'),show='headings'); tree.heading('id',text='ID'); tree.heading('question',text='Question'); tree.heading('answer',text='Answer'); tree.column('id',width=45); tree.column('question',width=300); tree.column('answer',width=300); tree.pack(fill='both',expand=True,padx=10,pady=6)
        def reload():
            for x in tree.get_children():tree.delete(x)
            with db() as con: rows=con.execute('SELECT id,question,answer FROM flashcards ORDER BY id DESC').fetchall()
            for r in rows:tree.insert('','end',values=r)
        def add():
            if not q.get().strip() or not a.get().strip():return
            with db() as con:con.execute('INSERT INTO flashcards(question,answer,created) VALUES(?,?,?)',(q.get().strip(),a.get().strip(),stamp()))
            q.set('');a.set('');reload()
        def study():
            with db() as con: rows=con.execute('SELECT question,answer FROM flashcards ORDER BY RANDOM()').fetchall()
            if not rows:messagebox.showinfo('Study','Add some flashcards first.',parent=win);return
            state={'i':0,'show':False}; card=tk.Toplevel(win);card.title('Flashcard study');card.geometry('520x300')
            label=ttk.Label(card,text='',wraplength=470,font=('Segoe UI',14));label.pack(fill='both',expand=True,padx=20,pady=20)
            def render():label.config(text=rows[state['i']][1] if state['show'] else rows[state['i']][0]); counter.config(text=f'Card {state["i"]+1} of {len(rows)}')
            def flip():state['show']=not state['show'];render()
            def nextc():state['i']=(state['i']+1)%len(rows);state['show']=False;render()
            counter=ttk.Label(card,text='');counter.pack();bar=ttk.Frame(card);bar.pack(pady=12);ttk.Button(bar,text='Flip',command=flip).pack(side='left',padx=4);ttk.Button(bar,text='Next',command=nextc).pack(side='left',padx=4);render()
        def delete_selected():
            sel=tree.selection()
            if not sel:return
            ident=int(tree.item(sel[0],'values')[0])
            with db() as con: con.execute('DELETE FROM flashcards WHERE id=?',(ident,))
            reload()
        bar=ttk.Frame(win,padding=10);bar.pack(fill='x');ttk.Button(bar,text='Add flashcard',command=add,style='Accent.TButton').pack(side='left');ttk.Button(bar,text='Study random cards',command=study).pack(side='left',padx=6);ttk.Button(bar,text='Delete selected',command=delete_selected).pack(side='left')
        reload()

    def text_toolbox(self):
        win=tk.Toplevel(self.root); win.title('MINI AI Text Toolbox'); win.geometry('900x650')
        ttk.Label(win,text='Text Toolbox — offline utilities',font=('Segoe UI',15,'bold')).pack(anchor='w',padx=12,pady=10)
        controls=ttk.Frame(win);controls.pack(fill='x',padx=12)
        mode=tk.StringVar(value='Clean whitespace'); ttk.Label(controls,text='Operation').pack(side='left');ttk.Combobox(controls,textvariable=mode,state='readonly',values=['Clean whitespace','Count words','Extract URLs','Extract email addresses','Sort lines','Remove duplicate lines','Uppercase','Lowercase','Title Case','JSON pretty-print','Summarise by first sentences'],width=30).pack(side='left',padx=8)
        src=tk.Text(win,wrap='word',height=12,undo=True);src.pack(fill='both',expand=True,padx=12,pady=6)
        dst=tk.Text(win,wrap='word',height=12,undo=True);dst.pack(fill='both',expand=True,padx=12,pady=6)
        def run():
            raw=src.get('1.0','end-1c'); m=mode.get()
            try:
                if m=='Clean whitespace':out=re.sub(r'[ \t]+',' ',raw);out=re.sub(r'\n\s*\n+', '\n\n',out).strip()
                elif m=='Count words':words=len(re.findall(r'\b\w+\b',raw));out=f'Characters: {len(raw)}\nWords: {words}\nLines: {len(raw.splitlines())}'
                elif m=='Extract URLs':out='\n'.join(re.findall(r'https?://[^\s<>"\']+',raw))
                elif m=='Extract email addresses':out='\n'.join(re.findall(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',raw))
                elif m=='Sort lines':out='\n'.join(sorted(raw.splitlines(),key=str.casefold))
                elif m=='Remove duplicate lines':out='\n'.join(dict.fromkeys(raw.splitlines()))
                elif m=='Uppercase':out=raw.upper()
                elif m=='Lowercase':out=raw.lower()
                elif m=='Title Case':out=raw.title()
                elif m=='JSON pretty-print':out=json.dumps(json.loads(raw),indent=2,ensure_ascii=False)
                else:
                    sentences=re.split(r'(?<=[.!?])\s+',re.sub(r'\s+',' ',raw).strip());out=' '.join(sentences[:3]) + ('…' if len(sentences)>3 else '')
                dst.delete('1.0','end');dst.insert('1.0',out)
            except Exception as e:messagebox.showerror('Tool error',str(e),parent=win)
        def copy():
            win.clipboard_clear();win.clipboard_append(dst.get('1.0','end-1c'))
        bar=ttk.Frame(win);bar.pack(fill='x',padx=12,pady=8);ttk.Button(bar,text='Run tool',command=run,style='Accent.TButton').pack(side='left');ttk.Button(bar,text='Copy result',command=copy).pack(side='left',padx=6);ttk.Button(bar,text='Send result to chat',command=lambda:self.insert_prompt(dst.get('1.0','end-1c'))).pack(side='left')

    def import_folder(self):
        folder=filedialog.askdirectory(title='Choose a folder of readable documents')
        if not folder:return
        supported={'.txt','.md','.html','.htm','.csv','.json','.py','.ino','.log','.xml','.yaml','.yml'}
        max_mb=float(SETTINGS.get('max_import_mb',25)); count=0; skipped=0; errors=[]
        for p in Path(folder).rglob('*'):
            if not p.is_file() or p.suffix.lower() not in supported:continue
            try:
                if p.stat().st_size>max_mb*1024*1024:skipped+=1;continue
                raw=p.read_text(encoding='utf-8',errors='replace')
                if p.suffix.lower() in ('.html','.htm'):raw=re.sub(r'(?is)<(script|style).*?>.*?</\1>',' ',raw);raw=re.sub(r'(?s)<[^>]+>',' ',raw);raw=re.sub(r'\s+',' ',raw)
                ok,msg=add_knowledge(p.name,raw,str(p))
                count+=int(ok)
                if not ok:errors.append(p.name+': '+msg)
            except Exception as e:errors.append(p.name+': '+str(e))
        messagebox.showinfo('Folder import',f'Imported {count} documents.\nSkipped oversized files: {skipped}.\n'+('\n'.join(errors[:8]) if errors else ''),parent=self.root);self.refresh_status()

    def open_eyes(self):
        """Local webcam preview with automatically downloaded YOLOv4-tiny COCO detection and teachable visual labels."""
        try:
            import cv2
        except Exception as import_error:
            cam_py = Path.home() / 'MINI_AI_CAMERA' / 'Scripts' / 'python.exe'
            extra = '\n\nA CPU-compatible camera environment was found at:\n' + str(cam_py) if cam_py.exists() else ''
            messagebox.showerror('Camera libraries unavailable',
                'MINI AI cannot import OpenCV in the Python interpreter currently running it. ' +
                'Your working camera environment may be separate. Close MINI AI and launch it with Start_MINI_AI.bat, which should select that environment.' + extra + '\n\n' + str(import_error), parent=self.root)
            return
        win=tk.Toplevel(self.root); win.title('MINI AI Eyes · Live Object Detection & Teaching'); win.geometry('900x760'); win.minsize(680,600)
        ttk.Label(win,text='MINI AI EYES · LIVE OBJECT DETECTION',font=('Segoe UI',15,'bold')).pack(anchor='w',padx=14,pady=(12,2))
        ttk.Label(win,text='Webcam frames are processed locally. On first use, MINI AI automatically downloads its detector; you do not enter links. It recognises up to 80 common categories, not every object. You can teach additional objects and save examples locally.',wraplength=850).pack(anchor='w',padx=14,pady=(0,8))
        preview=ttk.Label(win,text='Opening camera and loading object detector…',anchor='center'); preview.pack(fill='both',expand=True,padx=14,pady=6)
        status=tk.StringVar(value='Opening camera…'); ttk.Label(win,textvariable=status).pack(anchor='w',padx=14)
        desc=tk.Text(win,height=3,wrap='word',bg='#ffffff',fg='#171717',insertbackground='#111111'); desc.pack(fill='x',padx=14,pady=(8,4)); desc.insert('1.0','Optional notes about the object or scene.')
        mode_row=ttk.Frame(win); mode_row.pack(fill='x',padx=14,pady=(2,4))
        ttk.Label(mode_row,text='Vision mode:').pack(side='left')
        vision_mode=tk.StringVar(value='Ask about object')
        ttk.Combobox(mode_row,textvariable=vision_mode,state='readonly',values=['Ask about object','Resource Capability'],width=24).pack(side='left',padx=8)
        question_var=tk.StringVar(value='What is this object, what does it do, and how does it work?')
        ttk.Label(win,text='Optional question for the offline detector summary:').pack(anchor='w',padx=14)
        ttk.Entry(win,textvariable=question_var).pack(fill='x',padx=14,pady=(0,5))
        buttons=ttk.Frame(win); buttons.pack(fill='x',padx=14,pady=6)
        state={'cap':None,'frame':None,'photo':None,'after':None,'closed':False,'snapshot':None,'failures':0,'camera_message':'',
               'frame_id':0,'detections':[],'net':None,'detector_started':False,'detector_error':'','detector_ready':False,'stop':threading.Event(),'last_box':None}
        # YOLOv4-tiny COCO: 80 common object classes. The model is downloaded
        # automatically on first camera use; the user never enters a URL.
        classes=['person','bicycle','car','motorcycle','airplane','bus','train','truck','boat',
                 'traffic light','fire hydrant','stop sign','parking meter','bench','bird','cat','dog',
                 'horse','sheep','cow','elephant','bear','zebra','giraffe','backpack','umbrella',
                 'handbag','tie','suitcase','frisbee','skis','snowboard','sports ball','kite',
                 'baseball bat','baseball glove','skateboard','surfboard','tennis racket','bottle',
                 'wine glass','cup','fork','knife','spoon','bowl','banana','apple','sandwich','orange',
                 'broccoli','carrot','hot dog','pizza','donut','cake','chair','couch','potted plant',
                 'bed','dining table','toilet','tv','laptop','mouse','remote','keyboard','cell phone',
                 'microwave','oven','toaster','sink','refrigerator','book','clock','vase','scissors',
                 'teddy bear','hair drier','toothbrush']
        def model_paths():
            folder=APP_DIR/'vision_models'; folder.mkdir(parents=True,exist_ok=True)
            return folder/'yolov4-tiny.cfg', folder/'yolov4-tiny.weights'
        def download_file(url,dest):
            minimum=1000 if dest.suffix=='.cfg' else 10000000
            if dest.exists() and dest.stat().st_size>minimum: return
            tmp=dest.with_suffix(dest.suffix+'.part')
            try:
                req=urllib.request.Request(url,headers={'User-Agent':'MINI-AI-LITE-X/1.0'})
                with urllib.request.urlopen(req,timeout=90) as response, open(tmp,'wb') as out:
                    while True:
                        chunk=response.read(1024*1024)
                        if not chunk: break
                        out.write(chunk)
                if tmp.stat().st_size<=minimum:
                    raise RuntimeError('Detector download was incomplete or invalid.')
                tmp.replace(dest)
            finally:
                try:
                    if tmp.exists(): tmp.unlink()
                except Exception: pass
        def hist_for(image):
            hsv=cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
            hist=cv2.calcHist([hsv],[0,1],None,[8,8],[0,180,0,256])
            cv2.normalize(hist,hist,alpha=1.0,norm_type=cv2.NORM_L1)
            return hist
        def saved_labels():
            with db() as con: return con.execute('SELECT label,histogram FROM visual_labels ORDER BY id DESC LIMIT 10000').fetchall()
        def best_taught_label(image):
            try:
                current=hist_for(image); best=('','-1')
                for label,raw in saved_labels():
                    import numpy as np
                    prior=np.asarray(json.loads(raw),dtype='float32').reshape((8,8))
                    score=float(cv2.compareHist(current,prior,cv2.HISTCMP_CORREL))
                    if score>float(best[1]): best=(label,str(score))
                return (best[0],float(best[1])) if best[0] and float(best[1])>=0.90 else ('',-1.0)
            except Exception: return ('',-1.0)
        def open_camera():
            backends=[getattr(cv2,'CAP_DSHOW',0),getattr(cv2,'CAP_MSMF',0),getattr(cv2,'CAP_ANY',0)] if os.name=='nt' else [getattr(cv2,'CAP_ANY',0)]
            for index in range(5):
                for backend in dict.fromkeys(backends):
                    cap_try=None
                    try:
                        cap_try=cv2.VideoCapture(index,backend)
                        if not cap_try.isOpened(): cap_try.release(); continue
                        cap_try.set(cv2.CAP_PROP_FRAME_WIDTH,480); cap_try.set(cv2.CAP_PROP_FRAME_HEIGHT,360)
                        try: cap_try.set(cv2.CAP_PROP_BUFFERSIZE,1)
                        except Exception: pass
                        for _ in range(5):
                            ok,frame_try=cap_try.read()
                            if ok and frame_try is not None and getattr(frame_try,'size',0)>0:
                                state['frame']=frame_try.copy(); state['frame_id']+=1
                                state['camera_message']='Camera connected · device '+str(index)
                                return cap_try
                            time.sleep(0.08)
                        cap_try.release()
                    except Exception:
                        try:
                            if cap_try is not None: cap_try.release()
                        except Exception: pass
            state['camera_message']='No webcam frame. Check Windows camera privacy, drivers and other apps using the camera.'
            return None
        def detector_worker():
            try:
                import numpy as np
                try: win.after(0,lambda: status.set('Automatically preparing improved detector (first run downloads about 25 MB)…'))
                except Exception: pass
                cfg,weights=model_paths()
                download_file('https://raw.githubusercontent.com/AlexeyAB/darknet/master/cfg/yolov4-tiny.cfg',cfg)
                download_file('https://github.com/AlexeyAB/darknet/releases/download/yolov4/yolov4-tiny.weights',weights)
                net=cv2.dnn.readNetFromDarknet(str(cfg),str(weights))
                try:
                    net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
                    net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
                except Exception: pass
                output_names=net.getUnconnectedOutLayersNames()
                state['net']=net; state['output_names']=output_names; state['detector_ready']=True
                try: win.after(0,lambda: status.set('Improved detector ready · 80 common categories · local CPU processing'))
                except Exception: pass
            except Exception as e:
                state['detector_error']=str(e)
                try: win.after(0,lambda: status.set('Automatic detector setup failed. Check internet once and press Retry detector. '+str(e)[:90]))
                except Exception: pass
                return
            last_id=-1
            while not state['stop'].is_set() and not state['closed']:
                frame=state.get('frame'); frame_id=state.get('frame_id',0)
                if frame is None or frame_id==last_id:
                    time.sleep(0.12); continue
                last_id=frame_id
                try:
                    h,w=frame.shape[:2]
                    blob=cv2.dnn.blobFromImage(frame,1/255.0,(416,416),swapRB=True,crop=False)
                    net.setInput(blob); outputs=net.forward(state['output_names'])
                    boxes=[]; confidences=[]; class_ids=[]
                    for output in outputs:
                        for detection in output:
                            scores=detection[5:]
                            cid=int(np.argmax(scores)); conf=float(scores[cid])*float(detection[4])
                            if conf<0.32: continue
                            cx,cy,bw,bh=float(detection[0])*w,float(detection[1])*h,float(detection[2])*w,float(detection[3])*h
                            x=max(0,int(cx-bw/2)); y=max(0,int(cy-bh/2))
                            bw=max(1,min(w-x,int(bw))); bh=max(1,min(h-y,int(bh)))
                            if bw<8 or bh<8: continue
                            boxes.append([x,y,bw,bh]); confidences.append(conf); class_ids.append(cid)
                    indices=cv2.dnn.NMSBoxes(boxes,confidences,0.32,0.42); found=[]
                    if len(indices)>0:
                        for idx in np.array(indices).reshape(-1)[:8]:
                            x,y,bw,bh=boxes[int(idx)]; conf=confidences[int(idx)]; cid=class_ids[int(idx)]
                            crop=frame[y:y+bh,x:x+bw]
                            taught,similarity=best_taught_label(crop) if crop.size else ('',-1)
                            label=(taught+' (taught)') if taught else (classes[cid] if 0<=cid<len(classes) else 'UNKNOWN')
                            found.append({'box':[x/max(1,w),y/max(1,h),(x+bw)/max(1,w),(y+bh)/max(1,h)],'label':label,'confidence':conf,'taught':bool(taught)})
                    if not found: found=[{'box':[0.02,0.02,0.98,0.98],'label':'UNKNOWN · teach me','confidence':0.0,'taught':False}]
                    found.sort(key=lambda d:d['confidence'],reverse=True); state['detections']=found[:8]
                except Exception as e:
                    state['detector_error']=str(e); time.sleep(0.4)
                time.sleep(0.35)
        def tick():
            if state['closed']: return
            cap=state['cap']
            if cap is None: return
            try:
                ok,frame=cap.read()
                if ok and frame is not None and getattr(frame,'size',0)>0:
                    state['frame']=frame.copy(); state['frame_id']+=1; state['failures']=0
                    h,w=frame.shape[:2]; maxw,maxh=640,420
                    if w>maxw or h>maxh:
                        scale=min(maxw/float(w),maxh/float(h)); frame=cv2.resize(frame,(max(1,int(w*scale)),max(1,int(h*scale))))
                    dh,dw=frame.shape[:2]
                    for item in state.get('detections',[]):
                        bx=item['box']; x1=max(0,min(dw-1,int(bx[0]*dw))); y1=max(0,min(dh-1,int(bx[1]*dh))); x2=max(x1+1,min(dw-1,int(bx[2]*dw))); y2=max(y1+1,min(dh-1,int(bx[3]*dh)))
                        cv2.rectangle(frame,(x1,y1),(x2,y2),(40,220,90) if item['label']!='UNKNOWN' and not item['label'].startswith('UNKNOWN') else (20,150,255),2)
                        label=item['label'] + ((' '+str(int(item['confidence']*100))+'%') if item['confidence'] else '')
                        cv2.putText(frame,label[:45],(x1,max(18,y1-6)),cv2.FONT_HERSHEY_SIMPLEX,0.48,(40,220,90) if not item['label'].startswith('UNKNOWN') else (20,150,255),2,cv2.LINE_AA)
                    ok_png,png=cv2.imencode('.png',frame,[int(cv2.IMWRITE_PNG_COMPRESSION),3])
                    if not ok_png: raise RuntimeError('Could not encode camera preview')
                    photo=tk.PhotoImage(data=base64.b64encode(png.tobytes()).decode('ascii'))
                    state['photo']=photo; preview.configure(image=photo,text='')
                    if state['detector_ready']:
                        unknown=sum(1 for d in state.get('detections',[]) if d['label'].startswith('UNKNOWN'))
                        status.set('Live detection · '+str(len(state.get('detections',[])))+' box(es) · '+(str(unknown)+' unknown' if unknown else 'recognition active')+' · local only')
                    elif state['detector_error']:
                        status.set('Camera active · detector failed; unknown box/teaching available')
                    else: status.set('Camera active · downloading/loading object detector…')
                else:
                    state['failures']+=1; status.set('Camera returned no frame ('+str(state['failures'])+'). Press Retry camera.')
            except Exception as e: status.set('Preview issue: '+str(e)[:160])
            state['after']=win.after(180,tick)
        def start_camera_worker():
            def worker():
                newcap=open_camera()
                def finish():
                    if state['closed']:
                        try:
                            if newcap is not None: newcap.release()
                        except Exception: pass
                        return
                    state['cap']=newcap
                    status.set(state['camera_message'] or 'Camera unavailable')
                    if newcap is not None: tick()
                try: win.after(0,finish)
                except Exception: pass
            threading.Thread(target=worker,daemon=True).start()
        def retry_camera():
            old=state.get('cap')
            try:
                if old is not None: old.release()
            except Exception: pass
            state['cap']=None; state['frame']=None; status.set('Searching webcam devices…')
            start_camera_worker()
        def capture():
            frame=state.get('frame')
            if frame is None: messagebox.showwarning('No frame','Wait for the camera preview, then capture again.',parent=win); return
            state['snapshot']=frame.copy(); state['last_box']=None
            status.set('Snapshot captured. Use Teach boxed object to label the current scene/object.')
        def teach_object():
            frame=state.get('snapshot') if state.get('snapshot') is not None else state.get('frame')
            if frame is None: messagebox.showwarning('No frame','Wait for the webcam preview first.',parent=win); return
            boxes=state.get('detections',[])
            box=next((d['box'] for d in boxes if not d['label'].startswith('UNKNOWN')), boxes[0]['box'] if boxes else [0.02,0.02,0.98,0.98])
            h,w=frame.shape[:2]; x1=max(0,int(box[0]*w)); y1=max(0,int(box[1]*h)); x2=min(w,int(box[2]*w)); y2=min(h,int(box[3]*h))
            crop=frame[y1:y2,x1:x2]
            if crop.size==0: crop=frame
            label=simpledialog.askstring('Teach MINI AI this object','What is this object called? Use a specific name, e.g. “blue Arduino Uno board”.',parent=win)
            if not label or not label.strip(): return
            label=label.strip()[:100]
            try:
                folder=APP_DIR/'eyes'/'taught'; folder.mkdir(parents=True,exist_ok=True)
                path=folder/('taught_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.jpg')
                if not cv2.imwrite(str(path),crop,[int(cv2.IMWRITE_JPEG_QUALITY),65]): raise RuntimeError('Could not save teaching image')
                hist=hist_for(crop)
                with db() as con: con.execute('INSERT INTO visual_labels(label,image_path,histogram,created) VALUES(?,?,?,?)',(label,str(path),json.dumps(hist.reshape(-1).tolist(),separators=(',',':')),stamp()))
                add_knowledge('Taught visual object: '+label,'User-labelled visual example saved locally. Visual matching uses a small HSV colour histogram and can confuse similar-looking objects. Example image: '+str(path),'user-taught camera object')
                desc.delete('1.0','end'); desc.insert('1.0','Taught object: '+label+'. Place a similar-looking object in view to test the simple visual match.')
                status.set('Learned label saved: '+label+' · visual similarity only')
                messagebox.showinfo('Object taught','Saved “'+label+'” and a compact visual signature. MINI AI will try to match similar-looking crops. This is example-based visual memory, not neural-model retraining; lighting/background changes can cause mistakes.',parent=win)
            except Exception as e: messagebox.showerror('Teaching failed',str(e),parent=win)
        def save_observation():
            frame=state.get('snapshot') if state.get('snapshot') is not None else state.get('frame')
            if frame is None: messagebox.showwarning('Capture first','Wait for a camera frame first.',parent=win); return
            note=desc.get('1.0','end').strip()
            if not note.strip(): note=simpledialog.askstring('Describe scene','What should MINI AI remember?',parent=win) or ''
            if not note.strip(): return
            folder=APP_DIR/'eyes'; folder.mkdir(parents=True,exist_ok=True); path=folder/('eye_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.jpg')
            try:
                if not cv2.imwrite(str(path),frame,[int(cv2.IMWRITE_JPEG_QUALITY),65]): raise RuntimeError('JPEG could not be written')
                d=digest(path.name+'\n'+note)
                with db() as con: con.execute('INSERT INTO eye_observations(image_path,description,created,digest) VALUES(?,?,?,?)',(str(path),note,stamp(),d))
                add_knowledge('Visual memory: '+path.name,note+'\nImage file: '+str(path),'camera visual journal')
                status.set('Saved compressed visual memory locally: '+path.name); self.refresh_status()
            except Exception as e: messagebox.showerror('Save failed',str(e),parent=win)
        def analyze_snapshot():
            """Analyze captured image using local detector and saved visual memory only."""
            frame=state.get('snapshot')
            if frame is None:
                messagebox.showwarning('Capture first','Click Capture snapshot first.',parent=win); return
            detections=[d for d in state.get('detections',[]) if not str(d.get('label','')).startswith('UNKNOWN')]
            labels=[]
            for d in detections:
                label=str(d.get('label','')).replace(' (taught)','').strip()
                if label and label not in labels: labels.append(label)
            saved=[]
            try:
                with db() as con:
                    rows=con.execute('SELECT description FROM eye_observations ORDER BY id DESC LIMIT 5').fetchall()
                saved=[r[0] for r in rows if r and r[0]]
            except Exception: pass
            if labels:
                confidence='; '.join(f"{d.get('label','object')} ({int(float(d.get('confidence',0))*100)}%)" for d in detections[:6])
                answer='OFFLINE CAMERA ANALYSIS\n\nLikely visible objects: '+', '.join(labels)+'.\n\nDetector estimates: '+confidence+'.\n\nWhat this means: these are category guesses from the local 80-category detector, not a human-level understanding of the full image. Check the boxes and labels against the actual scene.\n\n'+('Project ideas are available from “What can I make?”. Use “Teach boxed object” to save a label if a box is wrong.')
            else:
                answer='OFFLINE CAMERA ANALYSIS\n\nI could not confidently identify an object from the detector’s supported categories in this snapshot. That does not mean the image is empty. Try moving the object closer, improving the light, and keeping the object fully in frame. Then use “Teach boxed object” to save a local example.\n\nFor project suggestions, click “What can I make?”; it can also offer starter projects when no objects are recognised.'
            if saved:
                answer+='\n\nRecent saved visual notes (memory, not image recognition):\n- '+'\n- '.join(saved[:3])
            self.add_msg('MINI AI Eyes',answer)
            status.set('Snapshot analyzed locally · no URL, account, or external vision server used')
        ttk.Button(buttons,text='Retry camera',command=retry_camera).pack(side='left',padx=(0,5))
        ttk.Button(buttons,text='Capture snapshot',command=capture,style='Accent.TButton').pack(side='left',padx=5)
        def what_can_i_make():
            found=[d.get('label','') for d in state.get('detections',[]) if d.get('label') and not d.get('label','').startswith('UNKNOWN')]
            found += [r[0] for r in saved_labels()[:12]]
            terms=' '.join(found).lower()
            ideas=[]
            def add(title,parts,steps): ideas.append((title,parts,steps))
            if any(x in terms for x in ('arduino','circuit','breadboard','wire','battery','led','resistor')):
                add('LED tester / mini light','LED, resistor, battery or Arduino','Identify LED polarity, add a current-limiting resistor, then test at low voltage. Never connect an LED directly to a battery without a resistor.')
                add('Simple sensor station','Arduino, wires, sensor','Connect a compatible sensor to a microcontroller and display readings. Check each part’s voltage and pinout first.')
            if any(x in terms for x in ('bottle','cup','bowl','container','plastic')):
                add('Desk organiser','clean bottle/container, scissors','With adult supervision, clean the container and cut only safe edges; cover sharp edges and use it to store small parts.')
                add('Self-watering planter','container, soil, plant','Use a clean container as a planter with drainage and a tray; avoid using containers that held chemicals.')
            if any(x in terms for x in ('cardboard','book','paper','box','scissors')):
                add('Mini storage box','cardboard, paper, tape','Fold a small box, reinforce corners with tape, and label compartments for parts or cables.')
                add('Phone stand','cardboard, ruler, tape','Cut two interlocking slots and test stability with the phone before using it near liquids or heat.')
            if any(x in terms for x in ('laptop','keyboard','mouse','cell phone','tv','remote')):
                add('Desk cable organiser','paper/cardboard, cable ties or clips','Route cables without pinching them. Keep ventilation openings clear and do not open mains-powered equipment.')
            if any(x in terms for x in ('plant','potted plant','bottle','cup')):
                add('Plant care monitor plan','plant, container, optional moisture sensor','Record light and watering needs first. If adding electronics, use a low-voltage sensor and keep water away from exposed circuits.')
            if not ideas:
                add('What can I make? — starter ideas','paper, cardboard, tape, recycled clean containers','Try a desk organiser, cardboard phone stand, labelled storage box, or a simple drawing/model of the objects in view. The camera identifies only likely categories, so confirm the parts yourself.')
            result='Objects currently detected / taught: '+(', '.join(dict.fromkeys(found)) if found else 'No confident object labels yet')+'\n\nPROJECT IDEAS\n'
            for i,(title,parts,steps) in enumerate(ideas[:6],1): result+=f'{i}. {title}\nParts: {parts}\nHow: {steps}\n\n'
            result+='Safety: confirm materials and electrical ratings yourself. These suggestions are based on visible labels, not a perfect understanding of the scene.'
            dlg=tk.Toplevel(win); dlg.title('What can I make in camera?'); dlg.geometry('640x520')
            out=tk.Text(dlg,wrap='word',font=('Segoe UI',10),bg='#ffffff',fg='#171717'); out.pack(fill='both',expand=True,padx=12,pady=12); out.insert('1.0',result); out.configure(state='disabled')
        ttk.Button(buttons,text='What can I make?',command=what_can_i_make,style='Accent.TButton').pack(side='left',padx=5)
        ttk.Button(buttons,text='Teach boxed object',command=teach_object,style='Accent.TButton').pack(side='left',padx=5)
        ttk.Button(buttons,text='Save visual memory',command=save_observation).pack(side='left',padx=5)
        ttk.Button(buttons,text='Analyze snapshot offline',command=analyze_snapshot).pack(side='left',padx=5)
        def close():
            state['closed']=True; state['stop'].set()
            try:
                if state.get('after'): win.after_cancel(state['after'])
            except Exception: pass
            try:
                if state['cap'] is not None: state['cap'].release()
            except Exception: pass
            win.destroy()
        win.protocol('WM_DELETE_WINDOW',close)
        start_camera_worker()
        state['detector_started']=True
        threading.Thread(target=detector_worker,daemon=True).start()

    def system_diagnostics(self):
        import platform,sys,sqlite3
        with db() as con:
            counts={name:con.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0] for name,table in [('Knowledge','knowledge'),('Chat messages','chats'),('Lessons','lessons'),('Notes','notes'),('Tasks','tasks'),('Flashcards','flashcards')]}
        report=['MINI AI SYSTEM DIAGNOSTICS','',f'Operating system: {platform.platform()}',f'Python: {sys.version.split()[0]}',f'Architecture: {platform.architecture()[0]}',f'CPU: {platform.processor() or "unknown"} · logical threads: {os.cpu_count() or "unknown"}',f'Installed RAM: {detect_system_ram_gb():.1f} GB',f'Free disk on app drive: {shutil.disk_usage(str(APP_DIR)).free/1024**3:.1f} GB',f'Database: {DB_PATH}',f'Database exists: {DB_PATH.exists()}',f'Storage used: {storage_bytes()/1024**2:.2f} MB',f'Storage limit: {SETTINGS.get("storage_limit_gb",200)} GB','', 'Local records:']+[f'{k}: {v}' for k,v in counts.items()]
        report += ['', 'Capability status:', 'Local memory/search: available', 'Online research: '+('enabled' if SETTINGS.get('online_research',True) and not SETTINGS.get('offline_only',False) else 'disabled'), 'Language model: '+('installed: '+str(SETTINGS.get('llm_model_file','mini_ai_llm_model.json')) if (APP_DIR/'models'/str(SETTINGS.get('llm_model_file','mini_ai_llm_model.json'))).exists() else 'not installed; use MINI AI LLM status'), 'Speech/image/video generation: not bundled', '']
        win=tk.Toplevel(self.root);win.title('MINI AI System Diagnostics');win.geometry('760x520');box=tk.Text(win,wrap='word');box.pack(fill='both',expand=True,padx=10,pady=10);box.insert('1.0','\n'.join(report));box.configure(state='disabled')
        ttk.Button(win,text='Copy report',command=lambda:(win.clipboard_clear(),win.clipboard_append('\n'.join(report)))).pack(pady=(0,10))

    def hardware_advisor(self):
        import platform
        ram = detect_system_ram_gb()
        cpu = os.cpu_count() or 2
        free_gb = shutil.disk_usage(str(APP_DIR)).free / (1024 ** 3)
        if ram < 6:
            profile = 'MINI AI AutoLearn LLM · 0.5B'; recommendation = 'Can test basic local chat, but answers will be noticeably weaker than ChatGPT. Close other apps and keep context small.'
        elif ram < 12:
            profile = 'Balanced · Qwen 2.5 3B'; recommendation = 'A reasonable test target for this laptop. Allow several GB of free disk and expect CPU inference to be slower.'
        elif ram < 24:
            profile = 'Stronger · Qwen 2.5 7B'; recommendation = 'Likely the strongest of these profiles to try. Keep other apps closed; CPU-only generation may be slow.'
        else:
            profile = 'MINI AI AutoLearn LLM · 0.5B'; recommendation = 'Try the larger profile only if you have at least 20 GB free disk and can tolerate slow CPU inference. GPU acceleration depends on runtime support.'
        report = (f'MINI AI — HARDWARE & MODEL FIT\n\nComputer: {platform.platform()}\nCPU: {platform.processor() or "unknown"}\nLogical CPU threads: {cpu}\nInstalled RAM: {ram:.1f} GB\nFree disk: {free_gb:.1f} GB\n\nSuggested first model: {profile}\n{recommendation}\n\nImportant: these are estimates, not a compatibility guarantee. The app currently uses a broad-compatibility CPU runtime, so a powerful NVIDIA GPU may not be fully used. A local model is not automatically as capable as ChatGPT.\n\nTry different model profiles on each laptop, then compare response quality, speed, memory pressure and stability.')
        win = tk.Toplevel(self.root); win.title('MINI AI Hardware & Model Fit'); win.geometry('720x440')
        box = tk.Text(win, wrap='word'); box.pack(fill='both', expand=True, padx=10, pady=10); box.insert('1.0', report); box.configure(state='disabled')
        bar = ttk.Frame(win); bar.pack(fill='x', padx=10, pady=(0,10))
        ttk.Button(bar, text='Copy report', command=lambda:(win.clipboard_clear(),win.clipboard_append(report))).pack(side='left')
        ttk.Button(bar, text='Install / repair MINI AI AutoLearn LLM', command=lambda:(win.destroy(),self.setup_local_llm())).pack(side='left',padx=8)

    def open_url(self):
        url=simpledialog.askstring('Open URL','Enter a trusted http:// or https:// URL:',parent=self.root)
        if not url:return
        url=url.strip()
        if url.startswith(('https://','http://')):
            webbrowser.open(url)
            self.add_msg('MINI AI','Opened URL in your default browser: '+url)
        else: messagebox.showwarning('URL not opened','For safety, the URL must begin with http:// or https://.')

    def restore_backup(self):
        src=filedialog.askopenfilename(title='Choose MINI AI backup',filetypes=[('ZIP backup','*.zip')])
        if not src:return
        if not messagebox.askyesno('Restore backup','Restoring will replace current database/settings files. Make a backup first if needed. Continue?'):return
        try:
            with zipfile.ZipFile(src,'r') as z:
                allowed={'personal_ai.sqlite3','settings.json'}
                names=set(z.namelist())
                if not names.intersection(allowed): raise ValueError('This ZIP does not look like a MINI AI backup.')
                for name in allowed:
                    if name in names:
                        target=APP_DIR/name
                        target.write_bytes(z.read(name))
            messagebox.showinfo('Restore complete','Backup restored. Restart MINI AI to reload all restored data.')
            self.refresh_status()
        except Exception as e: messagebox.showerror('Restore failed',str(e))

    def backup(self):
        dest=filedialog.asksaveasfilename(title='Save private backup',defaultextension='.zip',filetypes=[('ZIP backup','*.zip')],initialfile='MINI_AI_LITE_X_backup.zip')
        if not dest:return
        try:
            with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
                for p in APP_DIR.iterdir():
                    if p.is_file() and p.name != 'personal_ai.sqlite3-wal' and p.name != 'personal_ai.sqlite3-shm': z.write(p,p.name)
            messagebox.showinfo('Backup',f'Backup saved to:\n{dest}')
        except Exception as e: messagebox.showerror('Backup failed',str(e))
    def settings(self):
        win=tk.Toplevel(self.root); win.title('All settings'); win.geometry('560x650'); win.transient(self.root); win.configure(bg='#eeeeee')
        st=ttk.Style(win)
        st.configure('Settings.TFrame',background='#eeeeee')
        st.configure('Settings.TLabel',background='#eeeeee',foreground='#202020')
        st.configure('Settings.TCheckbutton',background='#eeeeee',foreground='#202020')
        st.map('Settings.TCheckbutton',foreground=[('active','#111111')],background=[('active','#eeeeee')])
        st.configure('Settings.TEntry',fieldbackground='#ffffff',foreground='#111111')
        st.configure('Settings.TButton',background='#d5d5d5',foreground='#111111')
        canvas=tk.Canvas(win,highlightthickness=0,bg='#eeeeee'); scroll=ttk.Scrollbar(win,orient='vertical',command=canvas.yview); inner=ttk.Frame(canvas,padding=16,style='Settings.TFrame')
        inner.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.create_window((0,0),window=inner,anchor='nw'); canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side='left',fill='both',expand=True); scroll.pack(side='right',fill='y')
        ttk.Label(inner,style='Settings.TLabel',text='Personal AI settings',font=('Segoe UI',15,'bold')).pack(anchor='w',pady=(0,4))
        ttk.Label(inner,style='Settings.TLabel',text='AutoLearn can search public websites on its own, without you entering a webpage. It saves source-linked text locally for later offline retrieval. Internet use can be disabled below. This updates the saved knowledge library; it does not retrain the LLM weights.',wraplength=500).pack(anchor='w',pady=(0,10))
        val=tk.StringVar(value=str(SETTINGS.get('storage_limit_gb',200)))
        ttk.Label(inner,style='Settings.TLabel',text='Maximum app storage (GB; 0.1–200)').pack(anchor='w'); ttk.Entry(inner,style='Settings.TEntry',textvariable=val).pack(fill='x',pady=(3,10))
        flags={
          'online_research':('Allow online research when requested',True),
          'offline_only':('Offline-only mode (blocks research)',False),
          'auto_learn':('AutoLearn research references',True),
          'auto_compare':('Auto Compare readable source text',True),
          'auto_learn_imports':('Automatically save imported documents to memory',True),
          'auto_topic_learning':('AutoLearn: automatically find and save a rotating topic every 5 minutes (internet required; no URL entry)',True),
          'auto_save_chats':('Save chat messages locally',True),
          'show_sources':('Show source notes in answers',True),
        }
        vars={}
        for key,(label,default) in flags.items():
            vars[key]=tk.BooleanVar(value=SETTINGS.get(key, SETTINGS.get('auto_research',default) if key=='auto_learn' else default))
            ttk.Checkbutton(inner,style='Settings.TCheckbutton',text=label,variable=vars[key]).pack(anchor='w',pady=3)
        ttk.Separator(inner).pack(fill='x',pady=12)
        ttk.Label(inner,style='Settings.TLabel',text='ONLINE AI REASONING + OFFLINE FALLBACK',font=('Segoe UI',11,'bold')).pack(anchor='w',pady=(0,4))
        ttk.Label(inner,style='Settings.TLabel',text='Optional: online AI is tried first when enabled and internet is available. If it fails or Offline-only is enabled, MINI AI uses its local language engine. Online providers may receive the text you send; API keys are stored in local settings.',wraplength=500).pack(anchor='w',pady=(0,8))
        online_ai_var=tk.BooleanVar(value=SETTINGS.get('online_ai_enabled',False))
        ttk.Checkbutton(inner,style='Settings.TCheckbutton',text='Enable online AI reasoning (requires provider settings)',variable=online_ai_var).pack(anchor='w',pady=3)
        api_base=tk.StringVar(value=str(SETTINGS.get('llm_base_url','https://api.openai.com')))
        api_model=tk.StringVar(value=str(SETTINGS.get('online_ai_model','gpt-4.1-mini')))
        api_key_var=tk.StringVar(value=str(SETTINGS.get('llm_api_key','')))
        ttk.Label(inner,style='Settings.TLabel',text='OpenAI-compatible HTTPS API base URL').pack(anchor='w',pady=(8,2)); ttk.Entry(inner,style='Settings.TEntry',textvariable=api_base).pack(fill='x')
        ttk.Label(inner,style='Settings.TLabel',text='Provider model name').pack(anchor='w',pady=(8,2)); ttk.Entry(inner,style='Settings.TEntry',textvariable=api_model).pack(fill='x')
        ttk.Label(inner,style='Settings.TLabel',text='API key (leave blank to use offline mode)').pack(anchor='w',pady=(8,2)); ttk.Entry(inner,style='Settings.TEntry',textvariable=api_key_var,show='*').pack(fill='x')
        ttk.Label(inner,style='Settings.TLabel',text='Maximum import size per file (MB)').pack(anchor='w',pady=(10,2))
        maxmb=tk.StringVar(value=str(SETTINGS.get('max_import_mb',25))); ttk.Entry(inner,style='Settings.TEntry',textvariable=maxmb).pack(fill='x')
        ttk.Label(inner,style='Settings.TLabel',text='Maximum search results (1–20)').pack(anchor='w',pady=(10,2))
        maxres=tk.StringVar(value=str(SETTINGS.get('max_results',8))); ttk.Entry(inner,style='Settings.TEntry',textvariable=maxres).pack(fill='x')
        ttk.Label(inner,style='Settings.TLabel',text='Research timeout (seconds; 3–60)').pack(anchor='w',pady=(10,2))
        timeout=tk.StringVar(value=str(SETTINGS.get('research_timeout',12))); ttk.Entry(inner,style='Settings.TEntry',textvariable=timeout).pack(fill='x')
        ttk.Separator(inner).pack(fill='x',pady=12)
        ttk.Label(inner,style='Settings.TLabel',text='Multi-engine research').pack(anchor='w',pady=(0,4))
        engine_vars={}
        auto_search=tk.BooleanVar(value=SETTINGS.get('auto_search_questions',True))
        ttk.Checkbutton(inner,style='Settings.TCheckbutton',text='Automatically search online for factual questions (when internet is enabled)',variable=auto_search).pack(anchor='w',pady=3)
        for key,label,default in [('search_duckduckgo','Use DuckDuckGo HTML search',True),('search_bing','Use Bing RSS search',True),('search_mojeek','Use Mojeek search',True),('fetch_full_pages','Read full pages where possible',True)]:
            engine_vars[key]=tk.BooleanVar(value=SETTINGS.get(key,default)); ttk.Checkbutton(inner,style='Settings.TCheckbutton',text=label,variable=engine_vars[key]).pack(anchor='w',pady=2)
        engine_vars['youtube_transcripts']=tk.BooleanVar(value=SETTINGS.get('youtube_transcripts',True)); ttk.Checkbutton(inner,style='Settings.TCheckbutton',text='Try publicly available YouTube captions/transcripts',variable=engine_vars['youtube_transcripts']).pack(anchor='w',pady=2)
        ttk.Label(inner,style='Settings.TLabel',text='Maximum full pages to read per research (0–10)').pack(anchor='w',pady=(8,2))
        maxpages=tk.StringVar(value=str(SETTINGS.get('max_pages_to_read',5))); ttk.Entry(inner,style='Settings.TEntry',textvariable=maxpages).pack(fill='x')
        ttk.Label(inner,style='Settings.TLabel',text='AutoLearn topic interval (minutes; 5–1440)').pack(anchor='w',pady=(10,2))
        topic_interval=tk.StringVar(value=str(SETTINGS.get('auto_topic_interval_minutes',5))); ttk.Entry(inner,style='Settings.TEntry',textvariable=topic_interval).pack(fill='x')
        persona=tk.StringVar(value=str(SETTINGS.get('persona','Friendly, thoughtful, honest')))
        ttk.Label(inner,style='Settings.TLabel',text='Assistant style/persona').pack(anchor='w',pady=(10,2)); ttk.Entry(inner,style='Settings.TEntry',textvariable=persona).pack(fill='x')
        def save():
            try:
                n=float(val.get()); mb=float(maxmb.get()); mr=int(maxres.get()); to=int(timeout.get()); mp=int(maxpages.get()); ti=int(topic_interval.get())
                if not .1<=n<=200 or not 1<=mb<=1024 or not 1<=mr<=20 or not 3<=to<=60 or not 0<=mp<=10 or not 5<=ti<=1440: raise ValueError('Values outside allowed limits')
            except Exception: messagebox.showerror('Invalid settings','Storage: 0.1–200 GB; import: 1–1024 MB; results: 1–20; timeout: 3–60 seconds.',parent=win); return
            SETTINGS.update({k:v.get() for k,v in vars.items()}); SETTINGS['auto_search_questions']=auto_search.get(); SETTINGS.update({'storage_limit_gb':n,'max_import_mb':mb,'max_results':mr,'research_timeout':to,'max_pages_to_read':mp,'auto_topic_interval_minutes':ti,'persona':persona.get().strip() or DEFAULTS['persona'],'auto_research':vars['auto_learn'].get()}); SETTINGS.update({k:v.get() for k,v in engine_vars.items()})
            SETTINGS.update({'online_ai_enabled':online_ai_var.get(),'llm_base_url':api_base.get().strip() or 'https://api.openai.com','online_ai_model':api_model.get().strip() or 'gpt-4.1-mini','llm_api_key':api_key_var.get().strip()})
            if SETTINGS['offline_only']: SETTINGS['online_research']=False
            SETTINGS_PATH.write_text(json.dumps(SETTINGS,indent=2),encoding='utf-8'); self.refresh_status(); win.destroy()
            messagebox.showinfo('Settings saved','Settings saved locally. AutoLearn will search a rotating topic every five minutes by default when online research is enabled and Offline-only mode is off. It does not require you to enter a webpage. The LLM uses saved material as retrieved context; it does not retrain its neural weights.')
        ttk.Separator(inner).pack(fill='x',pady=12)
        ttk.Label(inner,style='Settings.TLabel',text='MINI AI AUTOLEARN LLM (LOCAL ONLY)',font=('Segoe UI',11,'bold')).pack(anchor='w',pady=(0,4))
        ttk.Label(inner,style='Settings.TLabel',text='MINI AI AutoLearn LLM runs locally with no API key or cloud AI account. AutoLearn adds source-linked knowledge to local memory for retrieval; it does not rewrite the model neural weights. This laptop uses one small CPU model for reliability. Larger models are disabled in this edition. The model needs RAM, disk space and patience. Even the largest option is not guaranteed to match ChatGPT.',wraplength=500).pack(anchor='w',pady=(0,8))
        ttk.Button(inner,text='Install / repair MINI AI AutoLearn LLM',command=self.setup_local_llm,style='Accent.TButton').pack(anchor='w',pady=(0,8))
        _mf=APP_DIR/'models'/str(SETTINGS.get('llm_model_file','mini_ai_llm_model.json'))
        ttk.Label(inner,style='Settings.TLabel',text='Model status: '+(('installed · '+str(SETTINGS.get('llm_model_file'))) if _mf.exists() else 'not installed yet')).pack(anchor='w',pady=(0,8))
        ttk.Button(inner,text='Save all settings',command=save,style='Accent.TButton').pack(anchor='w',pady=16)

    def about(self):
        messagebox.showinfo('About this edition','MINI AI AutoLearn LLM\n\nChat history is compressed automatically in the local database to reduce disk use while remaining readable in Saved chats.\n\nIncludes local SQLite memory, lessons, file import, saved chats, memory search/deletion, conversation export, backups, multi-engine on-demand research, developer Code Lab, notes, tasks, flashcards, text tools, hardware advice, and automatic Qwen 2.5 0.5B or 1.5B local model selection for low-memory systems. Models are downloaded separately and require no API key or paid AI service.\n\nThree modes: Chatbot (conversation only, no tools), LLM Chat (conversation with utility commands), and AI Agent (research and task-oriented help). AutoLearn is configured for a five-minute topic cycle by default. The agent can use explicit research workflows and app tools; it does not have unrestricted autonomous computer access. Expression and app-state awareness are simulated software features, not human consciousness. Saved memory is retrieval, not neural retraining.\n\nThis is not equivalent to ChatGPT: even a larger local model may be weaker, and speed depends on RAM, CPU and runtime compatibility. Online research, factual correctness, YouTube captions and compatibility with older Windows versions are not guaranteed. Offline image/video generation, speech recognition and a compiled EXE installer are not bundled. Eyes attempts to download YOLOv4-tiny and detect 80 COCO categories automatically on first use; if the download or model load fails, detection does not work until repaired. Unknown scenes get a teachable fallback box. User-taught visual labels use colour-histogram similarity, not neural retraining, and can be wrong. Python with tkinter is required.\n\nPrivate data folder:\n'+str(APP_DIR))
    def refresh_status(self):
        try:
            with db() as con: k=con.execute('SELECT COUNT(*) FROM knowledge').fetchone()[0]; c=con.execute('SELECT COUNT(*) FROM chats').fetchone()[0]
            used=storage_bytes()/1024**3; lim=100.0
            self.status.configure(text=f'Knowledge: {k} · Chat items: {c} · Storage: {used:.3f}/{lim:g} GB')
        except Exception: self.status.configure(text='Local database starting…')
    def load_recent(self):
        with db() as con: rows=[(r[0],unpack_chat_body(r[1])) for r in con.execute('SELECT role,body FROM chats ORDER BY id DESC LIMIT 30').fetchall()]
        if rows:
            self.chat.configure(state='normal'); self.chat.delete('1.0','end')
            for role,body in reversed(rows): self.chat.insert('end',f'{role}\n{body}\n\n')
            self.chat.configure(state='disabled'); self.chat.see('end')

def main():
    db(); root=tk.Tk(); App(root); root.mainloop()
if __name__=='__main__': main()
