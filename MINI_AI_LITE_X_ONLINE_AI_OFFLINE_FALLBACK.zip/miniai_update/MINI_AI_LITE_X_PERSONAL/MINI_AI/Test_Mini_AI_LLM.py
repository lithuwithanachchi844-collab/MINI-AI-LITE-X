import tempfile, os
from pathlib import Path
# Importing uses the normal per-user model path, but no model downloads occur.
from mini_ai_llm import MiniAILLM
m=MiniAILLM()
assert m.learn_text('The weather station measures temperature humidity and light levels. The Arduino reads sensors and stores weather data locally.', 'self-test') >= 8
assert 'I am MINI AI' in m.answer('Who are you?')
print('MINI AI internal language engine self-test passed.')
