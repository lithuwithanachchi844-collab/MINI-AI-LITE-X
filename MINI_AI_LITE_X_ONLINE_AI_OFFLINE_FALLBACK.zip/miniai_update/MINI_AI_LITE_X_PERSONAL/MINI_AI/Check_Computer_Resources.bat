@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (py -3 Check_Computer_Resources.py) else (python Check_Computer_Resources.py)
pause
