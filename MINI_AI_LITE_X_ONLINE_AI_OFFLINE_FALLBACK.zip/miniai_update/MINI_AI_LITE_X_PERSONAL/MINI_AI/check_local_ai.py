"""Diagnose MINI AI's local model installation without changing user data."""
import json, os, sys, urllib.request, urllib.error
from pathlib import Path
app = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'MiniAILiteX_PersonalAI_Max'
print('MINI AI LOCAL MODEL DIAGNOSTIC')
print('App data:', app)
settings_path = app / 'settings.json'
settings = {}
try:
    settings = json.loads(settings_path.read_text(encoding='utf-8'))
    print('Settings: readable')
except Exception as e:
    print('Settings: unavailable or unreadable:', e)
base = str(settings.get('llm_base_url', 'http://127.0.0.1:5001/v1')).rstrip('/')
model_name = str(settings.get('llm_model_file', 'qwen2.5-0.5b-instruct-q4_k_m.gguf'))
checks = [
    ('Runtime', app/'runtime'/'koboldcpp_oldcpu.exe', 5_000_000, b'MZ'),
    ('Model', app/'models'/model_name, 250_000_000 if '0.5b' in model_name.lower() else 700_000_000, b'GGUF'),
]
for label, path, min_size, header in checks:
    try:
        size = path.stat().st_size
        with path.open('rb') as f: valid_header = f.read(len(header)) == header
        print(f'{label}: {"OK" if size >= min_size and valid_header else "INVALID/INCOMPLETE"} | {size:,} bytes | {path}')
        if not valid_header: print('  Expected file header:', header)
        if size < min_size: print('  File is smaller than expected; run Repair_Local_AI.bat')
    except OSError as e:
        print(f'{label}: MISSING | {path} | {e}')
try:
    req = urllib.request.Request(base+'/models', headers={'User-Agent':'MINI-AI-Diagnostic/1.0'})
    with urllib.request.urlopen(req, timeout=3) as r:
        print('Local server: ONLINE | HTTP', r.status)
        print('Server response:', r.read(1000).decode('utf-8','replace'))
except Exception as e:
    print('Local server: OFFLINE/NOT READY |', repr(e))
for name in ('llm_start_error.txt','llm_runtime.log'):
    path=app/name
    if path.exists():
        try:
            data=path.read_text(encoding='utf-8',errors='replace')[-3500:]
            print('\n---',name,'(last 3500 chars) ---\n',data)
        except Exception as e: print(name, 'could not read:', e)
print('\nIf files are missing or invalid, run Repair_Local_AI.bat while online. If the runtime says it cannot run on this PC, send this diagnostic output.')
