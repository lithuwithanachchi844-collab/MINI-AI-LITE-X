@echo off
setlocal
cd /d "%~dp0"
title MINI AI - Repair local language model
 echo MINI AI local language-model repair
 echo This checks the old-CPU runtime and GGUF model, removes invalid/incomplete downloads, and retries setup.
 echo Internet is needed for any missing or damaged downloads.
 echo.
call Setup_Local_LLM.bat
if errorlevel 1 (
  echo.
  echo REPAIR FAILED. Please keep this window open and send the error text.
  pause
  exit /b 1
)
echo.
echo Setup finished. Close MINI AI fully, then reopen Start_MINI_AI.bat.
echo If the model still fails, inspect %%LOCALAPPDATA%%\MiniAILiteX_PersonalAI_Max\llm_runtime.log and llm_start_error.txt.
pause
