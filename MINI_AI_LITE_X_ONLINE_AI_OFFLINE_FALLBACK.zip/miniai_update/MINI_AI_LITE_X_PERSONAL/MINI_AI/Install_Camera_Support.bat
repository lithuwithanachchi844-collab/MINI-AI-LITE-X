@echo off
setlocal
cd /d "%~dp0"
title MINI AI - Camera Support
set "CAM_HOME=%USERPROFILE%\MINI_AI_CAMERA"
set "CAM_PY=%CAM_HOME%\Scripts\python.exe"
echo Installing CPU-compatible OpenCV support for MINI AI.
echo This uses a separate Python 3.11 environment and does not replace Python 3.13.
if not exist "%CAM_PY%" (
  where py >nul 2>nul
  if errorlevel 1 (
    echo Python launcher not found. Install Python 3.11 64-bit first.
    pause
    exit /b 1
  )
  py -3.11 -m venv "%CAM_HOME%"
  if errorlevel 1 (
    echo Could not create the Python 3.11 environment.
    pause
    exit /b 1
  )
)
"%CAM_PY%" -m pip install --disable-pip-version-check numpy==1.26.4 opencv-python==4.10.0.84
if errorlevel 1 (
  echo Installation failed. Keep this window open and send the error text.
  pause
  exit /b 1
)
"%CAM_PY%" -c "import numpy,cv2; print('NumPy:',numpy.__version__); print('OpenCV:',cv2.__version__)"
if errorlevel 1 (
  echo The camera libraries did not import successfully.
  pause
  exit /b 1
)
echo.
echo Camera libraries installed. Start MINI AI with Start_MINI_AI.bat.
echo No separate Windows Camera app is needed.
pause
