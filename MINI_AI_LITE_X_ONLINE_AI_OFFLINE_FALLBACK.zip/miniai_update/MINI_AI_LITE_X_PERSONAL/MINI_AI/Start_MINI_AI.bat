@echo off
setlocal
cd /d "%~dp0"
title MINI AI LITE X PERSONAL - AutoLearn LLM
rem Always open the app first. The language model is optional and can be installed from inside the app.
rem Prefer the known working Python 3.11 camera environment on the user's older CPU.
set "CAM_PY=%USERPROFILE%\MINI_AI_CAMERA\Scripts\python.exe"
if exist "%CAM_PY%" goto launch_camera_python
where py >nul 2>nul
if not errorlevel 1 (
  py -3.11 --version >nul 2>nul
  if not errorlevel 1 goto launch_py311
)
where py >nul 2>nul
if not errorlevel 1 goto launch_py
where python >nul 2>nul
if not errorlevel 1 goto launch_python
echo Python 3 was not found. Install Python 3.11 64-bit with Tcl/Tk included.
pause
exit /b 1
:launch_camera_python
"%CAM_PY%" mini_ai_lite_x.py
goto check_error
:launch_py311
py -3.11 mini_ai_lite_x.py
goto check_error
:launch_py
py -3 mini_ai_lite_x.py
goto check_error
:launch_python
python mini_ai_lite_x.py
goto check_error
:check_error
if errorlevel 1 (
  echo.
  echo MINI AI stopped with an error. See %LOCALAPPDATA%\MiniAILiteX_PersonalAI_Max\llm_runtime.log if the local language model failed.
  pause
)
