# Third-party notices and licence checklist

This release does **not** bundle third-party Python packages or model weights.

## Python

The app uses Python standard-library modules including Tkinter, SQLite, urllib,
threading, JSON, and math. Python is distributed under the Python Software
Foundation License; see <https://docs.python.org/3/license.html>. Users install
Python separately.

## Optional local inference runtime

- `llama-cpp-python`: project licence is MIT; source and current licence are at
  <https://github.com/abetlen/llama-cpp-python>. It may pull/build native
  dependencies depending on platform and installer configuration. Check current
  dependency notices and wheel provenance before redistributing a bundled build.
- `llama.cpp`: MIT; <https://github.com/ggml-org/llama.cpp>.

The app installs the runtime only after the user clicks the runtime-install button.
It is not included in the ZIP.

## Optional Qwen model download

The app offers a quantized `Qwen2.5-0.5B-Instruct` GGUF file hosted by a third-party
quantization publisher. The original Qwen2.5 model family is published under the
Apache License 2.0; see the official model card and licence at
<https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct> and the exact GGUF repository
selected by the app at
<https://huggingface.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF>.

**Do not assume this notice substitutes for checking the exact current model
repository, model card, file provenance, and licence.** The weights are not
bundled or redistributed by this release; users download them directly. Before
changing the download URL or redistributing model weights, re-check and comply
with the exact terms, notices, and any attribution requirements.

## Optional online providers

No provider SDK is bundled. The app uses Python's standard `urllib` to call a
user-configured OpenAI-compatible endpoint. Provider terms, privacy, data
retention, billing and API policies are controlled by that provider.

## Logos and branding

This project is not affiliated with or endorsed by OpenAI, Alibaba/Qwen, Hugging
Face, or the llama.cpp maintainers. “ChatGPT-inspired” describes the general dark
workspace style; OpenAI names and marks remain their respective owners' property.
