# Privacy notice

MINI AI LITE X is designed for local-first use. The app itself does not include
analytics or telemetry. This is a code-level description, not an independent audit.

## Data stored locally

Chat history, lessons, notes, tasks, and activity logs are stored in a SQLite file
under `%USERPROFILE%\MINI_AI_LITE_X_Data`. These records are not encrypted by the
app. Anyone who can access your Windows account/files may be able to read them.

## Optional local model

When **Offline local model** is selected, chat inference runs on the device after
the model and runtime have been installed. First-time downloads contact the model
host. Local model files and chat database remain on the device unless the user
copies/shares them.

## Optional online AI

If you explicitly configure an online endpoint and select an online mode, the
prompt is sent to that endpoint. The provider's privacy and retention terms apply.
The API key is protected with Windows DPAPI when saved on Windows, but is decrypted
in process memory when used. Do not commit keys or send them to support channels.

## Web research

The Web Research tool makes a network request to the public webpage URL supplied
by the user. The target website may see your IP address and request metadata.

## Optional remote tracker

The tracker can show app chat/activity records and issue supported commands to the
app. Treat the control token as a password. It listens on localhost by default.
Remote access should only be configured through a trusted private VPN; do not
expose the server directly to the public internet. Activity is only what the app
records, not all activity on the computer.

## Delete data

Use the app's clear/export controls where available, and close the app before
manually removing `%USERPROFILE%\MINI_AI_LITE_X_Data`. Deleting this folder removes
local chat, lessons, notes, tasks, settings, model files, and tracker state.
Back up anything you need before deletion.
