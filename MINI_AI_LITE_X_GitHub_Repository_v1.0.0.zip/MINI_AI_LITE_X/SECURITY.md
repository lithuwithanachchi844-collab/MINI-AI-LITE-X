# Security policy

Please do not report vulnerabilities by publishing secrets or private chat logs.
Open a private security advisory on the GitHub repository if that feature is
available, or contact the maintainer through the contact channel listed on the
repository profile.

## Important threat boundaries

- Never commit API keys, passwords, tokens, local databases, model files, or user
  data. The repository `.gitignore` excludes common local files.
- API-key encryption at rest on Windows does not protect against malware or code
  running as the same user.
- Prompt instructions and moderation do not guarantee safe outputs.
- The optional tracker is powerful over the features it exposes. Keep it private,
  use a strong token, and never expose its port directly to the internet.
- This public preview has not undergone an external security audit.
