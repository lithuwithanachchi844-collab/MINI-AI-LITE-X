# Contributing

1. Open an issue describing the bug or proposed improvement. Remove private data.
2. For code changes, explain the behaviour and how you checked it.
3. Do not submit API keys, passwords, access tokens, databases, downloaded model
   weights, or personal chat logs.
4. Keep default behaviour local-first and make any network transmission explicit.
5. Check all third-party licences before adding dependencies or redistributing
   binaries, fonts, images, models, or other assets.
