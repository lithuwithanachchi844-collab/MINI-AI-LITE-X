# Publish MINI AI LITE X on GitHub (free)

This folder is a prepared repository snapshot. It has not been uploaded to GitHub
on your behalf; sign in to your own GitHub account to publish it.

## Create the repository

1. Sign in at <https://github.com/> and select **New repository**.
2. Name it `MINI-AI-LITE-X` (or another name you own).
3. Choose **Public** if you want public distribution, select **MIT License** only if
   you accept the included licence, and create the repository. If creating from
   this prepared source, you can instead upload the included files as the first
   commit; avoid creating duplicate README/LICENSE files on GitHub.
4. Upload the contents of this `MINI_AI_LITE_X` folder or use Git from a local copy.
   Keep the root `README.md`, `LICENSE`, `PRIVACY.md`, `SECURITY.md`, and
   `THIRD_PARTY_NOTICES.md` in the repository root.
5. Review all files before making the repository public. Never commit API keys,
   tracker tokens, databases, logs, user data, or downloaded `.gguf` model weights.

## Create a public release

1. Open the repository's **Releases** page and select **Draft a new release**.
2. Create tag `v1.0.0` and title `MINI AI LITE X v1.0.0 — Public Preview`.
3. Upload these assets from the `release/` folder:
   - `MINI_AI_LITE_X_v1.0.0_Portable.zip`
   - `MINI_AI_LITE_X_Tracker_v1.0.0.zip` (optional, separate tracker)
4. Upload `MINI_AI_LITE_X_RELEASE_SHA256.txt` if you want users to verify downloaded
   assets. The checksum file is provided alongside the ZIPs in the release pack.
5. Use the following release notes:

   **Free local-first Windows preview.** Python 3.11/3.12 required. The portable
   ZIP is not a standalone EXE. Optional local AI runtime/model are downloaded
   separately; no paid API key is required for local use. See README and privacy
   notice for limitations, local data handling, model terms and setup.

6. Publish the release. Update the changelog and version/tag for future releases.

## Before public launch

- Test on a clean Windows 10 and Windows 11 machine, including Python 3.11/3.12.
- Test the offline rules mode with the internet disconnected.
- Test optional model download, runtime installation, inference and model licence.
- Test API-key save/replace/clear on Windows DPAPI; confirm no key appears in logs,
  exports, screenshots, issue templates, or tracker responses.
- Test tracker on localhost and private VPN only. Confirm the firewall is not opened
  and no router port forwarding is configured.
- Confirm all model and dependency licences and attribution requirements from their
  current upstream repositories. The optional model/runtime are not bundled.
- Replace the generic copyright line if desired and ensure you have the right to
  publish all source, names, artwork and included materials.
- Add your support/contact details and any additional legal/privacy notices you need.

## Important

This release is a **public preview**, not a fully tested commercial-grade build.
The source compile and archive integrity checks passed in the build environment,
but the full GUI, model inference, and Windows compatibility have not been tested
on every supported target. Do not claim those tests have passed unless you run them.
