# MINI AI LITE X — Free, Local-First Desktop AI

**Version:** 1.0.0 (public preview)  
**Platform:** Windows 10/11 (Python desktop app)  
**Price:** Free  
**Internet/API key:** Not required for offline local chat after one-time setup.

MINI AI LITE X is a lightweight Tkinter workspace with a local-first AI setting. It does not include a paid API key and does not bundle model weights. On first run, the app defaults to **Offline local model**, so it will not silently send chat to a cloud API. You can use **Offline rules only** without downloading a model. Online AI is an optional, explicit choice and may incur provider charges.

## Download and run (portable ZIP)

1. Download `MINI_AI_LITE_X_v1.0.0_Portable.zip` from the GitHub Releases page.
2. Extract the ZIP to a writable folder. Do not run it inside the ZIP viewer.
3. Install Python 3.11 or 3.12 from <https://www.python.org/downloads/> if it is not already installed. On Windows, select **Add Python to PATH**. Ensure the Python installation includes Tcl/Tk (standard Windows installer option).
4. Double-click `Start_MINI_AI_LITE_X.bat`.
5. For a no-download fallback, select **Offline rules only** in AI Model.
6. For actual local language-model chat, open **AI Model**, install the optional `llama-cpp-python` runtime, download the Qwen 0.5B quantized GGUF model, click **Load / reload model**, and keep **Offline local model** selected.

The portable ZIP is a Python application bundle, **not a standalone EXE**. The optional model is approximately 400–500 MB and is downloaded separately. First-time runtime installation/model download needs internet; after successful setup, local-model chat can work offline. A 4 GB RAM laptop may be slow, and a compatible Windows wheel may not be available for every Python/CPU combination.

## Features

- Chat with local model, offline rules, or optional OpenAI-compatible online API
- Teach & Library: save/search lessons and import text/code
- Notes and tasks stored locally
- Everyday calculator and writing helpers
- Procedural Picture Maker (not a trained image-generation model)
- Website Maker for starter HTML/CSS/JavaScript files
- Web Research: fetches text from a user-supplied public webpage URL; not a full search engine
- Offline Places: bundled city-coordinate lookup, not full offline maps
- Game Creator: creates standalone HTML games playable offline in a browser
- AI Model settings and local activity logging
- Optional separate remote tracker ZIP (see `tracker/`)

## Privacy defaults

- The default chat mode is **Offline local model**. If the model is not installed/loaded, the app tells you how to set it up rather than silently using the internet.
- **Offline rules only** uses local programmed responses and needs no model/API key.
- No API key, password, model weights, user database, or tracker token is included in the release.
- User data is stored under `%USERPROFILE%\MINI_AI_LITE_X_Data`.
- On Windows, newly saved online API keys are encrypted at rest using Windows DPAPI for the current Windows user. They must be decrypted in process memory to make a request; this is not protection against malware or a compromised account.
- The local SQLite database (chat, lessons, notes, tasks and activity) is not encrypted by this app. Do not store secrets in chat, notes or lessons.
- Web Research sends a request to the URL you enter. Online AI sends your prompt to the endpoint you configure. These features are optional; use local mode for offline/private chat.
- The app does not include analytics/telemetry code. No independent privacy audit has been performed.

## Optional OpenAI API

OpenAI API usage is **not required**. If a user explicitly selects Online API and configures their own key, charges may apply. API billing is separate from ChatGPT subscriptions. Keys are not included in this project. Never commit a key to GitHub.

## Optional tracker

The tracker is a separate package under `tracker/` and as `MINI_AI_LITE_X_Tracker_v1.0.0.zip`. By default it listens only on `127.0.0.1` (this computer). It displays app-recorded chat/activity and can issue an allow-listed set of controls. It cannot inspect unrelated programs or devices. Remote access requires deliberate configuration and a private VPN; do not expose the tracker to the public internet.

## Limitations

- This is a public preview; the GUI has not been tested on every Windows release or hardware setup.
- The app's basic rules mode is not a general-purpose LLM.
- The picture maker is procedural art, not neural image generation.
- Moderation and prompt instructions reduce risk but cannot guarantee every AI output is appropriate.
- Do not use this software as the sole basis for medical, legal, financial, safety-critical or emergency decisions.

## Licence and model terms

The application source is offered under the MIT License (see `LICENSE`). Third-party components and model weights have their own licences; see `THIRD_PARTY_NOTICES.md`. The model is not bundled. Before redistributing a model or changing its download source, check the exact upstream model card and licence.

## Contributing and reporting issues

See `CONTRIBUTING.md` and `SECURITY.md`. Do not post API keys, passwords, private chat logs or tracker tokens in issues.
