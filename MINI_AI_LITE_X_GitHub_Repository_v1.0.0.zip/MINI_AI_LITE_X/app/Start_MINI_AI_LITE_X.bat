@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 mini_ai_lite_x.py
) else (
  python mini_ai_lite_x.py
)
if errorlevel 1 (
  echo.
  echo MINI AI LITE X could not start. Install Python 3.11 or 3.12 from https://www.python.org/downloads/ and select Add Python to PATH.
  pause
)
endlocal
