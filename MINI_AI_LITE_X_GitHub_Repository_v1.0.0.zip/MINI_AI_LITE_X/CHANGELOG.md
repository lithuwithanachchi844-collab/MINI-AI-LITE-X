# Changelog

## 1.0.0 — 2026-10-24 — Public preview

- Prepared a GitHub-oriented source tree and portable ZIP release.
- Set initial chat mode to Offline local model to avoid unexpected online fallback.
- Kept online API as an optional, user-configured mode.
- Added privacy, security, licence, setup, troubleshooting and contribution notes.
- Made the separate tracker listen on localhost by default; network binding requires
  an explicit `--host` argument.
- Model weights and optional inference runtime are not bundled.
