MINI AI LITE X — OPTIONAL TRACKER (PUBLIC PREVIEW)

The tracker is separate from the app and uses Python standard library only.
Start MINI AI LITE X first, then run Start_Tracker_Server.bat. On this computer,
open http://127.0.0.1:8765 and enter the token at:
%USERPROFILE%\MINI_AI_LITE_X_Data\control_token.txt

For safety it binds to localhost by default. To deliberately bind to a specific
trusted private-network interface, run from Command Prompt:
  py -3 mini_ai_tracker_server.py --host <private-interface-IP>
Do not use 0.0.0.0 on an untrusted network and never port-forward the tracker.
Read TRACKER_MANUAL.txt before enabling remote access.
