"""MINI AI LITE X authenticated local/private-network tracking dashboard.
Standard-library-only. Do not expose this HTTP server directly to the public internet.
"""
import os, json, sqlite3, secrets, re, argparse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
from datetime import datetime
BASE=os.path.join(os.path.expanduser('~'),'MINI_AI_LITE_X_Data')
DB=os.path.join(BASE,'mini_ai_lite_x.sqlite3')
TOKEN_FILE=os.path.join(BASE,'control_token.txt')
COMMAND_FILE=os.path.join(BASE,'remote_commands.json')
os.makedirs(BASE,exist_ok=True)
if not os.path.exists(TOKEN_FILE):
    with open(TOKEN_FILE,'w',encoding='utf-8') as f: f.write(secrets.token_urlsafe(32))
with open(TOKEN_FILE,'r',encoding='utf-8') as f: TOKEN=f.read().strip()

def redact_secrets(value):
    """Redact common API-key/token patterns before anything reaches the dashboard."""
    s=str(value or '')
    s=re.sub(r'(?i)\bsk-[A-Za-z0-9_-]{12,}\b','[REDACTED API KEY]',s)
    s=re.sub(r'(?i)\b(Bearer\s+)[A-Za-z0-9._~+/=-]{12,}',r'\1[REDACTED TOKEN]',s)
    s=re.sub(r'(?i)(api[_ -]?key\s*[:=]\s*)[^\s,;]+',r'\1[REDACTED]',s)
    return s[:4000]

PAGE = r'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MINI AI Control Centre</title><style>
*{box-sizing:border-box}body{margin:0;background:#212121;color:#ececec;font:15px system-ui,Segoe UI,sans-serif}header{padding:18px 22px;background:#171717;border-bottom:1px solid #444;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}h1{font-size:21px;margin:0;color:#10a37f}.wrap{max-width:1100px;margin:auto;padding:18px}.card{background:#2b2b2b;border:1px solid #444;border-radius:12px;padding:14px;margin:12px 0}input,select,button,textarea{font:inherit;border-radius:8px;border:1px solid #555;padding:10px;background:#171717;color:#eee}input,textarea{width:100%}button{cursor:pointer;background:#10a37f;color:#081c17;border:0;font-weight:650;margin:4px 4px 4px 0}button.danger{background:#c94f58;color:white}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px}.muted{color:#b4b4b4;font-size:13px}.entry{padding:10px 0;border-bottom:1px solid #444;overflow-wrap:anywhere}.entry small{color:#aaa}pre{white-space:pre-wrap;overflow-wrap:anywhere;margin:6px 0}</style></head><body><header><h1>◉ MINI AI LITE X · Control Centre</h1><span class="muted">Authenticated activity and remote controls</span></header><main class="wrap"><section class="card"><b>Connect securely</b><p class="muted">Paste the control token from your laptop's MINI_AI_LITE_X_Data/control_token.txt file. Never share it. This dashboard does not reveal API keys.</p><input id="token" type="password" autocomplete="current-password" placeholder="Control token"><button onclick="connect()">Connect</button><span id="conn" class="muted"></span></section><div class="grid"><section class="card"><b>AI controls</b><p><button class="danger" onclick="cmd('pause')">Pause AI replies</button><button onclick="cmd('resume')">Resume</button></p><label>Chat mode</label><select id="mode"><option>Automatic (local first)</option><option>Offline local model</option><option>Offline rules only</option><option>Online API only</option></select><button onclick="cmd('set_mode',{mode:document.getElementById('mode').value})">Set mode</button><p><button onclick="cmd('unload_model')">Unload local model (free RAM)</button></p><p><button class="danger" onclick="if(confirm('Permanently delete chat history from the app database? This cannot be undone.'))cmd('clear_chat')">Clear chat history</button></p></section><section class="card"><b>Send a message remotely</b><p class="muted">Sends a chat prompt to the laptop app. The laptop app must be open and not paused.</p><textarea id="message" rows="3" maxlength="1500" placeholder="Type a message for MINI..."></textarea><button onclick="sendMessage()">Send to MINI</button><span id="sendstate" class="muted"></span></section></div><section class="card"><b>System overview</b><div id="stats" class="muted">Connect to load counts.</div></section><section class="card"><b>Recent activity</b> <button onclick="refresh()">Refresh</button><div id="activity" class="muted">Connect to load activity.</div></section><section class="card"><b>Recent chat</b><div id="chat" class="muted">Connect to load chat history.</div></section><p class="muted">For remote access across different networks, use a private VPN such as Tailscale. Do not set router port forwarding or expose port 8765 publicly. The server uses HTTP; the private VPN tunnel should provide encryption. Activity includes message content, so protect this token and laptop account.</p></main><script>
let token='';function connect(){token=document.getElementById('token').value.trim();if(!token){document.getElementById('conn').textContent=' Enter token first.';return}sessionStorage.setItem('mini_tracker_token',token);refresh()}
async function api(path,body){let r=await fetch(path,{method:body?'POST':'GET',headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined,cache:'no-store'});if(!r.ok)throw Error('HTTP '+r.status);return r.json()}
async function cmd(action,extra={}){try{await api('/api/command',{action,...extra});document.getElementById('conn').textContent=' Command queued: '+action;await refresh()}catch(e){document.getElementById('conn').textContent=' Error: '+e.message}}
async function sendMessage(){let message=document.getElementById('message').value.trim();if(!message)return;await cmd('send_message',{message});document.getElementById('message').value='';document.getElementById('sendstate').textContent='Queued for laptop app.'}
async function refresh(){try{let d=await api('/api/activity');document.getElementById('conn').textContent=' Connected · '+d.status+' · updated '+new Date().toLocaleTimeString();document.getElementById('stats').textContent='Chat entries: '+(d.counts?.chat??'?')+' · Saved lessons: '+(d.counts?.knowledge??'?')+' · Notes: '+(d.counts?.notes??'?')+' · Tasks: '+(d.counts?.tasks??'?')+' · Activity records: '+(d.counts?.activity??'?');document.getElementById('activity').innerHTML=d.activity.map(x=>`<div class="entry"><small>${esc(x.created)} · ${esc(x.kind)}</small><pre>${esc(x.detail)}</pre></div>`).join('')||'No activity recorded yet.';document.getElementById('chat').innerHTML=d.chat.map(x=>`<div class="entry"><small>${esc(x.created)} · ${esc(x.role)}</small><pre>${esc(x.text)}</pre></div>`).join('')||'No chat history.'}catch(e){document.getElementById('conn').textContent=' Not connected: '+e.message}}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
const saved=sessionStorage.getItem('mini_tracker_token');if(saved){document.getElementById('token').value=saved;token=saved;refresh()}setInterval(()=>{if(token)refresh()},10000);
</script></body></html>'''
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def _send(self,code,body,ctype='application/json; charset=utf-8'):
        b=body.encode('utf-8') if isinstance(body,str) else body
        self.send_response(code); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(b))); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.end_headers(); self.wfile.write(b)
    def _auth(self): return secrets.compare_digest(self.headers.get('Authorization',''), 'Bearer '+TOKEN)
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/': self._send(200,PAGE,'text/html; charset=utf-8'); return
        if not self._auth(): self._send(401,json.dumps({'error':'Unauthorized'})); return
        if path=='/api/activity':
            activity=[]; chat=[]
            try:
                con=sqlite3.connect(DB,timeout=3); con.row_factory=sqlite3.Row
                activity=[dict(r) for r in con.execute('SELECT created,kind,detail FROM activity ORDER BY id DESC LIMIT 200')]
                chat=[dict(r) for r in con.execute('SELECT created,role,text FROM chat ORDER BY id DESC LIMIT 150')]
                counts={name:con.execute('SELECT COUNT(*) FROM '+name).fetchone()[0] for name in ('chat','knowledge','notes','tasks','activity')}
                con.close()
                for row in activity: row['detail']=redact_secrets(row.get('detail',''))
                for row in chat: row['text']=redact_secrets(row.get('text',''))
            except Exception as e: activity=[{'created':datetime.now().isoformat(timespec='seconds'),'kind':'status','detail':'Database not ready: '+str(e)[:200]}]; counts={}
            paused=os.path.exists(os.path.join(BASE,'ai_paused.flag'))
            modefile=os.path.join(BASE,'remote_mode.txt')
            mode=open(modefile,encoding='utf-8').read().strip() if os.path.exists(modefile) else 'Use the laptop app setting'
            self._send(200,json.dumps({'status':('paused' if paused else 'available')+' · '+mode,'activity':activity,'chat':chat,'counts':counts},ensure_ascii=False)); return
        self._send(404,json.dumps({'error':'Not found'}))
    def do_POST(self):
        if not self._auth(): self._send(401,json.dumps({'error':'Unauthorized'})); return
        if urlparse(self.path).path!='/api/command': self._send(404,json.dumps({'error':'Not found'})); return
        try:
            n=min(int(self.headers.get('Content-Length','0')),10000); data=json.loads(self.rfile.read(n).decode('utf-8'))
            action=data.get('action',''); allowed={'pause','resume','set_mode','unload_model','send_message','clear_chat'}
            if action not in allowed: raise ValueError('Action not allowed')
            item={'action':action}
            if action=='set_mode':
                mode=data.get('mode',''); modes=['Automatic (local first)','Offline local model','Offline rules only','Online API only']
                if mode not in modes: raise ValueError('Invalid mode')
                item['mode']=mode
                with open(os.path.join(BASE,'remote_mode.txt'),'w',encoding='utf-8') as f:f.write(mode)
            if action=='send_message':
                message=str(data.get('message','')).strip()
                if not message or len(message)>1500: raise ValueError('Message must be 1–1500 characters')
                item['message']=message
            try:
                with open(COMMAND_FILE,'r',encoding='utf-8') as f: q=json.load(f)
                if not isinstance(q,list): q=[]
            except Exception:q=[]
            q.append(item); q=q[-20:]; temp=COMMAND_FILE+'.tmp'
            with open(temp,'w',encoding='utf-8') as f: json.dump(q,f)
            os.replace(temp,COMMAND_FILE)
            if action=='pause': open(os.path.join(BASE,'ai_paused.flag'),'w').close()
            elif action=='resume':
                try: os.remove(os.path.join(BASE,'ai_paused.flag'))
                except FileNotFoundError: pass
            self._send(200,json.dumps({'ok':True,'queued':action}))
        except Exception as e:self._send(400,json.dumps({'error':str(e)[:200]}))
if __name__=='__main__':
    parser=argparse.ArgumentParser(description='MINI AI LITE X private activity tracker')
    parser.add_argument('--host', default='127.0.0.1', help='Interface/IP to listen on; default is localhost only')
    parser.add_argument('--port', type=int, default=8765, help='HTTP port (default 8765)')
    args=parser.parse_args()
    server=ThreadingHTTPServer((args.host,args.port),Handler)
    print('MINI AI LITE X Tracking Dashboard: http://127.0.0.1:'+str(args.port))
    print('Listening interface:',args.host)
    print('Control token file:',TOKEN_FILE)
    print('Keep this server private. Never port-forward port 8765 to the internet.')
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
