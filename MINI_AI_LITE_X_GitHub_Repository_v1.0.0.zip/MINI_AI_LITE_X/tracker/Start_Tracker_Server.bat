@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 mini_ai_tracker_server.py
) else (
  python mini_ai_tracker_server.py
)
if errorlevel 1 (
  echo.
  echo Tracker could not start. Install Python 3.11 or 3.12 from https://www.python.org/downloads/.
  pause
)
endlocal
