"""Small offline regression tests for MINI AI LITE X core storage."""
import importlib.util
import pathlib
import sqlite3
import tempfile
import unittest

SOURCE = pathlib.Path(__file__).resolve().parents[1] / "app" / "mini_ai_lite_x.py"
SPEC = importlib.util.spec_from_file_location("mini_ai_lite_x_tested", SOURCE)
APP = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(APP)

class CoreStorageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = pathlib.Path(self.temp.name)
        APP.APP_DIR = root
        APP.DB_PATH = root / "knowledge.sqlite3"
        APP.SETTINGS_PATH = root / "settings.json"
        APP.db_init()
        self.original_fetch = APP.fetch_page
        APP.fetch_page = lambda url, timeout: (
            url, "Test page",
            ("Science weather computer learning text. " if url.endswith("/one") else
             "Engineering chemistry astronomy learning text. ") * 30
        )
        self.settings = {**APP.DEFAULTS, "storage_limit_gb": 1,
                         "max_chars_per_page": 12000, "request_timeout_seconds": 5}

    def tearDown(self):
        APP.fetch_page = self.original_fetch
        self.temp.cleanup()

    def test_save_and_retrieve_page_text(self):
        result = APP.save_page("https://example.org/one", "science", self.settings)
        self.assertEqual(result["status"], "saved")
        hits = APP.retrieve("science weather", 3)
        self.assertTrue(hits)
        self.assertIn("Science weather", hits[0][4])

    def test_duplicate_url_is_skipped(self):
        APP.save_page("https://example.org/one", "science", self.settings)
        result = APP.save_page("https://example.org/one", "science", self.settings)
        self.assertEqual(result["status"], "duplicate")
        with sqlite3.connect(APP.DB_PATH) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM pages").fetchone()[0], 1)

    def test_duplicate_content_is_skipped_across_urls(self):
        APP.save_page("https://example.org/one", "science", self.settings)
        result = APP.save_page("https://mirror.example.org/one", "science", self.settings)
        self.assertEqual(result["status"], "duplicate")

    def test_storage_cap_refuses_new_page(self):
        old_usage = APP.app_storage_bytes
        APP.app_storage_bytes = lambda: 2 * (1024 ** 3)
        try:
            result = APP.save_page("https://example.org/one", "science", self.settings)
            self.assertEqual(result["status"], "cap")
        finally:
            APP.app_storage_bytes = old_usage

if __name__ == "__main__":
    unittest.main(verbosity=2)
