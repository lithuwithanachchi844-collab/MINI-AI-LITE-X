MINI AI LITE X v1.0.3 — AUTOLEARN FIXED PORTABLE

START THE APP
1. Extract this ZIP to a normal writable folder. Do not run from inside the ZIP viewer.
2. Install Python 3.10+ from https://www.python.org/downloads/windows/ and ensure Tcl/Tk is included.
3. Double-click Start_MINI_AI_LITE_X.bat.

AUTOMATIC INTERNET LEARNING
- AutoLearn is enabled by default and can run when the app starts, then on the configured schedule (6 hours by default).
- AutoLearn runs independently of Talk mode. Use the AutoLearn ON/OFF sidebar button to pause/resume.
- Settings control the startup topic, schedule, maximum pages per run, page text size, timeout, and storage cap.
- It reads accessible public webpage text and saves it to a local SQLite knowledge library. Duplicate URLs and identical text are skipped.
- Saved knowledge remains available offline. AutoLearn expands searchable memory; it does not retrain a language model's weights.
- Research requires internet access. If a site blocks automated access or requires login/JavaScript, it may not be readable.

OPTIONAL LOCAL AI MODEL
Double-click Setup_Local_AI.bat to attempt to install a compatible local runtime and small model. This needs internet access and can fail on older CPUs or restricted networks. On a 4 GB RAM laptop, responses may be slow. The app still starts without the model, but general chat is limited.

DATA AND PRIVACY
Settings, chat history, saved pages, and lessons are stored under %LOCALAPPDATA%\MiniAILiteX. AutoLearn saves downloaded page text locally. Online AI providers are not used by AutoLearn.

TEST STATUS
Python syntax compilation, four offline storage regression tests, Tkinter GUI smoke test, and ZIP integrity checks passed in the build environment. Live web search and local-model generation were not tested because internet/model runtime were unavailable. The app was not tested on the user's physical Windows laptop. See TESTING_REPORT.txt.
