@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py mini_ai_lite_x.py --setup-ai
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    python mini_ai_lite_x.py --setup-ai
  ) else (
    echo Python was not found. Install Python from https://www.python.org/downloads/windows/
    pause
  )
)
if not "%errorlevel%"=="0" pause
endlocal
