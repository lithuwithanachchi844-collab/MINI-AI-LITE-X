"""MINI AI LITE X - lightweight Windows chatbot and web-learning assistant.
Uses Python standard library only. Reads accessible public webpages, saves their
text locally, retrieves it for later answers, and works offline with saved data.
A local GGUF model can optionally provide more fluent generated answers.
"""
from __future__ import annotations
import os, re, json, time, sqlite3, threading, queue, urllib.request, urllib.parse, urllib.error, html, hashlib, webbrowser, subprocess, random, base64, tempfile, uuid, zipfile, shutil, xml.etree.ElementTree as ET
from pathlib import Path
from html.parser import HTMLParser
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog

APP_NAME = "MINI AI LITE X"
APP_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "MiniAILiteX"
DB_PATH = APP_DIR / "knowledge.sqlite3"
SETTINGS_PATH = APP_DIR / "settings.json"
DEFAULTS = {"storage_limit_gb":200,"chat_storage_limit_gb":50,"max_pages_per_run":4,"max_chars_per_page":12000,
 "research_on_startup":True,"startup_topic":"basic science and technology","research_interval_hours":6,
 "auto_learning_enabled":True,"last_auto_research":0,"auto_topic_index":0,"llama_cli_path":"","model_path":"",
 "request_timeout_seconds":18,"open_manual_urls":True,"open_research_pages":False,"talk_only_mode":True}
TOPICS = ["NASA space science discoveries","basic physics explanations","computer science fundamentals","renewable energy research","human biology education","world history","climate science","mathematics concepts","engineering inventions","wildlife conservation","geography and Earth science","technology security and privacy"]
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36 MINI-AI-LITE-X personal research assistant"

def load_settings():
    APP_DIR.mkdir(parents=True, exist_ok=True)
    migrated=False
    try:
        stored=json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        s={**DEFAULTS, **stored}
        # The previous published default was 100 GB; this project now requests 200 GB.
        if stored.get("storage_limit_gb") == 100:
            s["storage_limit_gb"]=200
            migrated=True
        if "chat_storage_limit_gb" not in stored:
            s["chat_storage_limit_gb"]=50
            migrated=True
    except Exception:
        s=dict(DEFAULTS)
    for k,lo,hi in [("storage_limit_gb",1,200),("chat_storage_limit_gb",1,50),("max_pages_per_run",1,8),("max_chars_per_page",1000,30000),("request_timeout_seconds",5,60),("research_interval_hours",1,168)]:
        try:s[k]=max(lo,min(hi,int(s[k])))
        except Exception:s[k]=DEFAULTS[k]
    if migrated:
        try: save_settings(s)
        except Exception: pass
    return s

def save_settings(s):
    APP_DIR.mkdir(parents=True,exist_ok=True); tmp=SETTINGS_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(s,indent=2),encoding="utf-8"); tmp.replace(SETTINGS_PATH)

class PageParser(HTMLParser):
    SKIP={"script","style","noscript","svg","nav","footer","header","form","iframe","canvas"}
    def __init__(self):super().__init__();self.parts=[];self.title_parts=[];self.skip=[];self.in_title=False
    def handle_starttag(self,tag,attrs):
        if tag in self.SKIP:self.skip.append(tag)
        if tag=="title":self.in_title=True
        if tag in {"p","div","br","li","h1","h2","h3","section","article"} and not self.skip:self.parts.append(" ")
    def handle_endtag(self,tag):
        if tag in self.SKIP:
            for i in range(len(self.skip)-1,-1,-1):
                if self.skip[i]==tag:del self.skip[i];break
        if tag=="title":self.in_title=False
        if tag in {"p","div","br","li","h1","h2","h3","section","article"} and not self.skip:self.parts.append(" ")
    def handle_data(self,data):
        v=re.sub(r"\s+"," ",data).strip()
        if not v:return
        if self.in_title:self.title_parts.append(v)
        if not self.skip:self.parts.append(v)

class SearchParser(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):
        if tag=="a":
            a=dict(attrs);h=a.get("href","")
            if "result__a" in a.get("class","").split() and h:self.links.append(h)

def fetch_page(url,timeout=18):
    p=urllib.parse.urlparse(url)
    if p.scheme not in ("http","https") or not p.netloc:raise ValueError("Enter a complete public http:// or https:// URL.")
    req=urllib.request.Request(url,headers={"User-Agent":UA,"Accept":"text/html,text/plain,application/xhtml+xml"})
    with urllib.request.urlopen(req,timeout=timeout) as r:
        ctype=r.headers.get("Content-Type","").lower(); raw=r.read(2_000_000); final=r.geturl()
    if not any(x in ctype for x in ("html","text/plain","xml")) and b"<html" not in raw[:1500].lower():
        raise ValueError("This link did not return readable HTML/text. It may be a PDF, login page, or unsupported file.")
    if "html" in ctype or b"<html" in raw[:1500].lower():
        parser=PageParser();parser.feed(raw.decode("utf-8","replace"));body=" ".join(parser.parts);title=" ".join(parser.title_parts).strip()
    else:body=raw.decode("utf-8","replace");title=""
    body=html.unescape(re.sub(r"\s+"," ",body)).strip()
    if not title:title=(body[:160].split(". ")[0] if body else urllib.parse.urlparse(final).netloc)
    if len(body)<100:raise ValueError("The page returned too little readable text. It may need JavaScript or block automated access.")
    return final,title[:250],body

def search_web(query,limit=4,timeout=18):
    errors=[];results=[]
    try:
        endpoint="https://html.duckduckgo.com/html/?q="+urllib.parse.quote(query)
        req=urllib.request.Request(endpoint,headers={"User-Agent":UA,"Accept":"text/html"})
        with urllib.request.urlopen(req,timeout=timeout) as r:raw=r.read(1_200_000).decode("utf-8","replace")
        parser=SearchParser();parser.feed(raw)
        for href in parser.links:
            p=urllib.parse.urlparse(html.unescape(href));dest=urllib.parse.parse_qs(p.query).get("uddg",[""])[0] if "duckduckgo.com" in p.netloc else href
            if dest.startswith(("https://","http://")) and "duckduckgo.com" not in urllib.parse.urlparse(dest).netloc and dest not in results:results.append(dest)
            if len(results)>=limit:break
    except Exception as e:errors.append("DuckDuckGo search: "+str(e))
    if results:return results,errors
    try:
        api="https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&srsearch="+urllib.parse.quote(query)+"&srlimit="+str(limit)
        req=urllib.request.Request(api,headers={"User-Agent":UA,"Accept":"application/json"})
        with urllib.request.urlopen(req,timeout=timeout) as r:data=json.loads(r.read(500000).decode("utf-8","replace"))
        for item in data.get("query",{}).get("search",[]):
            title=item.get("title","")
            if title:results.append("https://en.wikipedia.org/wiki/"+urllib.parse.quote(title.replace(" ","_")))
    except Exception as e:errors.append("Wikipedia search: "+str(e))
    if not results:raise RuntimeError("No search results were returned. "+" | ".join(errors)+". You can still use Learn URL with a known public link.")
    return results,errors

def db_init():
    APP_DIR.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(DB_PATH) as c:
        c.execute("CREATE TABLE IF NOT EXISTS pages(id INTEGER PRIMARY KEY,url TEXT NOT NULL UNIQUE,title TEXT NOT NULL,body TEXT NOT NULL,saved_at INTEGER NOT NULL,content_hash TEXT NOT NULL UNIQUE,query TEXT NOT NULL DEFAULT '')")
        c.execute("CREATE INDEX IF NOT EXISTS pages_saved_at ON pages(saved_at)")
        c.execute("CREATE TABLE IF NOT EXISTS chat(id INTEGER PRIMARY KEY,role TEXT NOT NULL,body TEXT NOT NULL,saved_at INTEGER NOT NULL)")
        cols={r[1] for r in c.execute("PRAGMA table_info(chat)").fetchall()}
        if "session_id" not in cols: c.execute("ALTER TABLE chat ADD COLUMN session_id TEXT")
        c.execute("CREATE TABLE IF NOT EXISTS chat_sessions(id TEXT PRIMARY KEY,title TEXT NOT NULL,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)")
        # Preserve older chat history in a single saved conversation.
        if c.execute("SELECT COUNT(*) FROM chat WHERE session_id IS NULL").fetchone()[0]:
            legacy="legacy-chat"
            now=int(time.time())
            c.execute("INSERT OR IGNORE INTO chat_sessions(id,title,created_at,updated_at) VALUES(?,?,?,?)",(legacy,"Earlier chat history",now,now))
            c.execute("UPDATE chat SET session_id=? WHERE session_id IS NULL",(legacy,))
        c.execute("CREATE INDEX IF NOT EXISTS chat_session_idx ON chat(session_id,id)")
        c.execute("CREATE TABLE IF NOT EXISTS lessons(id INTEGER PRIMARY KEY,title TEXT NOT NULL,content TEXT NOT NULL,kind TEXT NOT NULL DEFAULT 'fact',created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)")
        c.execute("CREATE INDEX IF NOT EXISTS lessons_updated_at ON lessons(updated_at)")

def storage_bytes():
    total=0
    for p in APP_DIR.glob("knowledge.sqlite3*"):
        try:total+=p.stat().st_size
        except OSError:pass
    return total

def app_storage_bytes():
    total=0
    for root, dirs, files in os.walk(APP_DIR):
        dirs[:] = [d for d in dirs if d not in {"__pycache__"}]
        for name in files:
            try: total += (Path(root) / name).stat().st_size
            except OSError: pass
    return total

def chat_storage_bytes():
    try:
        with sqlite3.connect(DB_PATH) as c:
            row=c.execute("SELECT COALESCE(SUM(LENGTH(CAST(body AS BLOB))),0) FROM chat").fetchone()
            return int(row[0] or 0)
    except Exception:
        return 0

def save_page(url,query,settings):
    final,title,body=fetch_page(url,settings["request_timeout_seconds"]);body=body[:settings["max_chars_per_page"]]
    digest=hashlib.sha256(body.casefold().encode("utf-8","replace")).hexdigest()
    with sqlite3.connect(DB_PATH) as c:
        if c.execute("SELECT 1 FROM pages WHERE url=? OR content_hash=?",(final,digest)).fetchone():return {"status":"duplicate","title":title,"url":final,"chars":len(body),"message":"Already saved; duplicate skipped: "+title}
        incoming=len((final+title+body+query).encode("utf-8"))+16384;cap=settings["storage_limit_gb"]*(1024**3)
        if app_storage_bytes()+incoming>cap:return {"status":"cap","title":title,"url":final,"chars":len(body),"message":"Storage cap reached; skipped: "+final}
        c.execute("INSERT INTO pages(url,title,body,saved_at,content_hash,query) VALUES(?,?,?,?,?,?)",(final,title,body,int(time.time()),digest,query[:500]))
    return {"status":"saved","title":title,"url":final,"chars":len(body),"message":f"LEARNED AND SAVED: {title} ({len(body):,} characters)\nSource: {final}"}

def words(s):return set(re.findall(r"[a-z0-9]{2,}",s.casefold()))
def retrieve(query,limit=5):
    q=words(query)
    if not q:return []
    with sqlite3.connect(DB_PATH) as c:rows=c.execute("SELECT id,url,title,body,saved_at FROM pages ORDER BY saved_at DESC LIMIT 12000").fetchall()
    hits=[]
    for row in rows:
        pid,url,title,body,stamp=row;doc=words((title+" ")*3+body);score=len(q&doc)/max(1,len(q))
        if score>=0.06:hits.append((score,pid,url,title,body,stamp))
    hits.sort(key=lambda x:(x[0],x[5]),reverse=True);return hits[:limit]

def local_model(prompt,settings):
    # The built_in_ai module owns local llama.cpp inference. Keep a fallback
    # for older extracted copies where that module is not present.
    try:
        import built_in_ai
        return built_in_ai.generate(prompt,settings,max_tokens=240,timeout=180)
    except Exception:
        cli=settings.get("llama_cli_path","").strip();model=settings.get("model_path","").strip()
        if not cli or not model or not Path(cli).is_file() or not Path(model).is_file():return None
        try:
            p=subprocess.run([cli,"-m",model,"-p",prompt,"-n","240","-c","2048"],capture_output=True,text=True,timeout=180,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            if p.returncode==0 and p.stdout.strip():return p.stdout.strip().split(prompt,1)[-1].strip()[-7000:]
        except Exception:pass
        return None

def retrieve_lessons(query,limit=8):
    q=words(query)
    if not q:return []
    with sqlite3.connect(DB_PATH) as c:
        rows=c.execute("SELECT id,title,content,kind,updated_at FROM lessons ORDER BY updated_at DESC LIMIT 5000").fetchall()
    ranked=[]
    for row in rows:
        lid,title,content,kind,stamp=row
        score=len(q & words((title+" ")*3+content))/max(1,len(q))
        if score >= 0.12 or kind == "correction" and score >= 0.08:
            ranked.append((score,lid,title,content,kind,stamp))
    ranked.sort(key=lambda x:(x[4]=="correction",x[0],x[5]),reverse=True)
    return ranked[:limit]

def chatbot_fallback(q,hits,lessons=None):
    lessons=lessons or []
    if lessons:
        corrections=[x for x in lessons if x[4]=="correction"]
        facts=[x for x in lessons if x[4]!="correction"]
        if corrections or facts:
            out=["I checked what you've taught me:"]
            for _,_,title,content,kind,_ in (corrections+facts)[:4]:
                out.append(("Correction" if kind=="correction" else "Lesson")+" — "+title+"\n"+content)
            if hits:
                out.append("\nRelated saved webpage sources are also available below.")
            else:
                out.append("\nThese are your saved lessons, not newly verified facts. You can edit or delete them in My Lessons.")
                return "\n\n".join(out)
            learned_prefix="\n\n".join(out)
        else: learned_prefix=""
    else: learned_prefix=""

    t=q.casefold().strip();short=t.rstrip(".!? ")
    if re.search(r"\b(hi|hello|hey|g'day)\b",t):return "Hello! I'm MINI AI LITE X. You can chat with me, ask about pages I've learned, or give me a webpage link to read and save. What would you like to explore?"
    if re.search(r"\b(who are you|what are you|your name)\b",t):return "I'm MINI AI LITE X, a lightweight chatbot and research assistant. I can read accessible public webpages, save their text on this computer, and use that saved knowledge when answering later—even offline. Without a configured language model, my conversation and reasoning are limited."
    if re.search(r"\b(thank you|thanks)\b",t):return "You're welcome! If you want me to expand my saved knowledge, use Research topic or Learn URL. I'll report whether the text was actually saved."
    if re.search(r"\b(what have you learned|how many pages|what do you know)\b",t):
        with sqlite3.connect(DB_PATH) as c:rows=c.execute("SELECT title,url,length(body) FROM pages ORDER BY saved_at DESC LIMIT 8").fetchall();count=c.execute("SELECT COUNT(*) FROM pages").fetchone()[0]
        if not rows:return "I haven't saved any webpages yet. Use Learn URL or Research topic while connected to the internet."
        return "I have saved "+str(count)+" webpage(s). Recent knowledge:\n"+"\n".join(f"• {title} — {chars:,} characters\n  {url}" for title,url,chars in rows)
    if re.search(r"\b(help|how do i use you|what can you do)\b",t):return "Here's how to use me:\n• Chat: type a question or message below.\n• Research topic: search public web pages, read their text, and save it.\n• Learn URL: enter a direct link; I'll open it in your browser (if enabled), read its accessible text, and save it locally.\n• Saved knowledge: inspect, open, or delete pages.\n• Offline: ask about topics already in my saved pages.\n\nI don't retrain a neural network from each page; I expand my local searchable knowledge store. A compatible local model can improve conversational responses."
    if not hits:return (learned_prefix+"\n\n" if learned_prefix else "")+"I don't have a saved webpage source that answers that yet. You can teach me using Teach AI, or use Research topic / Learn URL to save public information."
    out=([learned_prefix,"\nI found information in my saved webpage knowledge:"] if learned_prefix else ["I found information in my saved knowledge:"])
    qw=words(q)
    for _,_,url,title,body,_ in hits[:3]:
        sentences=re.split(r"(?<=[.!?])\s+",body);ranked=sorted(((len(qw&words(s)),s.strip()) for s in sentences if len(s.strip())>35),reverse=True)
        chosen=[s for score,s in ranked[:4] if score]
        out.append("\n"+title+"\n"+(" ".join(chosen) if chosen else body[:900])+"\nSource: "+url)
    out.append("\nI used saved webpage text, not a newly trained model. Check the sources for important decisions.")
    return "\n".join(out)

def expression_for(text):
    """Choose a conversational expression from the message; this is simulated style, not a real feeling."""
    t=(text or "").casefold()
    if re.search(r"\b(sad|lonely|upset|depressed|scared|worried|anxious|bad day|cry|hurt)\b",t):
        return ("🤗", "Supportive", "Use a gentle, validating, non-judgmental tone. Acknowledge the user's feelings without pretending to feel them yourself.")
    if re.search(r"\b(why|how does|how do|what if|wonder|curious|explain|learn|teach me)\b",t):
        return ("🤔", "Curious", "Sound curious and engaged. Ask a useful follow-up question when it would help.")
    if re.search(r"\b(thank|thanks|awesome|great|yay|happy|excited|love it|good news)\b",t):
        return ("😄", "Cheerful", "Be upbeat and warm, using a little friendly enthusiasm without overdoing it.")
    if re.search(r"\b(error|bug|broken|wrong|doesn't work|does not work|fix|problem|help)\b",t):
        return ("🧐", "Focused", "Be patient, practical, and thoughtful. Work through the issue clearly without blaming the user.")
    if re.search(r"\b(hello|hi|hey|g'day|good morning)\b",t):
        return ("😊", "Friendly", "Sound friendly and welcoming.")
    return ("😌", "Calm", "Use a calm, natural, considerate conversational tone. Avoid excessive emojis.")

def offline_answer(question, lessons=None):
    """Small honest offline fallback for when the optional neural model is unavailable."""
    q=(question or "").strip()
    t=q.casefold()
    # Basic arithmetic, deliberately restricted to safe numeric expressions.
    m=re.fullmatch(r"\s*(?:what is\s+)?([0-9\s()+\-*/%.]+)\s*\??\s*",t)
    if m and any(ch.isdigit() for ch in m.group(1)):
        expr=m.group(1).strip()
        if len(expr)<=80 and re.fullmatch(r"[0-9\s()+\-*/%.]+",expr):
            try:
                import ast, operator
                ops={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv,ast.FloorDiv:operator.floordiv,ast.Mod:operator.mod,ast.Pow:operator.pow,ast.USub:operator.neg,ast.UAdd:operator.pos}
                def calc(node,depth=0):
                    if depth>20: raise ValueError()
                    if isinstance(node,ast.Expression): return calc(node.body,depth+1)
                    if isinstance(node,ast.Constant) and isinstance(node.value,(int,float)): return node.value
                    if isinstance(node,ast.UnaryOp) and type(node.op) in ops: return ops[type(node.op)](calc(node.operand,depth+1))
                    if isinstance(node,ast.BinOp) and type(node.op) in ops:
                        a,b=calc(node.left,depth+1),calc(node.right,depth+1)
                        if isinstance(node.op,ast.Pow) and abs(b)>8: raise ValueError()
                        result=ops[type(node.op)](a,b)
                        if abs(result)>1e100: raise ValueError()
                        return result
                    raise ValueError()
                value=calc(ast.parse(expr,mode='eval'))
                return f"{expr} = {value:g}" if isinstance(value,float) else f"{expr} = {value}"
            except Exception: pass
    if re.search(r"\b(hi|hello|hey|g'day|good morning|good afternoon|good evening)\b",t):
        return "Hi! 😊 I'm here and ready to help. What would you like to talk about or work on?"
    if re.search(r"\b(thank you|thanks|cheers)\b",t): return "You're welcome! 😊 What would you like to do next?"
    if re.search(r"\b(are you (alive|real|sentient|conscious)|do you have feelings)\b",t):
        return "I'm an AI application, not a living person, so I don't have real feelings or consciousness. I can still chat in a friendly way and help with tasks."
    if re.search(r"\b(who are you|what are you|your name)\b",t):
        return "I'm MINI AI LITE X. I can keep local chats, use lessons you teach me, and work with saved research. The language-model engine is optional; if it isn't installed, I use a limited built-in offline helper instead of pretending a full model is running."
    if re.search(r"\b(what can you do|help|how do i use you)\b",t):
        return "I can chat, save conversations locally, remember lessons you teach me, and (in Research mode) save information from accessible webpages. I can also do basic arithmetic offline. For open-ended explanations and stronger reasoning, install a compatible local language model from Settings / first-run setup."
    if re.search(r"\b(bye|goodbye|see you|good night)\b",t): return "See you later! 😊 Your saved conversations remain on this computer."
    # A tiny curated starter knowledge base is useful offline without misrepresenting its limits.
    knowledge=[
      (r"\b(photosynthesis|plants make food)\b", "Photosynthesis is how plants, algae, and some bacteria use light energy to turn carbon dioxide and water into energy-rich sugars. In plants it happens mainly in chloroplasts, and oxygen is released as a by-product."),
      (r"\b(gravity)\b", "Gravity is the attraction associated with mass and energy. Near Earth's surface it gives unsupported objects an acceleration of about 9.8 m/s². In Einstein's general relativity, gravity is described as curvature of spacetime."),
      (r"\b(black hole|black holes)\b", "A black hole is a region where gravity is so strong that, inside its event horizon, nothing can escape to the outside—not even light. Black holes can form when very massive stars collapse, and astronomers also observe supermassive black holes in many galaxies."),
      (r"\b(artificial intelligence|\bai\b|machine learning)\b", "Artificial intelligence (AI) is a broad field of methods that let computers perform tasks such as recognizing patterns, understanding language, planning, or generating content. Machine learning is a subset of AI in which systems learn statistical patterns from examples. A language model generates text from patterns learned during training; it does not automatically become more capable just because chat history is stored."),
      (r"\b(climate change|global warming)\b", "Today's global warming is primarily caused by human emissions of greenhouse gases, especially carbon dioxide from burning fossil fuels. These gases trap additional heat, raising average temperatures and changing rainfall, sea levels, and the frequency or intensity of some extreme events."),
      (r"\b(electricity|electric current)\b", "Electric current is the rate at which electric charge flows. In a simple circuit, a voltage difference drives current through a conducting path. For many components, Ohm's law relates voltage, current, and resistance: V = I × R."),
      (r"\b(arduino)\b", "Arduino is an electronics prototyping platform built around microcontrollers and a programming environment. A sketch typically has setup(), which runs once, and loop(), which repeats. Check the board's pin voltage and current limits before connecting components."),
      (r"\b(python programming|python language|what is python)\b", "Python is a general-purpose programming language known for readable syntax. It is commonly used for automation, data analysis, web services, and AI. For example, print('Hello') displays text; variables store values, and functions group reusable operations."),
      (r"\b(sleep)\b", "Sleep supports memory, attention, mood, and physical health. Many adults do best with roughly 7–9 hours each night, although individual needs vary. A consistent schedule and a dark, quiet room can help. If sleep problems persist or seriously affect daily life, consider speaking with a health professional."),
    ]
    for pat,answer in knowledge:
        if re.search(pat,t): return answer+"\n\nNote: the built-in helper is limited and this answer was not generated by a language model."
    # Use user-taught lessons if available, without fabricating general knowledge.
    if lessons:
        relevant=[]
        qw=set(re.findall(r"[a-z0-9]{3,}",t))
        for item in lessons:
            try:
                title,body=item[2],item[3]
                score=len(qw & set(re.findall(r"[a-z0-9]{3,}",(str(title)+' '+str(body)).casefold())))
                if score: relevant.append((score,str(title),str(body)))
            except Exception: pass
        if relevant:
            relevant.sort(reverse=True)
            return "From the lessons you've taught me (not independently verified):\n\n"+"\n\n".join(f"{title}: {body}" for _,title,body in relevant[:2])
    return ("I can keep chatting, but the local language model is not available yet, so I can't reliably compose a full answer to that question offline. "
            "Try a basic calculation or one of the built-in topics, teach me a relevant lesson, or install a compatible local model. "
            "I won't pretend that this limited helper is the full AI engine.")

def answer_question(question,settings,talk_only=False):
    hits=[] if talk_only else retrieve(question,5);lessons=retrieve_lessons(question,8);evidence="\n\n".join(f"[{t}] {b[:1800]}\nSource: {u}" for _,_,u,t,b,_ in hits)
    lesson_evidence="\n\n".join(("[USER CORRECTION] " if k=="correction" else "[USER-TAUGHT LESSON] ")+t+": "+b for _,_,t,b,k,_ in lessons)
    emoji,mood,mood_instruction=expression_for(question)
    if talk_only:
        prompt=("You are MINI AI LITE X in TALK mode: a friendly conversational chatbot, not a web researcher or information-gathering agent. Do not search for, fetch, or suggest gathering webpages. Focus on natural conversation, responding to what the user says, asking thoughtful follow-up questions, and being warm and honest. You may use the user's saved lessons for personal context, but do not cite web sources or present yourself as having real feelings. Current simulated style: "+mood+". "+mood_instruction+" Use occasional emoji naturally.\nUser-taught lessons and corrections:\n"+(lesson_evidence or "None")+"\nUser: "+question)
    else:
        prompt=("You are MINI AI LITE X, a warm, helpful and honest chatbot. Treat user corrections as high-priority guidance, but do not present unverified user claims as independently verified. Use saved evidence where relevant and cite URLs. If evidence is insufficient, say so. Do not claim consciousness or real feelings. Express a simulated conversational style called "+mood+". "+mood_instruction+" Use occasional natural emoji only when appropriate.\nUser: "+question+"\nUser-taught lessons and corrections:\n"+(lesson_evidence or "None")+"\nSaved webpage evidence:\n"+(evidence or "No relevant saved pages."))
    generated=local_model(prompt,settings)
    if generated:return generated
    if talk_only and not lessons:
        # Honest no-model fallback: give varied, intent-aware responses instead of
        # repeating one generic line. A real language model is still needed for
        # open-ended reasoning; this fallback never pretends otherwise.
        t=question.casefold().strip()
        if re.search(r"\b(hi|hello|hey|g'day|good morning|good evening)\b",t):
            return "Hey! 😊 I'm here. What's on your mind today? We can talk casually, work through a problem, or plan something together."
        if re.search(r"\b(thank you|thanks|cheers)\b",t):
            return "You're welcome! 😊 I'm glad to help. What would you like to do next?"
        if re.search(r"\b(who are you|what are you|your name)\b",t):
            return "I'm MINI AI LITE X. The local language model hasn't loaded, so I'm running in limited fallback mode right now. I can still handle some common prompts, save chats and use lessons, but I won't pretend this is full language-model intelligence."
        if re.search(r"\b(are you (alive|real|sentient|conscious)|do you have feelings)\b",t):
            return "I'm software, not a living person, and I don't have real feelings or consciousness. I can still respond in a friendly, supportive way."
        if re.search(r"\b(sad|lonely|upset|worried|anxious|bad day|hurt|scared|stressed)\b",t):
            return "I'm sorry things feel difficult right now. 🤗 If you want, tell me what happened and we can take it one step at a time. You don't have to explain it perfectly."
        if re.search(r"\b(help|what can you do|how do i use you)\b",t):
            return "I can save and reopen chats, use lessons you teach me, and research public webpages when Research mode is enabled. In this fallback mode my general answers are limited because the local language model failed to install. Once a compatible model is installed, open Settings and confirm its runtime and model paths."
        if re.search(r"\b(what have you learned|how many pages|what do you know)\b",t):
            with sqlite3.connect(DB_PATH) as c:
                count=c.execute("SELECT COUNT(*) FROM pages").fetchone()[0]
                lesson_count=c.execute("SELECT COUNT(*) FROM lessons").fetchone()[0]
            return f"So far, this installation has {count} saved webpage(s) and {lesson_count} taught lesson(s). Saved material is stored on this computer. That is different from having a working language model installed."
        if re.search(r"\b(explain|what is|what are|why does|how does|how do|tell me about)\b",t):
            topic=re.sub(r"^(please\s+)?(can you\s+)?(explain|what is|what are|why does|how does|how do|tell me about)\s+", "", question, flags=re.I).strip(" ?.!\t")
            if topic:
                return (f"I can help explore **{topic}**, but my local language model isn't available yet, so I can't reliably explain that topic from general knowledge in this mode. "
                        "If you switch to Research mode and save a trustworthy source, I can summarise the saved material; alternatively, install a compatible local model to enable generated answers.")
        if re.search(r"\b(bye|goodbye|see you|good night)\b",t):
            return "See you later! 😊 Your saved chats stay on this computer. Come back whenever you'd like to continue."
        if len(t.split()) <= 3:
            return "I'm listening. Could you tell me a little more about what you mean? My language model isn't installed yet, so I may need a more specific prompt in this limited mode."
        return offline_answer(question, lessons)
    return chatbot_fallback(question,hits,lessons)

class App:
 def __init__(self,root):
    self.root=root;self.settings=load_settings();db_init();self.events=queue.Queue();self.busy=False;self.stop_event=threading.Event()
    with sqlite3.connect(DB_PATH) as c:
     latest=c.execute("SELECT id FROM chat_sessions ORDER BY updated_at DESC LIMIT 1").fetchone()
     self.current_session_id=latest[0] if latest else self.create_session_row("New chat")
    root.title(APP_NAME);root.geometry("980x720");root.minsize(740,560);self.build();self.load_chat();self.refresh_stats();root.after(150,self.poll);root.protocol("WM_DELETE_WINDOW",self.close)
    self.apply_mode()
    if not self.has_messages():
     greeting=("Hi! 😊 Welcome to MINI AI LITE X. Your chats are saved locally. The local language model is ready." if self.settings.get("llama_cli_path") and self.settings.get("model_path") and Path(str(self.settings.get("llama_cli_path"))).is_file() and Path(str(self.settings.get("model_path"))).is_file() else "Hi! 😊 MINI AI LITE X has started. Chats and saved lessons are available, but the language-model files are not installed yet, so replies are limited until setup succeeds.")
     self.say("MINI AI LITE X",greeting,persist=True)
    if self.settings.get("research_on_startup") and self.settings.get("auto_learning_enabled"):
     root.after(2200, self.start_startup_learning)
    root.after(60000,self.scheduler)
 def build(self):
    # ChatGPT-inspired layout using native Tk widgets; no browser engine or account required.
    style=ttk.Style(self.root)
    try: style.theme_use("clam")
    except Exception: pass
    bg="#212121"; panel="#171717"; fg="#eeeeee"; muted="#a8a8a8"; accent="#10a37f"
    self.root.configure(bg=bg)
    style.configure("TFrame",background=bg)
    style.configure("Side.TFrame",background=panel)
    style.configure("TLabel",background=bg,foreground=fg,font=("Segoe UI",10))
    style.configure("Muted.TLabel",background=bg,foreground=muted,font=("Segoe UI",9))
    style.configure("Title.TLabel",background=bg,foreground=fg,font=("Segoe UI",15,"bold"))
    style.configure("TButton",font=("Segoe UI",9),padding=(9,6),background="#343434",foreground=fg)
    style.map("TButton",background=[("active","#454545")],foreground=[("disabled","#777777")])
    style.configure("Accent.TButton",background=accent,foreground="white",padding=(12,7))
    style.map("Accent.TButton",background=[("active","#0e8f70")])
    shell=ttk.Frame(self.root);shell.pack(fill="both",expand=True)
    side=ttk.Frame(shell,style="Side.TFrame",padding=10,width=205);side.pack(side="left",fill="y");side.pack_propagate(False)
    ttk.Label(side,text="✳ MINI AI LITE X",font=("Segoe UI",13,"bold"),background=panel,foreground=fg).pack(anchor="w",pady=(5,14))
    ttk.Button(side,text="💬  Talk",command=lambda:self.set_mode(True)).pack(fill="x",pady=3)
    ttk.Button(side,text="＋  New chat",command=self.new_chat).pack(fill="x",pady=3)
    ttk.Button(side,text="▤  Saved chats",command=self.saved_chats).pack(fill="x",pady=3)
    self.research_buttons=[]
    for label,command in [("⌕  Deep research",self.deep_topic_dialog),("↗  Research topic",self.topic_dialog),("▤  Learn a webpage",self.url_dialog),("▣  Saved knowledge",self.manage)]:
     b=ttk.Button(side,text=label,command=command);self.research_buttons.append(b)
    self.auto_button=ttk.Button(side,text="🌐  AutoLearn: ON",command=self.toggle_auto_learning)
    self.auto_button.pack(fill="x",pady=3)
    ttk.Button(side,text="⌨  Code & wiring",command=self.open_coder).pack(fill="x",pady=3)
    ttk.Button(side,text="▧  Upload & improve",command=self.upload_center).pack(fill="x",pady=3)
    ttk.Button(side,text="✎  Teach AI",command=self.teach_ai).pack(fill="x",pady=3)
    ttk.Button(side,text="▤  My Lessons",command=self.manage_lessons).pack(fill="x",pady=3)
    ttk.Button(side,text="🎨  Offline media studio",command=self.media_studio).pack(fill="x",pady=3)
    ttk.Button(side,text="⚙  Settings",command=self.settings_dialog).pack(fill="x",pady=3)
    self.mode_button=ttk.Button(side,text="↗  Research mode",command=lambda:self.set_mode(False))
    ttk.Separator(side).pack(fill="x",pady=12)
    self.mode_label=ttk.Label(side,text="● Offline-ready",background=panel,foreground="#8bd5b0",wraplength=175)
    self.mode_label.pack(anchor="w",pady=3)
    ttk.Label(side,text="Local knowledge stays on this PC. Online research is optional.",background=panel,foreground=muted,wraplength=175).pack(anchor="w",pady=4)
    main=ttk.Frame(shell);main.pack(side="left",fill="both",expand=True)
    head=ttk.Frame(main,padding=(18,12));head.pack(fill="x")
    ttk.Label(head,text="Talk",style="Title.TLabel").pack(side="left")
    self.expression=ttk.Label(head,text="😌 Calm",style="Muted.TLabel")
    self.expression.pack(side="left",padx=(14,0))
    self.stats=ttk.Label(head,text="Knowledge: 0 pages",style="Muted.TLabel");self.stats.pack(side="right")
    chatwrap=ttk.Frame(main);chatwrap.pack(fill="both",expand=True,padx=14,pady=(0,8))
    self.chat=tk.Text(chatwrap,wrap="word",state="disabled",font=("Segoe UI",10),padx=18,pady=14,
        bg="#212121",fg="#eeeeee",insertbackground="white",relief="flat",borderwidth=0,
        selectbackground="#365b55",spacing1=4,spacing3=8)
    scroll=ttk.Scrollbar(chatwrap,command=self.chat.yview);self.chat.configure(yscrollcommand=scroll.set)
    self.chat.pack(side="left",fill="both",expand=True);scroll.pack(side="right",fill="y")
    self.chat.tag_configure("user",foreground="#8bd5b0",font=("Segoe UI",10,"bold"),spacing1=10)
    self.chat.tag_configure("assistant",foreground="#eeeeee",font=("Segoe UI",10,"bold"),spacing1=10)
    self.chat.tag_configure("body",foreground="#e2e2e2",font=("Segoe UI",10),lmargin1=3,lmargin2=3)
    composer=ttk.Frame(main,padding=(14,6,14,8));composer.pack(fill="x")
    entrybox=ttk.Frame(composer);entrybox.pack(fill="x")
    self.entry=tk.Entry(entrybox,font=("Segoe UI",11),bg="#303030",fg="#eeeeee",insertbackground="white",relief="flat",borderwidth=8)
    self.entry.pack(side="left",fill="x",expand=True,ipady=7);self.entry.bind("<Return>",lambda e:self.ask())
    ttk.Button(entrybox,text="Send  ↑",style="Accent.TButton",command=self.ask).pack(side="left",padx=(8,0))
    ttk.Label(composer,text="Talk mode: conversation only. Saved chats stay on this PC.",style="Muted.TLabel").pack(anchor="w",pady=(6,0))
    self.status=ttk.Label(main,text="Ready · Chat and saved knowledge work offline",anchor="w",padding=(14,6),style="Muted.TLabel");self.status.pack(fill="x")
 def create_session_row(self,title):
    sid=uuid.uuid4().hex;now=int(time.time())
    with sqlite3.connect(DB_PATH) as c:c.execute("INSERT INTO chat_sessions(id,title,created_at,updated_at) VALUES(?,?,?,?)",(sid,title,now,now))
    return sid
 def has_messages(self):
    with sqlite3.connect(DB_PATH) as c:return bool(c.execute("SELECT 1 FROM chat WHERE session_id=? LIMIT 1",(self.current_session_id,)).fetchone())
 def apply_mode(self):
    talk=bool(self.settings.get("talk_only_mode",True))
    for b in self.research_buttons:
     if talk:b.pack_forget()
     else:b.pack(fill="x",pady=3)
    if talk:self.mode_button.pack(fill="x",pady=3)
    else:self.mode_button.pack_forget()
    cli=Path(str(self.settings.get("llama_cli_path", ""))) if self.settings.get("llama_cli_path") else None
    model=Path(str(self.settings.get("model_path", ""))) if self.settings.get("model_path") else None
    model_ready=bool(cli and model and cli.is_file() and model.is_file())
    if model_ready:
     label="● Local AI model ready · "+("Talk mode" if talk else "Research mode"); color="#8bd5b0"
    else:
     label="● Limited offline mode · model not installed"; color="#e6a06a"
    self.mode_label.configure(text=label,foreground=color)
    self.update_auto_button()
    self.status.configure(text=("Talk mode · chatbot only · AutoLearn runs separately when enabled" if talk else "Research mode · online tools available"))
 def set_mode(self,talk):
    self.settings["talk_only_mode"]=bool(talk);save_settings(self.settings);self.apply_mode()
    if talk:self.say(APP_NAME,"💬 Talk mode is on. I won't run web searches or gather webpages here. Let's just chat!",persist=False)
    else:self.say(APP_NAME,"Research mode is on. Web research and webpage-learning tools are available in the menu.",persist=False)
 def new_chat(self):
    self.current_session_id=self.create_session_row("New chat")
    self.chat.configure(state="normal");self.chat.delete("1.0","end");self.chat.configure(state="disabled")
    self.say("MINI AI LITE X","New chat started. 😊 What would you like to talk about?",persist=True)
 def load_chat(self):
    try:
     with sqlite3.connect(DB_PATH) as c:rows=c.execute("SELECT role,body FROM chat WHERE session_id=? ORDER BY id DESC LIMIT 160",(self.current_session_id,)).fetchall()
     self.chat.configure(state="normal")
     for role,body in reversed(rows):self.chat.insert("end",f"{role}\n{body}\n\n")
     self.chat.configure(state="disabled");self.chat.see("end")
    except Exception:pass
 def saved_chats(self):
    win=tk.Toplevel(self.root);win.title("Saved chats");win.geometry("620x460");win.minsize(460,320)
    outer=ttk.Frame(win,padding=12);outer.pack(fill="both",expand=True)
    ttk.Label(outer,text="Saved chats",font=("Segoe UI",15,"bold")).pack(anchor="w")
    ttk.Label(outer,text="Your conversations are saved locally and can be reopened later.").pack(anchor="w",pady=(4,10))
    lb=tk.Listbox(outer,font=("Segoe UI",10),bg="#303030",fg="#eeeeee",selectbackground="#176b59",relief="flat",height=14)
    lb.pack(fill="both",expand=True)
    with sqlite3.connect(DB_PATH) as c:rows=c.execute("SELECT s.id,s.title,s.updated_at,COUNT(ch.id) FROM chat_sessions s LEFT JOIN chat ch ON ch.session_id=s.id GROUP BY s.id ORDER BY s.updated_at DESC").fetchall()
    for sid,title,stamp,count in rows:lb.insert("end",f"{title}  ·  {time.strftime('%Y-%m-%d %H:%M',time.localtime(stamp))}  ·  {count} messages")
    def open_selected():
     sel=lb.curselection()
     if not sel:return
     self.current_session_id=rows[sel[0]][0]
     self.chat.configure(state="normal");self.chat.delete("1.0","end");self.chat.configure(state="disabled")
     self.load_chat();self.status.configure(text="Opened saved chat");win.destroy()
    def rename_selected():
     sel=lb.curselection()
     if not sel:return
     title=simpledialog.askstring("Rename saved chat","Enter a name for this chat:",initialvalue=rows[sel[0]][1],parent=win)
     if title and title.strip():
      with sqlite3.connect(DB_PATH) as c:c.execute("UPDATE chat_sessions SET title=?,updated_at=? WHERE id=?",(title.strip()[:100],int(time.time()),rows[sel[0]][0]))
      rows[sel[0]]=(rows[sel[0]][0],title.strip()[:100],rows[sel[0]][2],rows[sel[0]][3]);lb.delete(sel[0]);lb.insert(sel[0],f"{rows[sel[0]][1]}  ·  {time.strftime('%Y-%m-%d %H:%M',time.localtime(rows[sel[0]][2]))}  ·  {rows[sel[0]][3]} messages");lb.selection_set(sel[0])
    buttons=ttk.Frame(outer);buttons.pack(fill="x",pady=(10,0))
    ttk.Button(buttons,text="Open chat",command=open_selected).pack(side="left")
    ttk.Button(buttons,text="Rename",command=rename_selected).pack(side="left",padx=6)
    ttk.Button(buttons,text="Close",command=win.destroy).pack(side="right")
    lb.bind("<Double-Button-1>",lambda e:open_selected())
 def say(self,role,text,persist=True):
    self.chat.configure(state="normal")
    tag="user" if role=="You" else "assistant" if role==APP_NAME else "body"
    self.chat.insert("end",f"{role}\n",tag);self.chat.insert("end",f"{text}\n\n","body");self.chat.see("end");self.chat.configure(state="disabled")
    if persist:
     try:
      incoming=len(text.encode("utf-8"))+256
      chat_cap=int(self.settings.get("chat_storage_limit_gb",50))*(1024**3)
      total_cap=int(self.settings.get("storage_limit_gb",200))*(1024**3)
      if chat_storage_bytes()+incoming>chat_cap:
       self.status.configure(text="Saved chat limit reached. Increase the chat limit in Settings or remove old chat history.")
       return
      if app_storage_bytes()+incoming>total_cap:
       self.status.configure(text="Total app storage limit reached. Increase the limit in Settings or free app storage.")
       return
      now=int(time.time())
      with sqlite3.connect(DB_PATH) as c:
       c.execute("INSERT INTO chat(role,body,saved_at,session_id) VALUES(?,?,?,?)",(role,text,now,self.current_session_id))
       if role=="You":
        row=c.execute("SELECT title FROM chat_sessions WHERE id=?",(self.current_session_id,)).fetchone()
        if row and row[0] in ("New chat","Earlier chat history"):c.execute("UPDATE chat_sessions SET title=?,updated_at=? WHERE id=?",(text[:70],now,self.current_session_id))
        else:c.execute("UPDATE chat_sessions SET updated_at=? WHERE id=?",(now,self.current_session_id))
       else:c.execute("UPDATE chat_sessions SET updated_at=? WHERE id=?",(now,self.current_session_id))
     except Exception:pass
 def ask(self):
    q=self.entry.get().strip()
    if not q:return
    self.entry.delete(0,"end");self.say("You",q);self.status.configure(text="Thinking…" if self.settings.get("talk_only_mode") else "Thinking and checking saved knowledge…")
    self.set_expression(q);talk_only=bool(self.settings.get("talk_only_mode",False))
    self.run_bg(lambda:answer_question(q,self.settings,talk_only=talk_only),lambda r:self.say("MINI AI LITE X",self.decorate_response(r,q)))
 def set_expression(self,text):
    emoji,mood,_=expression_for(text)
    if hasattr(self,"expression"):
     self.expression.configure(text=f"{emoji} {mood}")
 def decorate_response(self,response,question):
    # Keep the response readable while letting the chosen expression show in the chat too.
    emoji,mood,_=expression_for(question)
    text=(response or "").strip()
    if not text:return "… I'm still thinking. Could you try asking that another way?"
    if text.startswith(("😊","😄","🤔","😌","🤗","🧐")):return text
    if mood in ("Cheerful","Friendly"):
     return emoji+" "+text
    if mood=="Supportive":
     return "🤗 "+text
    if mood=="Curious":
     return "🤔 "+text
    if mood=="Focused":
     return "🧐 "+text
    return text
 def run_bg(self,fn,done):
    def worker():
     try:self.events.put((done,fn(),None))
     except Exception as e:self.events.put((done,None,str(e)))
    threading.Thread(target=worker,daemon=True).start()
 def poll(self):
    try:
     while True:
      done,result,error=self.events.get_nowait()
      if error:
       self.say("Error",error);self.status.configure(text="Task failed — see error above")
       if hasattr(self,"mode_label"):self.mode_label.configure(text="● Offline / source unavailable",foreground="#e6a06a")
      else:
       done(result)
       if self.busy is False and self.status.cget("text")=="Ready":self.status.configure(text="Ready · Offline chat remains available")
      self.refresh_stats()
    except queue.Empty:pass
    if self.root.winfo_exists():self.root.after(150,self.poll)
 def update_auto_button(self):
    if hasattr(self,"auto_button"):
     enabled=bool(self.settings.get("auto_learning_enabled",True))
     self.auto_button.configure(text=("🌐  AutoLearn: ON" if enabled else "⏸  AutoLearn: OFF"))
 def start_startup_learning(self):
    if self.stop_event.is_set() or not self.settings.get("auto_learning_enabled") or not self.settings.get("research_on_startup"):
     return
    # Do not repeat startup research if a recent scheduled run already happened.
    interval=float(self.settings.get("research_interval_hours",6))*3600
    if time.time()-float(self.settings.get("last_auto_research",0)) < interval:
     return
    self.start_research(self.settings.get("startup_topic","basic science and technology"),automatic=True)
 def toggle_auto_learning(self):
    enabled=not bool(self.settings.get("auto_learning_enabled",True))
    self.settings["auto_learning_enabled"]=enabled
    if enabled:
     # Trigger a single run now; subsequent runs follow the configured schedule.
     self.settings["last_auto_research"]=0
    save_settings(self.settings);self.update_auto_button()
    if enabled:
     self.status.configure(text="AutoLearn enabled · starting a small public-web research run")
     self.say("AutoLearn","Automatic learning is ON. I'll read a small number of accessible public webpages, save their text locally, skip duplicates, and use that saved knowledge in future chats. I don't retrain model weights.",persist=False)
     if not self.busy:
      i=int(self.settings.get("auto_topic_index",0))%len(TOPICS)
      self.settings["auto_topic_index"]=(i+1)%len(TOPICS);save_settings(self.settings)
      self.start_research(TOPICS[i],automatic=True)
    else:
     self.status.configure(text="AutoLearn paused · saved knowledge remains available offline")
     self.say("AutoLearn","Automatic internet research is paused. Your saved knowledge and chats remain on this computer.",persist=False)
 def topic_dialog(self):
    q=simpledialog.askstring(APP_NAME,"What topic should I research?",parent=self.root)
    if q and q.strip():self.start_research(q.strip())
 def deep_topic_dialog(self):
    q=simpledialog.askstring(APP_NAME,"What question should I deeply research? The app will search several angles, read accessible pages, save the extracted text, and produce a source report.",parent=self.root)
    if q and q.strip():self.start_deep_research(q.strip())
 def start_deep_research(self,query):
    if self.busy:
     self.say(APP_NAME,"A research task is already running. Please wait for it to finish.");return
    self.busy=True;self.mode_label.configure(text="● Online research running",foreground="#f0c674")
    self.status.configure(text="Deep research: planning searches and collecting sources…")
    self.say("Research agent","Starting deep research on: "+query+"\nI will search several related angles, read page text, deduplicate it, and save usable sources.",persist=False)
    def task():
     angles=[query,query+" explained",query+" evidence research",query+" benefits risks limitations"]
     urls=[];notes=[]
     for angle in angles:
      try:
       found,errs=search_web(angle,max(2,min(4,self.settings["max_pages_per_run"])),self.settings["request_timeout_seconds"])
       for u in found:
        if u not in urls:urls.append(u)
       notes.extend(errs)
      except Exception as e:notes.append("Search for "+angle+": "+str(e))
      if len(urls)>=self.settings["max_pages_per_run"]*2:break
     if not urls:raise RuntimeError("Deep research could not find accessible search results. Try a direct link with Learn a webpage.\n"+"\n".join(notes))
     report=[];saved=0;read=0
     for i,u in enumerate(urls[:self.settings["max_pages_per_run"]*2],1):
      self.events.put((lambda msg:self.status.configure(text=msg),f"Deep research · reading source {i}: {u}",None))
      try:
       r=save_page(u,query,self.settings);report.append(r["message"]);read+=1
       if r["status"]=="saved":saved+=1
       if self.settings.get("open_research_pages",False):
        try:webbrowser.open(u,new=2)
        except Exception:pass
      except Exception as e:report.append("Could not read "+u+" — "+str(e))
     return "DEEP RESEARCH REPORT\nTopic: "+query+f"\nPages attempted: {len(urls[:self.settings['max_pages_per_run']*2])} · Newly saved: {saved} · Processed: {read}\n\n"+"\n\n".join(report)+"\n\nThe full extracted text of successfully saved pages is stored locally and can be inspected under Saved knowledge. Results depend on which public pages are accessible; JavaScript-only, paywalled, or blocked pages may fail."
    def done(result):
     self.busy=False;self.mode_label.configure(text="● Online research finished",foreground="#8bd5b0")
     self.say("Deep research report",result);self.status.configure(text="Deep research complete · Saved text is available offline")
    def worker():
     try:r=task();self.events.put((done,r,None))
     except Exception as e:self.events.put((done,None,str(e)))
     finally:self.busy=False
    threading.Thread(target=worker,daemon=True).start()
 def url_dialog(self):
    u=simpledialog.askstring(APP_NAME,"Paste a public webpage link (https://...). The app will open it in your browser, read its text, and save it.",parent=self.root)
    if not u:return
    u=u.strip()
    if self.settings.get("open_manual_urls",True):
     try:webbrowser.open(u,new=2)
     except Exception as e:self.say("Browser notice","Could not open your browser automatically: "+str(e),persist=False)
    self.status.configure(text="Opening link, reading page text, and saving knowledge…")
    self.say("Learning agent","Opening and reading: "+u,persist=False)
    self.run_bg(lambda:save_page(u,"manual URL",self.settings),lambda r:self.show_learning_result(r))
 def show_learning_result(self,result):
    self.say("Learning result",result.get("message",str(result)))
    if result.get("status")=="saved":self.say("MINI AI LITE X","I saved the readable page text locally. Ask me questions about this topic now, or after restarting/offline.",persist=False)
    self.status.configure(text="Page reading complete")
 def start_research(self,query,automatic=False):
    if self.busy:
     if not automatic:self.say("MINI AI LITE X","A research task is already running. Please wait for it to finish.")
     return
    self.busy=True;self.status.configure(text="Searching public sources for: "+query);self.say("Research agent","Searching for: "+query,persist=False)
    if automatic:
     # Throttle even failed attempts: an offline laptop must not retry every minute.
     self.settings["last_auto_research"]=time.time();save_settings(self.settings)
    def task():
     messages=[];urls,errors=search_web(query,self.settings["max_pages_per_run"],self.settings["request_timeout_seconds"]);messages.extend(errors);saved=0
     if not urls:raise RuntimeError("No search results were found. Try Learn URL with a known public webpage.")
     for i,url in enumerate(urls[:self.settings["max_pages_per_run"]],1):
      if automatic and (self.stop_event.is_set() or not self.settings.get("auto_learning_enabled",True)):
       messages.append("AutoLearn was paused; remaining pages were skipped.");break
      self.events.put((lambda msg:self.status.configure(text=msg),f"Reading page {i}/{min(len(urls),self.settings['max_pages_per_run'])}: {url}",None))
      if not automatic and self.settings.get("open_research_pages",False):
       try:webbrowser.open(url,new=2)
       except Exception:pass
      try:
       result=save_page(url,query,self.settings);messages.append(result["message"])
       if result["status"]=="saved":saved+=1
      except Exception as e:messages.append("Could not read "+url+" — "+str(e))
     return "\n\n".join(messages)+f"\n\nResearch finished. Newly saved pages: {saved}."
    def finished(result):
     self.busy=False
     if result:self.say("Research report",result)
     self.status.configure(text="Research finished · saved text is available offline")
     self.mode_label.configure(text="● Online research finished",foreground="#8bd5b0")
    def worker():
     try:r=task();self.events.put((finished,r,None))
     except Exception as e:self.events.put((finished,None,str(e)))
     finally:self.busy=False
    threading.Thread(target=worker,daemon=True).start()
 def scheduler(self):
    if not self.stop_event.is_set() and self.settings.get("auto_learning_enabled"):
     due=time.time()-float(self.settings.get("last_auto_research",0))>=self.settings["research_interval_hours"]*3600
     if due and not self.busy:
      i=int(self.settings.get("auto_topic_index",0))%len(TOPICS);topic=TOPICS[i];self.settings["auto_topic_index"]=i+1;save_settings(self.settings);self.start_research(topic,automatic=True)
    if self.root.winfo_exists():self.root.after(60000,self.scheduler)
 def teach_ai(self):
    win=tk.Toplevel(self.root);win.title("Teach MINI AI LITE X");win.geometry("720x560");win.minsize(560,420)
    outer=ttk.Frame(win,padding=14);outer.pack(fill="both",expand=True)
    ttk.Label(outer,text="Teach AI",font=("Segoe UI",15,"bold")).pack(anchor="w")
    ttk.Label(outer,text="Save a fact, explanation, preference, or correction. It will remain on this PC and be searched during future chats. This adds searchable memory; it does not retrain the model's neural-network weights.",wraplength=680).pack(anchor="w",pady=(5,12))
    ttk.Label(outer,text="Lesson title / topic").pack(anchor="w")
    title=tk.Entry(outer);title.pack(fill="x",pady=(3,10))
    ttk.Label(outer,text="Type of lesson").pack(anchor="w")
    kind=tk.StringVar(value="fact")
    ttk.Combobox(outer,textvariable=kind,values=["fact","correction","preference","instruction","note"],state="readonly").pack(anchor="w",pady=(3,10))
    ttk.Label(outer,text="What should I learn? (include the corrected answer if correcting me)").pack(anchor="w")
    body=tk.Text(outer,wrap="word",height=12);body.pack(fill="both",expand=True,pady=(3,10))
    def save_lesson():
        t=title.get().strip();b=body.get("1.0","end").strip();k=kind.get()
        if not t or not b:
            messagebox.showinfo(APP_NAME,"Enter both a title and lesson text.",parent=win);return
        now=int(time.time())
        with sqlite3.connect(DB_PATH) as c:c.execute("INSERT INTO lessons(title,content,kind,created_at,updated_at) VALUES(?,?,?,?,?)",(t[:250],b[:50000],k,now,now))
        self.refresh_stats();self.status.configure(text="Lesson saved locally · available in future chats, including offline")
        messagebox.showinfo(APP_NAME,"Lesson saved. I'll search it when a future question appears related. You can review or remove it in My Lessons.",parent=win)
        title.delete(0,"end");body.delete("1.0","end")
    def import_file():
        path=filedialog.askopenfilename(parent=win,title="Teach AI from a text file",filetypes=[("Text and code files","*.txt *.md *.py *.ino *.c *.cpp *.h *.json *.csv *.html *.css *.js"),("All files","*.*")])
        if not path:return
        try:
            data=Path(path).read_text(encoding="utf-8",errors="replace")
            if len(data)>50000:data=data[:50000]
            if not title.get().strip():title.insert(0,Path(path).name)
            body.delete("1.0","end");body.insert("1.0",data)
        except Exception as e:messagebox.showerror(APP_NAME,"Could not read this file: "+str(e),parent=win)
    bar=ttk.Frame(outer);bar.pack(fill="x")
    ttk.Button(bar,text="Import text/code file…",command=import_file).pack(side="left")
    ttk.Button(bar,text="Save lesson",style="Accent.TButton",command=save_lesson).pack(side="right")
 def manage_lessons(self):
    win=tk.Toplevel(self.root);win.title("My Lessons — review, edit, or delete what AI learned");win.geometry("900x570");win.minsize(680,420)
    tree=ttk.Treeview(win,columns=("kind","title","date"),show="headings",selectmode="browse")
    for col,label,width in [("kind","Type",110),("title","Lesson title",560),("date","Updated",150)]:tree.heading(col,text=label);tree.column(col,width=width,anchor="w")
    tree.pack(fill="both",expand=True,padx=8,pady=8)
    def refresh():
        tree.delete(*tree.get_children())
        with sqlite3.connect(DB_PATH) as c:rows=c.execute("SELECT id,kind,title,updated_at FROM lessons ORDER BY updated_at DESC").fetchall()
        for lid,k,t,stamp in rows:tree.insert("","end",iid=str(lid),values=(k,t,time.strftime("%Y-%m-%d %H:%M",time.localtime(stamp))) )
    def selected():
        sel=tree.selection();return int(sel[0]) if sel else None
    def edit():
        lid=selected()
        if lid is None:messagebox.showinfo(APP_NAME,"Select a lesson first.",parent=win);return
        with sqlite3.connect(DB_PATH) as c:r=c.execute("SELECT title,content,kind FROM lessons WHERE id=?",(lid,)).fetchone()
        if not r:return
        d=tk.Toplevel(win);d.title("Edit lesson");d.geometry("680x520");f=ttk.Frame(d,padding=12);f.pack(fill="both",expand=True)
        ttk.Label(f,text="Title").pack(anchor="w");t=tk.Entry(f);t.pack(fill="x",pady=4);t.insert(0,r[0])
        ttk.Label(f,text="Type").pack(anchor="w");k=tk.StringVar(value=r[2]);ttk.Combobox(f,textvariable=k,values=["fact","correction","preference","instruction","note"],state="readonly").pack(anchor="w",pady=4)
        ttk.Label(f,text="Lesson text").pack(anchor="w");b=tk.Text(f,wrap="word");b.pack(fill="both",expand=True,pady=4);b.insert("1.0",r[1])
        def save_edit():
            if not t.get().strip() or not b.get("1.0","end").strip():messagebox.showinfo(APP_NAME,"Title and text are required.",parent=d);return
            with sqlite3.connect(DB_PATH) as c:c.execute("UPDATE lessons SET title=?,content=?,kind=?,updated_at=? WHERE id=?",(t.get().strip()[:250],b.get("1.0","end").strip()[:50000],k.get(),int(time.time()),lid))
            d.destroy();refresh();self.refresh_stats()
        ttk.Button(f,text="Save changes",command=save_edit).pack(anchor="e",pady=4)
    def delete():
        lid=selected()
        if lid is None:return
        if not messagebox.askyesno(APP_NAME,"Permanently delete this lesson?",parent=win):return
        with sqlite3.connect(DB_PATH) as c:c.execute("DELETE FROM lessons WHERE id=?",(lid,))
        refresh();self.refresh_stats()
    bar=ttk.Frame(win,padding=8);bar.pack(fill="x")
    ttk.Button(bar,text="Teach another lesson",command=self.teach_ai).pack(side="left",padx=4)
    ttk.Button(bar,text="View / edit selected",command=edit).pack(side="left",padx=4)
    ttk.Button(bar,text="Delete selected",command=delete).pack(side="left",padx=4)
    refresh()
 def manage(self):
    win=tk.Toplevel(self.root);win.title("Saved knowledge — inspect, open, or delete");win.geometry("900x470")
    tree=ttk.Treeview(win,columns=("title","url","date","chars"),show="headings",selectmode="browse")
    for col,label,width in [("title","Title",230),("url","Source URL",440),("date","Saved",125),("chars","Text chars",85)]:tree.heading(col,text=label);tree.column(col,width=width,anchor="w")
    tree.pack(fill="both",expand=True,padx=8,pady=8)
    with sqlite3.connect(DB_PATH) as c:rows=c.execute("SELECT id,title,url,saved_at,length(body) FROM pages ORDER BY saved_at DESC").fetchall()
    for pid,title,url,stamp,n in rows:tree.insert("","end",iid=str(pid),values=(title,url,time.strftime("%Y-%m-%d %H:%M",time.localtime(stamp)),f"{n:,}"))
    def selected():
     s=tree.selection();return int(s[0]) if s else None
    def inspect():
     pid=selected()
     if pid is None:return
     with sqlite3.connect(DB_PATH) as c:r=c.execute("SELECT title,url,body FROM pages WHERE id=?",(pid,)).fetchone()
     if r:
      d=tk.Toplevel(win);d.title(r[0]);d.geometry("780x540");ttk.Label(d,text=r[0],font=("Segoe UI",12,"bold")).pack(anchor="w",padx=8,pady=5);ttk.Label(d,text=r[1],wraplength=750).pack(anchor="w",padx=8)
      box=tk.Text(d,wrap="word");box.pack(fill="both",expand=True,padx=8,pady=8);box.insert("1.0",r[2]);box.configure(state="disabled")
    def open_page():
     pid=selected()
     if pid is None:messagebox.showinfo(APP_NAME,"Select a saved page first.",parent=win);return
     with sqlite3.connect(DB_PATH) as c:r=c.execute("SELECT url FROM pages WHERE id=?",(pid,)).fetchone()
     if r:webbrowser.open(r[0],new=2)
    def delete():
     pid=selected()
     if pid is None:return
     if not messagebox.askyesno(APP_NAME,"Delete this saved page?",parent=win):return
     with sqlite3.connect(DB_PATH) as c:c.execute("DELETE FROM pages WHERE id=?",(pid,))
     tree.delete(str(pid));self.refresh_stats()
    bar=ttk.Frame(win,padding=8);bar.pack(fill="x")
    for label,fn in [("Inspect saved text",inspect),("Open Page in browser",open_page),("Delete selected",delete)]:ttk.Button(bar,text=label,command=fn).pack(side="left",padx=4)
 def open_coder(self):
    """Offline code workspace powered by the configured local GGUF model."""
    win=tk.Toplevel(self.root);win.title("MINI AI LITE X — Offline coding workshop");win.geometry("900x700");win.minsize(700,520)
    top=ttk.Frame(win,padding=10);top.pack(fill="x")
    ttk.Label(top,text="Offline coding workshop",font=("Segoe UI",14,"bold")).pack(anchor="w")
    ttk.Label(top,text="Describe a project to get code plus a separate wiring/design plan. Optional local image generation can draw a concept diagram; AI-drawn wiring is illustrative and must be checked against datasheets before connecting hardware.",wraplength=850).pack(anchor="w",pady=(4,8))
    row=ttk.Frame(win,padding=(10,0));row.pack(fill="x")
    ttk.Label(row,text="Language:").pack(side="left")
    language=tk.StringVar(value="Python")
    ttk.Combobox(row,textvariable=language,values=["Python","Arduino C++","HTML/CSS/JavaScript","C/C++","PowerShell","Other"],state="readonly",width=24).pack(side="left",padx=8)
    source_path=tk.StringVar(value="")
    def browse_source():
     f=filedialog.askopenfilename(parent=win,title="Choose existing code to repair",filetypes=[("Code files","*.py *.ino *.cpp *.h *.c *.html *.js *.css *.ps1 *.txt"),("All files","*.*")])
     if f:source_path.set(f)
    ttk.Button(row,text="Choose code to repair…",command=browse_source).pack(side="left",padx=6)
    ttk.Label(win,text="What should I build or fix? Include requirements and any error message:").pack(anchor="w",padx=10,pady=(10,3))
    request=tk.Text(win,height=5,wrap="word",font=("Segoe UI",10));request.pack(fill="x",padx=10)
    tabs=ttk.Notebook(win);tabs.pack(fill="both",expand=True,padx=10,pady=(10,8))
    code_tab=ttk.Frame(tabs);design_tab=ttk.Frame(tabs)
    tabs.add(code_tab,text="Code to upload");tabs.add(design_tab,text="Wiring & build plan")
    ttk.Label(code_tab,text="Generated code:").pack(anchor="w",padx=6,pady=(6,3))
    output=tk.Text(code_tab,wrap="none",font=("Consolas",10),undo=True);output.pack(fill="both",expand=True,padx=6,pady=(0,6))
    ttk.Label(design_tab,text="Parts list, pin-by-pin wiring, power notes, build steps, and safety checks:").pack(anchor="w",padx=6,pady=(6,3))
    design=tk.Text(design_tab,wrap="word",font=("Segoe UI",10),undo=True);design.pack(fill="both",expand=True,padx=6,pady=(0,6))
    status=tk.StringVar(value="Ready. Configure a local llama.cpp executable and GGUF model in Settings to generate code offline.")
    ttk.Label(win,textvariable=status,wraplength=850).pack(anchor="w",padx=10,pady=(0,6))
    def get_existing():
     f=source_path.get().strip()
     if not f:return ""
     try:
      text=Path(f).read_text(encoding="utf-8",errors="replace")
      return text[:24000]
     except Exception as e:raise RuntimeError("Could not read selected source file: "+str(e))
    def generate(repair=False):
     task=request.get("1.0","end").strip()
     if not task:
      messagebox.showinfo(APP_NAME,"Describe the program or fix you want first.",parent=win);return
     existing_path=source_path.get().strip()
     try:existing=get_existing()
     except Exception as e:messagebox.showerror(APP_NAME,str(e),parent=win);return
     if repair and not existing:
      messagebox.showinfo(APP_NAME,"Choose an existing source file first so I can inspect and repair it.",parent=win);return
     if not self.settings.get("llama_cli_path") or not self.settings.get("model_path"):
      messagebox.showwarning(APP_NAME,"Offline code generation needs a local model. Open Settings and set the llama.cpp executable path and a compatible GGUF model file. No hosted AI is used by this coding workspace. On a 4 GB laptop, choose a small quantized model and close other apps.",parent=win);return
     lang=language.get()
     if repair:
      prompt=("You are an expert offline programming assistant. Repair the supplied source code according to the user's request and error. Preserve existing features unless asked otherwise. Return the COMPLETE corrected file only, no markdown fences. Language: "+lang+"\nUser request/error:\n"+task+"\nExisting file path (context only): "+existing_path+"\nSOURCE START\n"+existing+"\nSOURCE END")
     else:
      prompt=("You are MINI AI LITE X, an expert coding assistant working fully offline. Create a complete, practical program. Follow the user's requirements, include useful comments and error handling, avoid claiming tests were run, and return only source code without markdown fences. Language: "+lang+"\nRequirements:\n"+task)
     status.set("Local model is writing code… This may take several minutes on this laptop.")
     def work():
      result=local_model(prompt,self.settings)
      if not result:raise RuntimeError("The local model did not return code. Check the llama.cpp path, GGUF model path, and model compatibility in Settings.")
      result=re.sub(r'^```[a-zA-Z0-9_+#.-]*\s*','',result.strip())
      result=re.sub(r'\s*```\s*$','',result)
      return result
     def done(result):
      output.delete("1.0","end");output.insert("1.0",result);status.set("Code generated locally. Review it before saving or running it.")
     self.run_bg(work,done)
    def generate_design():
     task=request.get("1.0","end").strip()
     if not task:messagebox.showinfo(APP_NAME,"Describe the project first.",parent=win);return
     if not self.settings.get("llama_cli_path") or not self.settings.get("model_path"):
      messagebox.showwarning(APP_NAME,"Design/wiring text needs a configured local GGUF model in Settings. No AI model is bundled.",parent=win);return
     lang=language.get()
     prompt=("You are a careful electronics and software design assistant. Based on the project request, return a practical build plan with: parts list, exact pin-to-pin wiring table, power/ground notes, build steps, assumptions, and verification/safety warnings. Never invent datasheet facts; mark uncertain details and tell the user to verify the exact board/module. For Arduino projects distinguish logic pins from power pins and warn not to power motors directly from GPIO. Do not output program code in this response.\nLanguage/platform: "+lang+"\nProject request:\n"+task)
     status.set("Writing the parts list and wiring plan locally…")
     def work():
      result=local_model(prompt,self.settings)
      if not result:raise RuntimeError("Local model did not return a plan. Check model paths and compatibility in Settings.")
      return result
     def done(result):design.delete("1.0","end");design.insert("1.0",result);tabs.select(design_tab);status.set("Wiring plan generated. Verify every connection before powering on.")
     self.run_bg(work,done)
    def save_design():
     text=design.get("1.0","end-1c")
     if not text.strip():messagebox.showinfo(APP_NAME,"Generate a wiring plan first.",parent=win);return
     f=filedialog.asksaveasfilename(parent=win,title="Save wiring plan",defaultextension=".txt",filetypes=[("Text files","*.txt"),("Markdown","*.md"),("All files","*.*")])
     if f:
      try:Path(f).write_text(text,encoding="utf-8");status.set("Saved wiring plan: "+f)
      except Exception as e:messagebox.showerror(APP_NAME,"Could not save plan: "+str(e),parent=win)
    def make_wiring_image():
     task=request.get("1.0","end").strip()
     if not task:messagebox.showinfo(APP_NAME,"Describe the project first.",parent=win);return
     api=simpledialog.askstring(APP_NAME,"Local Stable Diffusion / Forge API URL:",initialvalue="http://127.0.0.1:7860",parent=win)
     if not api:return
     prompt_img="A clean educational electronics concept illustration for this project: "+task+". White background, neatly labelled components, clear layout, technical infographic style. This is an illustrative concept only, not a verified electrical schematic; do not imply pin accuracy."
     status.set("Requesting an illustrative concept image from the local image model…")
     def work():
      req=urllib.request.Request(api.rstrip("/")+"/sdapi/v1/txt2img",data=json.dumps({"prompt":prompt_img,"steps":12,"width":512,"height":512,"batch_size":1}).encode(),headers={"Content-Type":"application/json"},method="POST")
      with urllib.request.urlopen(req,timeout=600) as r:data=json.loads(r.read(80000000).decode("utf-8"))
      if not data.get("images"):raise RuntimeError("Image API returned no image.")
      folder=APP_DIR/"generated_media";folder.mkdir(parents=True,exist_ok=True);dest=folder/("wiring_concept_"+time.strftime("%Y%m%d_%H%M%S")+".png");dest.write_bytes(base64.b64decode(data["images"][0].split(",",1)[-1]));return str(dest)
     def done(path):status.set("Concept image saved: "+path);messagebox.showinfo(APP_NAME,"Illustrative concept image saved to:\n"+path+"\n\nAI-generated wiring pictures may contain errors. Use the text wiring plan and official datasheets to verify connections.",parent=win)
     self.run_bg(work,done)
    def save_code():
     code=output.get("1.0","end-1c")
     if not code.strip():messagebox.showinfo(APP_NAME,"Generate code first.",parent=win);return
     default_ext={"Python":".py","Arduino C++":".ino","HTML/CSS/JavaScript":".html","C/C++":".cpp","PowerShell":".ps1","Other":".txt"}.get(language.get(),".txt")
     f=filedialog.asksaveasfilename(parent=win,title="Save generated code",defaultextension=default_ext,filetypes=[("Source files","*.py *.ino *.cpp *.h *.c *.html *.js *.css *.ps1 *.txt"),("All files","*.*")])
     if not f:return
     try:Path(f).write_text(code,encoding="utf-8");status.set("Saved code to: "+f)
     except Exception as e:messagebox.showerror(APP_NAME,"Could not save code: "+str(e),parent=win)
    def check_code():
     code=output.get("1.0","end-1c")
     if not code.strip():messagebox.showinfo(APP_NAME,"Generate code first.",parent=win);return
     if language.get()!="Python":messagebox.showinfo(APP_NAME,"Automatic syntax checking in this workspace currently supports Python only. The code has not been executed.",parent=win);return
     try:compile(code,"<MINI_AI_LITE_X_generated_code>","exec");status.set("Python syntax check passed. The program was NOT executed.");messagebox.showinfo(APP_NAME,"Python syntax check passed. This checks syntax only; it does not prove the program works or is safe.",parent=win)
     except SyntaxError as e:status.set(f"Python syntax error on line {e.lineno}: {e.msg}");messagebox.showerror(APP_NAME,f"Syntax error on line {e.lineno}: {e.msg}\n\nUse Repair code and include this error in your request.",parent=win)
    bar=ttk.Frame(win,padding=10);bar.pack(fill="x")
    ttk.Button(bar,text="Generate code",command=lambda:generate(False)).pack(side="left",padx=(0,6))
    ttk.Button(bar,text="Generate wiring plan",command=generate_design).pack(side="left",padx=6)
    ttk.Button(bar,text="Draw concept image…",command=make_wiring_image).pack(side="left",padx=6)
    ttk.Button(bar,text="Repair selected file",command=lambda:generate(True)).pack(side="left",padx=6)
    ttk.Button(bar,text="Check Python syntax",command=check_code).pack(side="left",padx=6)
    ttk.Button(bar,text="Save wiring plan…",command=save_design).pack(side="right",padx=5)
    ttk.Button(bar,text="Save code as…",command=save_code).pack(side="right")
 def upload_center(self):
    """Inspect uploaded text/code/docs, OCR images when Tesseract is installed, and request improvements."""
    win=tk.Toplevel(self.root);win.title("MINI AI LITE X — Upload & improve");win.geometry("900x700");win.minsize(700,540)
    outer=ttk.Frame(win,padding=12);outer.pack(fill="both",expand=True)
    ttk.Label(outer,text="Upload, inspect, improve, and save",font=("Segoe UI",15,"bold")).pack(anchor="w")
    ttk.Label(outer,text="Text and source files can be read directly. DOCX is supported. PDF text extraction uses pdftotext if installed. Images can be OCR-scanned if Tesseract is installed; direct visual understanding requires a compatible vision model, which is not bundled.",wraplength=850).pack(anchor="w",pady=(5,10))
    selected=tk.StringVar(value="No file selected");path_var=tk.StringVar(value="")
    def choose():
     f=filedialog.askopenfilename(parent=win,title="Choose an image or file",filetypes=[("Supported files","*.txt *.md *.py *.ino *.cpp *.h *.c *.html *.js *.css *.json *.xml *.csv *.log *.docx *.pdf *.png *.jpg *.jpeg *.bmp *.webp"),("All files","*.*")])
     if f:path_var.set(f);selected.set(f);preview.delete("1.0","end");preview.insert("1.0","Selected: "+f+"\nClick Scan file to extract readable content.")
    ttk.Button(outer,text="Choose image or file…",command=choose).pack(anchor="w")
    ttk.Label(outer,textvariable=selected,wraplength=850).pack(anchor="w",pady=4)
    ttk.Label(outer,text="What should be improved? (e.g. fix bugs, explain the image, improve the writing, clean up code):").pack(anchor="w",pady=(6,3))
    instruction=tk.Entry(outer);instruction.pack(fill="x");instruction.insert(0,"Inspect this file, explain problems, and improve it while preserving intended features.")
    panes=ttk.Panedwindow(outer,orient="vertical");panes.pack(fill="both",expand=True,pady=8)
    a=ttk.Frame(panes);b=ttk.Frame(panes);panes.add(a,weight=1);panes.add(b,weight=2)
    ttk.Label(a,text="Extracted content / scan result").pack(anchor="w");preview=tk.Text(a,wrap="word",height=8);preview.pack(fill="both",expand=True)
    ttk.Label(b,text="AI review / improved result").pack(anchor="w");result=tk.Text(b,wrap="word",undo=True);result.pack(fill="both",expand=True)
    cache={"text":"","path":""}
    def extract_file(f):
     ext=Path(f).suffix.lower()
     if ext==".docx":
      with zipfile.ZipFile(f) as z:
       root=ET.fromstring(z.read("word/document.xml"));return "\n".join((x.text or "") for x in root.iter() if x.tag.endswith("}t"))
     if ext==".pdf":
      try:
       cp=subprocess.run(["pdftotext",f,"-"],capture_output=True,text=True,timeout=30,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
       if cp.returncode==0 and cp.stdout.strip():return cp.stdout
      except Exception:pass
      return "PDF text could not be extracted. Install Poppler pdftotext, or convert the PDF to text first."
     if ext in (".png",".jpg",".jpeg",".bmp",".webp"):
      try:
       cp=subprocess.run(["tesseract",f,"stdout"],capture_output=True,text=True,timeout=60,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
       if cp.returncode==0 and cp.stdout.strip():return "OCR text extracted from image (not full visual understanding):\n"+cp.stdout
      except Exception:pass
      return "Image selected: "+Path(f).name+"\nNo OCR text extracted. Install Tesseract OCR for text extraction. To interpret the whole picture, a compatible vision-language model is needed; this app currently has no bundled vision model. You can still use Improve image below with a local Stable Diffusion API."
     try:return Path(f).read_text(encoding="utf-8",errors="replace")[:40000]
     except Exception as e:return "Could not read file as text: "+str(e)
    def scan():
     f=path_var.get().strip()
     if not f or not Path(f).is_file():messagebox.showinfo(APP_NAME,"Choose a file first.",parent=win);return
     preview.delete("1.0","end");preview.insert("1.0","Scanning file…")
     def work():return extract_file(f)
     def done(text):cache["text"]=text;cache["path"]=f;preview.delete("1.0","end");preview.insert("1.0",text);status.set("Scan complete. Review extracted text before asking for improvements.")
     self.run_bg(work,done)
    def improve():
     content=cache.get("text","")
     if not content:messagebox.showinfo(APP_NAME,"Scan a file first.",parent=win);return
     if not self.settings.get("llama_cli_path") or not self.settings.get("model_path"):
      messagebox.showwarning(APP_NAME,"Improvement needs a configured local GGUF model in Settings. The app does not include a language model.",parent=win);return
     request_text=instruction.get().strip() or "Review and improve this file."
     prompt=("You are MINI AI LITE X, a careful file-review assistant. Follow the user's requested improvement. Preserve intended behavior and important details. For code, return the complete improved file first, followed by a clearly separated short change summary. For ordinary text, provide the improved version and summarize changes. For OCR text, mention uncertainty from recognition errors. Do not claim you ran tests.\nUser request: "+request_text+"\nFile: "+Path(cache.get("path","")).name+"\nCONTENT START\n"+content[:30000]+"\nCONTENT END")
     status.set("Reviewing and improving with the configured local model…")
     def work():
      r=local_model(prompt,self.settings)
      if not r:raise RuntimeError("No answer returned. Check the configured local model and llama.cpp paths.")
      return r
     def done(r):result.delete("1.0","end");result.insert("1.0",r);status.set("Review ready. Check the result before using it.")
     self.run_bg(work,done)
    def save_result():
     text=result.get("1.0","end-1c")
     if not text.strip():messagebox.showinfo(APP_NAME,"There is no improved result to save yet.",parent=win);return
     original=Path(path_var.get()).name if path_var.get() else "improved"
     f=filedialog.asksaveasfilename(parent=win,title="Save improved file",initialfile="improved_"+original,defaultextension=".txt",filetypes=[("All files","*.*"),("Text files","*.txt"),("Python","*.py"),("Arduino sketch","*.ino"),("Markdown","*.md")])
     if f:
      try:Path(f).write_text(text,encoding="utf-8");status.set("Saved improved result: "+f)
      except Exception as e:messagebox.showerror(APP_NAME,"Could not save result: "+str(e),parent=win)
    def improve_image():
     f=path_var.get().strip()
     if not f or Path(f).suffix.lower() not in (".png",".jpg",".jpeg",".bmp",".webp"):
      messagebox.showinfo(APP_NAME,"Choose an image file first.",parent=win);return
     api=simpledialog.askstring(APP_NAME,"Local Stable Diffusion / Forge API URL:",initialvalue="http://127.0.0.1:7860",parent=win)
     if not api:return
     prompt_text=simpledialog.askstring(APP_NAME,"How should the image be changed?",initialvalue="Improve clarity and detail while preserving the main subject",parent=win)
     if not prompt_text:return
     status.set("Sending image to the local image model for editing…")
     def work():
      raw=Path(f).read_bytes();encoded=base64.b64encode(raw).decode("ascii")
      payload={"init_images":[encoded],"prompt":prompt_text,"denoising_strength":0.45,"steps":12,"width":512,"height":512,"batch_size":1}
      req=urllib.request.Request(api.rstrip("/")+"/sdapi/v1/img2img",data=json.dumps(payload).encode(),headers={"Content-Type":"application/json"},method="POST")
      with urllib.request.urlopen(req,timeout=600) as r:data=json.loads(r.read(80000000).decode("utf-8"))
      if not data.get("images"):raise RuntimeError("Image API returned no edited image.")
      folder=APP_DIR/"generated_media";folder.mkdir(parents=True,exist_ok=True);dest=folder/("improved_"+time.strftime("%Y%m%d_%H%M%S")+".png");dest.write_bytes(base64.b64decode(data["images"][0].split(",",1)[-1]));return str(dest)
     def done(dest):status.set("Edited image saved: "+dest);messagebox.showinfo(APP_NAME,"Edited image saved to:\n"+dest,parent=win)
     self.run_bg(work,done)
    status=tk.StringVar(value="Choose a file to begin. Results are saved only when you choose Save.")
    bar=ttk.Frame(outer);bar.pack(fill="x")
    ttk.Button(bar,text="Scan file",command=scan).pack(side="left",padx=(0,5))
    ttk.Button(bar,text="Improve with AI",command=improve).pack(side="left",padx=5)
    ttk.Button(bar,text="Improve image…",command=improve_image).pack(side="left",padx=5)
    ttk.Button(bar,text="Save improved result…",command=save_result).pack(side="right")
    ttk.Label(outer,textvariable=status,wraplength=850).pack(anchor="w",pady=(6,0))
 def media_studio(self):
    win=tk.Toplevel(self.root);win.title("MINI AI LITE X — Offline Media Studio");win.geometry("780x680");win.minsize(650,560);win.transient(self.root)
    outer=ttk.Frame(win,padding=14);outer.pack(fill="both",expand=True)
    ttk.Label(outer,text="Offline Media Studio",font=("Segoe UI",15,"bold")).pack(anchor="w")
    ttk.Label(outer,text="Generate images with a local Stable Diffusion WebUI API. Make a video slideshow from images using FFmpeg. Model files must already be installed; no cloud service is used.",wraplength=720).pack(anchor="w",pady=(5,12))
    ttk.Label(outer,text="Local image-generation API URL (Automatic1111 / Forge)").pack(anchor="w")
    api=tk.StringVar(value="http://127.0.0.1:7860")
    ttk.Entry(outer,textvariable=api).pack(fill="x",pady=(3,8))
    ttk.Label(outer,text="Image prompt").pack(anchor="w")
    prompt=tk.Text(outer,height=4,wrap="word");prompt.pack(fill="x",pady=(3,8));prompt.insert("1.0","A peaceful futuristic garden, detailed digital art")
    ttk.Label(outer,text="Output folder").pack(anchor="w")
    out=tk.StringVar(value=str(APP_DIR/"generated_media"))
    line=ttk.Frame(outer);line.pack(fill="x",pady=(3,8));ttk.Entry(line,textvariable=out).pack(side="left",fill="x",expand=True);ttk.Button(line,text="Browse…",command=lambda:out.set(filedialog.askdirectory(parent=win) or out.get())).pack(side="left",padx=(6,0))
    status=tk.StringVar(value="Ready. Start your local image-generation server first.")
    log=tk.Text(outer,height=10,wrap="word",state="disabled");log.pack(fill="both",expand=True,pady=(8,8))
    def report(msg):
     log.configure(state="normal");log.insert("end",msg+"\n");log.see("end");log.configure(state="disabled");status.set(msg[:180])
    def image_worker(text,base):
     try:
      base=base.rstrip("/");endpoint=base+"/sdapi/v1/txt2img"
      payload={"prompt":text,"steps":12,"width":512,"height":512,"batch_size":1,"n_iter":1}
      req=urllib.request.Request(endpoint,data=json.dumps(payload).encode(),headers={"Content-Type":"application/json"},method="POST")
      with urllib.request.urlopen(req,timeout=600) as r:data=json.loads(r.read(80_000_000).decode("utf-8"))
      imgs=data.get("images",[])
      if not imgs:raise RuntimeError("The local image server returned no images.")
      folder=Path(out.get()).expanduser();folder.mkdir(parents=True,exist_ok=True)
      name="mini_ai_image_"+time.strftime("%Y%m%d_%H%M%S")+".png"
      raw=imgs[0].split(",",1)[-1];dest=folder/name;dest.write_bytes(base64.b64decode(raw))
      self.root.after(0,lambda:report("Image saved: "+str(dest)))
      self.root.after(0,lambda:messagebox.showinfo(APP_NAME,"Image generated offline and saved to:\n"+str(dest),parent=win))
     except Exception as e:self.root.after(0,lambda err=str(e):report("Image generation failed: "+err+". Check that the local API server is running and API access is enabled."))
    def generate_image():
     text=prompt.get("1.0","end").strip()
     if not text:messagebox.showwarning(APP_NAME,"Enter an image prompt.",parent=win);return
     report("Sending prompt to local image model…")
     threading.Thread(target=image_worker,args=(text,api.get().strip()),daemon=True).start()
    def make_ai_video():
     idea=simpledialog.askstring(APP_NAME,"Describe the video you want (the app creates AI-generated scene images and combines them into an MP4 slideshow, not true moving AI video):",parent=win)
     if not idea:return
     ff=filedialog.askopenfilename(parent=win,title="Choose ffmpeg.exe",filetypes=[("FFmpeg executable","ffmpeg.exe"),("All files","*.*")])
     if not ff:return
     base=api.get().strip().rstrip("/")
     folder=Path(out.get()).expanduser()
     def worker():
      folder.mkdir(parents=True,exist_ok=True);frames=[]
      scenes=["wide establishing shot","closer view with new camera angle","dynamic action moment","beautiful final closing shot"]
      for i,scene in enumerate(scenes,1):
       prompt_text=idea+", "+scene+", cinematic composition, consistent visual style, frame "+str(i)+" of 4"
       req=urllib.request.Request(base+"/sdapi/v1/txt2img",data=json.dumps({"prompt":prompt_text,"steps":12,"width":512,"height":512,"batch_size":1}).encode(),headers={"Content-Type":"application/json"},method="POST")
       with urllib.request.urlopen(req,timeout=600) as r:data=json.loads(r.read(80000000).decode("utf-8"))
       if not data.get("images"):raise RuntimeError("The image model returned no frame "+str(i))
       fp=folder/("ai_video_frame_"+time.strftime("%Y%m%d_%H%M%S")+"_"+str(i)+".png");fp.write_bytes(base64.b64decode(data["images"][0].split(",",1)[-1]));frames.append(fp)
       self.root.after(0,lambda n=i:report("AI video: generated scene image "+str(n)+" of 4…"))
      dest=folder/("mini_ai_video_"+time.strftime("%Y%m%d_%H%M%S")+".mp4")
      listing=folder/"_mini_ai_generated_video_list.txt"
      lines=[]
      for fp in frames:lines.append("file '"+str(fp.resolve()).replace("'","'\\''")+"'\nduration 2.5")
      lines.append("file '"+str(frames[-1].resolve()).replace("'","'\\''")+"'");listing.write_text("\n".join(lines),encoding="utf-8")
      cp=subprocess.run([ff,"-y","-f","concat","-safe","0","-i",str(listing),"-vf","scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p","-r","24","-pix_fmt","yuv420p",str(dest)],capture_output=True,text=True,timeout=600,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
      if cp.returncode:raise RuntimeError((cp.stderr or "FFmpeg failed")[-1500:])
      return str(dest)
     def done(dest):report("AI-generated scene slideshow saved: "+dest);messagebox.showinfo(APP_NAME,"Video saved to:\n"+dest+"\n\nThis is a slideshow of AI-generated scene images, not generated continuous motion.",parent=win)
     report("Generating four AI scene images; this can take a long time…")
     self.run_bg(worker,done)
    def make_video():
     ff= filedialog.askopenfilename(parent=win,title="Choose ffmpeg.exe",filetypes=[("FFmpeg executable","ffmpeg.exe"),("All files","*.*")])
     if not ff:return
     files=filedialog.askopenfilenames(parent=win,title="Choose images in video order",filetypes=[("Image files","*.png *.jpg *.jpeg *.bmp *.webp"),("All files","*.*")])
     if not files:return
     try:
      folder=Path(out.get()).expanduser();folder.mkdir(parents=True,exist_ok=True)
      dest=folder/("mini_ai_video_"+time.strftime("%Y%m%d_%H%M%S")+".mp4")
      # ffmpeg concat demuxer accepts quoted absolute paths; escape single quotes.
      listing=folder/"_mini_ai_video_list.txt"
      lines=[]
      for f in files:lines.append("file '"+str(Path(f).resolve()).replace("'","'\\''")+"'\nduration 3")
      lines.append("file '"+str(Path(files[-1]).resolve()).replace("'","'\\''")+"'")
      listing.write_text("\n".join(lines),encoding="utf-8")
      report("Creating a 3-second-per-image slideshow video…")
      def video_worker():
       try:
        p=subprocess.run([ff,"-y","-f","concat","-safe","0","-i",str(listing),"-vf","scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p","-r","24","-pix_fmt","yuv420p",str(dest)],capture_output=True,text=True,timeout=600,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        if p.returncode:raise RuntimeError((p.stderr or "FFmpeg failed")[-1800:])
        self.root.after(0,lambda:report("Video saved: "+str(dest)))
       except Exception as e:self.root.after(0,lambda err=str(e):report("Video creation failed: "+err))
      threading.Thread(target=video_worker,daemon=True).start()
     except Exception as e:report("Could not prepare video: "+str(e))
    def start_local_engine():
     launcher=Path(__file__).resolve().parent/"Start_Local_Image_Engine.bat"
     if not launcher.exists():
      messagebox.showerror(APP_NAME,"Local image-engine launcher was not found. Re-extract the complete MINI AI LITE X ZIP.",parent=win);return
     try:
      if os.name=="nt":os.startfile(str(launcher))
      else:subprocess.Popen([str(launcher)])
      report("Opened local CPU image-engine window. Keep it open; first launch downloads model files.")
     except Exception as e:messagebox.showerror(APP_NAME,"Could not start local image engine: "+str(e),parent=win)
    def check_local_engine():
     def work():
      req=urllib.request.Request(api.get().rstrip("/")+"/health",headers={"Accept":"application/json"})
      with urllib.request.urlopen(req,timeout=5) as r:return json.loads(r.read(100000).decode("utf-8"))
     def done(data):report("Engine reachable. Model: "+str(data.get("model"))+" · loaded: "+str(data.get("loaded")))
     self.run_bg(work,done)
    buttons=ttk.Frame(outer);buttons.pack(fill="x",pady=5)
    ttk.Button(buttons,text="Start local CPU engine",command=start_local_engine).pack(side="left")
    ttk.Button(buttons,text="Check engine",command=check_local_engine).pack(side="left",padx=5)
    ttk.Button(buttons,text="Generate image offline",command=generate_image).pack(side="left",padx=5)
    ttk.Button(buttons,text="AI video from prompt…",command=make_ai_video).pack(side="left",padx=8)
    ttk.Button(buttons,text="Create video from images…",command=make_video).pack(side="left",padx=8)
    ttk.Button(buttons,text="Open output folder",command=lambda:(Path(out.get()).mkdir(parents=True,exist_ok=True),os.startfile(str(Path(out.get()).resolve())) if os.name=="nt" else webbrowser.open(Path(out.get()).resolve().as_uri()))).pack(side="right")
    ttk.Label(outer,textvariable=status,wraplength=720).pack(anchor="w",pady=(6,0))
    report("For local generation, run INSTALL_LOCAL_IMAGE_ENGINE.bat once, then Start_Local_Image_Engine.bat; its CPU API uses port 7860. Alternatively, use a compatible Stable Diffusion WebUI/Forge server. Video creation needs ffmpeg.exe. The AI video option generates several images locally from your prompt and combines them into a slideshow; it is not continuous AI-generated motion. True text-to-video generation needs a separate compatible video model, which is not bundled and is unlikely to run well on a 4 GB laptop.")
 def open_source(self):
    hits=retrieve(self.entry.get().strip(),1)
    if hits:webbrowser.open(hits[0][2],new=2);return
    messagebox.showinfo(APP_NAME,"Ask a question related to saved knowledge, or open Saved knowledge and select a page.",parent=self.root)
 def settings_dialog(self):
    win=tk.Toplevel(self.root);win.title("Settings");win.geometry("760x650");win.minsize(700,600);win.transient(self.root)
    fields=[("Total app storage limit GB (max 200)","storage_limit_gb"),("Saved chat limit GB (max 50)","chat_storage_limit_gb"),("Pages per research run (1–8)","max_pages_per_run"),("Research interval hours","research_interval_hours"),("Request timeout seconds","request_timeout_seconds"),("Maximum text characters per page","max_chars_per_page"),("Startup research topic","startup_topic"),("llama.cpp executable path (optional)","llama_cli_path"),("GGUF model file path (optional)","model_path")]
    vars={}
    for i,(label,key) in enumerate(fields):ttk.Label(win,text=label).grid(row=i,column=0,sticky="w",padx=10,pady=5);v=tk.StringVar(value=str(self.settings.get(key,"")));vars[key]=v;ttk.Entry(win,textvariable=v,width=48).grid(row=i,column=1,sticky="ew",padx=10,pady=5)
    auto=tk.BooleanVar(value=bool(self.settings.get("auto_learning_enabled",True)));startup=tk.BooleanVar(value=bool(self.settings.get("research_on_startup",True)));openmanual=tk.BooleanVar(value=bool(self.settings.get("open_manual_urls",True)));openresearch=tk.BooleanVar(value=bool(self.settings.get("open_research_pages",False)))
    ttk.Checkbutton(win,text="Automatic scheduled learning",variable=auto).grid(row=9,column=0,columnspan=2,sticky="w",padx=10,pady=3)
    ttk.Checkbutton(win,text="Research on startup",variable=startup).grid(row=10,column=0,columnspan=2,sticky="w",padx=10,pady=3)
    ttk.Checkbutton(win,text="Open Learn URL links in my browser",variable=openmanual).grid(row=11,column=0,columnspan=2,sticky="w",padx=10,pady=3)
    ttk.Checkbutton(win,text="Open every manually researched result in browser (can open several tabs)",variable=openresearch).grid(row=12,column=0,columnspan=2,sticky="w",padx=10,pady=3)
    def save():
     try:
      for _,key in fields:
       if key in ("storage_limit_gb","chat_storage_limit_gb","max_pages_per_run","research_interval_hours","request_timeout_seconds","max_chars_per_page"):self.settings[key]=int(vars[key].get())
       else:self.settings[key]=vars[key].get().strip()
      self.settings.update(auto_learning_enabled=auto.get(),research_on_startup=startup.get(),open_manual_urls=openmanual.get(),open_research_pages=openresearch.get());save_settings(self.settings);self.settings=load_settings();self.apply_mode();self.update_auto_button();self.status.configure(text="Settings saved");win.destroy()
     except Exception as e:messagebox.showerror(APP_NAME,"Could not save settings: "+str(e),parent=win)
    ttk.Button(win,text="Save settings",command=save).grid(row=13,column=1,sticky="e",padx=10,pady=12)
 def refresh_stats(self):
    try:
     with sqlite3.connect(DB_PATH) as c:n=c.execute("SELECT COUNT(*) FROM pages").fetchone()[0]
     used=app_storage_bytes();cap=max(1,int(self.settings.get("storage_limit_gb",200)))*(1024**3)
     if used >= 1024**3: used_text=f"{used/(1024**3):.2f} GB"
     else: used_text=f"{used/(1024**2):.1f} MB"
     self.stats.configure(text=f"Knowledge: {n} pages · Storage {used_text} / {self.settings.get('storage_limit_gb',200)} GB")
    except Exception:pass
 def close(self):self.stop_event.set();self.root.destroy()

def main():
    root=tk.Tk();App(root);root.mainloop()


# Embedded first-run local AI installer. This keeps the project in one Python file.
import base64 as _mini_base64, sys as _mini_sys
_MINI_AI_SETUP_B64 = """IiIiT25lLWNsaWNrIGZpcnN0LXJ1biBpbnN0YWxsZXIgZm9yIE1JTkkgQUkgTElURSBYIGxvY2FsIExMTSAoUHl0aG9uIHN0ZGxpYiBvbmx5KS4iIiIKaW1wb3J0IG9zLCBzeXMsIGpzb24sIHVybGxpYi5yZXF1ZXN0LCB1cmxsaWIuZXJyb3IsIHppcGZpbGUsIHRhcmZpbGUsIHNodXRpbCwgdGVtcGZpbGUKZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCgpBUFBfRElSID0gUGF0aChvcy5lbnZpcm9uLmdldCgnTE9DQUxBUFBEQVRBJywgc3RyKFBhdGguaG9tZSgpKSkpIC8gJ01pbmlBSUxpdGVYJwpSVU5USU1FX0RJUiA9IEFQUF9ESVIgLyAncnVudGltZScKTU9ERUxfRElSID0gQVBQX0RJUiAvICdtb2RlbHMnClNFVFRJTkdTID0gQVBQX0RJUiAvICdzZXR0aW5ncy5qc29uJwpNT0RFTF9OQU1FID0gJ3F3ZW4yLjUtMC41Yi1pbnN0cnVjdC1xNF9rX20uZ2d1ZicKTU9ERUxfVVJMID0gJ2h0dHBzOi8vaHVnZ2luZ2ZhY2UuY28vUXdlbi9Rd2VuMi41LTAuNUItSW5zdHJ1Y3QtR0dVRi9yZXNvbHZlL21haW4vJyArIE1PREVMX05BTUUKVUEgPSAnTUlOSS1BSS1MSVRFLVgtbG9jYWwtaW5zdGFsbGVyLzMuMCcKR0lUSFVCX0FQSSA9ICdodHRwczovL2FwaS5naXRodWIuY29tL3JlcG9zL2dnbWwtb3JnL2xsYW1hLmNwcCcKCmRlZiBzYXkocyk6IHByaW50KHMsIGZsdXNoPVRydWUpCgpkZWYgZ2V0X2pzb24odXJsKToKICAgIHJlcSA9IHVybGxpYi5yZXF1ZXN0LlJlcXVlc3QodXJsLCBoZWFkZXJzPXsnVXNlci1BZ2VudCc6IFVBLCAnQWNjZXB0JzogJ2FwcGxpY2F0aW9uL3ZuZC5naXRodWIranNvbid9KQogICAgd2l0aCB1cmxsaWIucmVxdWVzdC51cmxvcGVuKHJlcSwgdGltZW91dD00NSkgYXMgcjoKICAgICAgICByZXR1cm4ganNvbi5sb2FkKHIpCgpkZWYgZG93bmxvYWQodXJsLCB0YXJnZXQsIGxhYmVsKToKICAgIHRhcmdldC5wYXJlbnQubWtkaXIocGFyZW50cz1UcnVlLCBleGlzdF9vaz1UcnVlKQogICAgcmVxID0gdXJsbGliLnJlcXVlc3QuUmVxdWVzdCh1cmwsIGhlYWRlcnM9eydVc2VyLUFnZW50JzogVUF9KQogICAgd2l0aCB1cmxsaWIucmVxdWVzdC51cmxvcGVuKHJlcSwgdGltZW91dD05MCkgYXMgciwgb3Blbih0YXJnZXQsICd3YicpIGFzIGY6CiAgICAgICAgdG90YWwgPSBpbnQoci5oZWFkZXJzLmdldCgnQ29udGVudC1MZW5ndGgnLCAnMCcpIG9yIDApOyBnb3QgPSAwCiAgICAgICAgd2hpbGUgVHJ1ZToKICAgICAgICAgICAgYiA9IHIucmVhZCgxMDI0ICogNTEyKQogICAgICAgICAgICBpZiBub3QgYjogYnJlYWsKICAgICAgICAgICAgZi53cml0ZShiKTsgZ290ICs9IGxlbihiKQogICAgICAgICAgICBpZiB0b3RhbDogcHJpbnQoJ1xyJXM6ICUuMWYgLyAlLjFmIE1CJyAlIChsYWJlbCwgZ290IC8gMTA0ODU3NiwgdG90YWwgLyAxMDQ4NTc2KSwgZW5kPScnLCBmbHVzaD1UcnVlKQogICAgICAgICAgICBlbHNlOiBwcmludCgnXHIlczogJS4xZiBNQicgJSAobGFiZWwsIGdvdCAvIDEwNDg1NzYpLCBlbmQ9JycsIGZsdXNoPVRydWUpCiAgICBwcmludCgnJywgZmx1c2g9VHJ1ZSkKCmRlZiBmaW5kX2NsaShyb290KToKICAgIGlmIG5vdCByb290LmV4aXN0cygpOiByZXR1cm4gTm9uZQogICAgaGl0cyA9IGxpc3Qocm9vdC5yZ2xvYignbGxhbWEtY2xpLmV4ZScpKQogICAgaWYgaGl0czogcmV0dXJuIGhpdHNbMF0KICAgICMgT2xkZXIgbGxhbWEuY3BwIFdpbmRvd3MgcGFja2FnZXMgbWF5IGNhbGwgdGhlIGV4ZWN1dGFibGUgbWFpbi5leGUuCiAgICBoaXRzID0gbGlzdChyb290LnJnbG9iKCdtYWluLmV4ZScpKQogICAgcmV0dXJuIGhpdHNbMF0gaWYgaGl0cyBlbHNlIE5vbmUKCmRlZiBzYWZlX2V4dHJhY3QoYXJjaGl2ZSwgZGVzdCk6CiAgICBkZXN0Lm1rZGlyKHBhcmVudHM9VHJ1ZSwgZXhpc3Rfb2s9VHJ1ZSk7IGJhc2UgPSBkZXN0LnJlc29sdmUoKQogICAgaWYgemlwZmlsZS5pc196aXBmaWxlKGFyY2hpdmUpOgogICAgICAgIHdpdGggemlwZmlsZS5aaXBGaWxlKGFyY2hpdmUpIGFzIHo6CiAgICAgICAgICAgIGZvciBpdGVtIGluIHouaW5mb2xpc3QoKToKICAgICAgICAgICAgICAgIHRhcmdldCA9IChkZXN0IC8gaXRlbS5maWxlbmFtZSkucmVzb2x2ZSgpCiAgICAgICAgICAgICAgICBpZiB0YXJnZXQgIT0gYmFzZSBhbmQgYmFzZSBub3QgaW4gdGFyZ2V0LnBhcmVudHM6CiAgICAgICAgICAgICAgICAgICAgcmFpc2UgUnVudGltZUVycm9yKCdVbnNhZmUgcGF0aCBpbiBydW50aW1lIGFyY2hpdmU7IGV4dHJhY3Rpb24gc3RvcHBlZC4nKQogICAgICAgICAgICB6LmV4dHJhY3RhbGwoZGVzdCkKICAgIGVsaWYgdGFyZmlsZS5pc190YXJmaWxlKGFyY2hpdmUpOgogICAgICAgIHdpdGggdGFyZmlsZS5vcGVuKGFyY2hpdmUsICdyOionKSBhcyB0OgogICAgICAgICAgICBmb3IgaXRlbSBpbiB0LmdldG1lbWJlcnMoKToKICAgICAgICAgICAgICAgIHRhcmdldCA9IChkZXN0IC8gaXRlbS5uYW1lKS5yZXNvbHZlKCkKICAgICAgICAgICAgICAgIGlmIHRhcmdldCAhPSBiYXNlIGFuZCBiYXNlIG5vdCBpbiB0YXJnZXQucGFyZW50czoKICAgICAgICAgICAgICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoJ1Vuc2FmZSBwYXRoIGluIHJ1bnRpbWUgYXJjaGl2ZTsgZXh0cmFjdGlvbiBzdG9wcGVkLicpCiAgICAgICAgICAgICAgICBpZiBpdGVtLmlzc3ltKCkgb3IgaXRlbS5pc2xuaygpOgogICAgICAgICAgICAgICAgICAgIHJhaXNlIFJ1bnRpbWVFcnJvcignUnVudGltZSBhcmNoaXZlIGNvbnRhaW5zIGEgbGluazsgcmVmdXNpbmcgdW5zYWZlIGV4dHJhY3Rpb24uJykKICAgICAgICAgICAgIyBQeXRob24gMy44IGRvZXMgbm90IHN1cHBvcnQgdGhlIG5ld2VyIGZpbHRlciBhcmd1bWVudC4KICAgICAgICAgICAgdHJ5OiB0LmV4dHJhY3RhbGwoZGVzdCwgZmlsdGVyPSdkYXRhJykKICAgICAgICAgICAgZXhjZXB0IFR5cGVFcnJvcjogdC5leHRyYWN0YWxsKGRlc3QpCiAgICBlbHNlOgogICAgICAgIHJhaXNlIFJ1bnRpbWVFcnJvcignRG93bmxvYWRlZCBydW50aW1lIGlzIG5vdCBhIFpJUCBvciBUQVIgYXJjaGl2ZS4gVGhpcyByZWxlYXNlIG1heSBvbmx5IG9mZmVyIGEgN3ogcGFja2FnZS4nKQoKZGVmIGFsbF9yZWxlYXNlcygpOgogICAgIiIiTGF0ZXN0IGNhbiBiZSBhIG5pZ2h0bHkgbWFya2VyLW9ubHkgcmVsZWFzZTsgc2NhbiB2ZXJzaW9uZWQgcmVsZWFzZSBoaXN0b3J5IHRvby4iIiIKICAgIGZvdW5kID0gW10KICAgIGVycm9ycyA9IFtdCiAgICB1cmxzID0gW0dJVEhVQl9BUEkgKyAnL3JlbGVhc2VzL2xhdGVzdCddICsgW0dJVEhVQl9BUEkgKyAnL3JlbGVhc2VzP3Blcl9wYWdlPTMwJnBhZ2U9JyArIHN0cihwKSBmb3IgcCBpbiByYW5nZSgxLCA0KV0KICAgIHNlZW4gPSBzZXQoKQogICAgZm9yIHVybCBpbiB1cmxzOgogICAgICAgIHRyeToKICAgICAgICAgICAgZGF0YSA9IGdldF9qc29uKHVybCkKICAgICAgICAgICAgZW50cmllcyA9IGRhdGEgaWYgaXNpbnN0YW5jZShkYXRhLCBsaXN0KSBlbHNlIFtkYXRhXQogICAgICAgICAgICBmb3IgcmVsIGluIGVudHJpZXM6CiAgICAgICAgICAgICAgICBpZiBub3QgaXNpbnN0YW5jZShyZWwsIGRpY3QpOiBjb250aW51ZQogICAgICAgICAgICAgICAgdGFnID0gc3RyKHJlbC5nZXQoJ3RhZ19uYW1lJykgb3IgcmVsLmdldCgnbmFtZScpIG9yICcnKQogICAgICAgICAgICAgICAgaWYgdGFnIGluIHNlZW46IGNvbnRpbnVlCiAgICAgICAgICAgICAgICBzZWVuLmFkZCh0YWcpOyBmb3VuZC5hcHBlbmQocmVsKQogICAgICAgIGV4Y2VwdCBFeGNlcHRpb24gYXMgZToKICAgICAgICAgICAgZXJyb3JzLmFwcGVuZCh1cmwucnNwbGl0KCcvJywgMSlbLTFdICsgJzogJyArIHN0cihlKSkKICAgIGlmIG5vdCBmb3VuZDoKICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoJ0NvdWxkIG5vdCByZWFkIGxsYW1hLmNwcCByZWxlYXNlIGluZm9ybWF0aW9uIGZyb20gR2l0SHViLiAnICsgJyB8ICcuam9pbihlcnJvcnNbOjNdKSkKICAgIHJldHVybiBmb3VuZCwgZXJyb3JzCgpkZWYgZ2V0X3J1bnRpbWUoKToKICAgIGV4aXN0aW5nID0gZmluZF9jbGkoUlVOVElNRV9ESVIpCiAgICBpZiBleGlzdGluZzogcmV0dXJuIGV4aXN0aW5nCiAgICBzYXkoJ0NoZWNraW5nIGxsYW1hLmNwcCByZWxlYXNlIGhpc3RvcnkgKHRoZSBsYXRlc3QgbmlnaHRseSBtYXkgY29udGFpbiBubyBXaW5kb3dzIGZpbGVzKS4uLicpCiAgICByZWxlYXNlcywgYXBpX2Vycm9ycyA9IGFsbF9yZWxlYXNlcygpCiAgICBjYW5kaWRhdGVzID0gW10KICAgIHZpc2libGUgPSBbXQogICAgZm9yIHJlbCBpbiByZWxlYXNlczoKICAgICAgICBmb3IgYXNzZXQgaW4gcmVsLmdldCgnYXNzZXRzJywgW10pIG9yIFtdOgogICAgICAgICAgICBubSA9IHN0cihhc3NldC5nZXQoJ25hbWUnLCAnJykpCiAgICAgICAgICAgIGxvdyA9IG5tLmxvd2VyKCkKICAgICAgICAgICAgaWYgbGVuKHZpc2libGUpIDwgMzU6IHZpc2libGUuYXBwZW5kKG5tKQogICAgICAgICAgICBpZiBub3QgbG93LmVuZHN3aXRoKCgnLnppcCcsICcudGFyLmd6JywgJy50Z3onKSk6IGNvbnRpbnVlCiAgICAgICAgICAgIGlmIG5vdCBhbnkoeCBpbiBsb3cgZm9yIHggaW4gKCd3aW4nLCAnd2luZG93cycpKTogY29udGludWUKICAgICAgICAgICAgaWYgYW55KHggaW4gbG93IGZvciB4IGluICgnYXJtNjQnLCAnYWFyY2g2NCcsICdjdWRhJywgJ3N5Y2wnLCAndnVsa2FuJykpOiBjb250aW51ZQogICAgICAgICAgICBjYW5kaWRhdGVzLmFwcGVuZCgocmVsLCBhc3NldCkpCiAgICBkZWYgc2NvcmUocGFpcik6CiAgICAgICAgcmVsLCBhc3NldCA9IHBhaXI7IG4gPSBzdHIoYXNzZXQuZ2V0KCduYW1lJywgJycpKS5sb3dlcigpCiAgICAgICAgIyBDZW50cmlubyAyLWVyYSBDUFVzIGdlbmVyYWxseSBsYWNrIEFWWDsgcHJlZmVyIG5vLUFWWC9TU0UgcGFja2FnZXMgaWYgcHVibGlzaGVkLgogICAgICAgIHJldHVybiAoMCBpZiAoJ25vYXZ4JyBpbiBuIG9yICduby1hdngnIGluIG4gb3IgJ3NzZScgaW4gbikgZWxzZQogICAgICAgICAgICAgICAgMSBpZiAoJ2F2eCcgbm90IGluIG4gb3IgJ2F2eDEnIGluIG4pIGVsc2UgMywKICAgICAgICAgICAgICAgIDAgaWYgKCd4NjQnIGluIG4gb3IgJ2FtZDY0JyBpbiBuIG9yICd3aW42NCcgaW4gbikgZWxzZSAxLAogICAgICAgICAgICAgICAgMCBpZiBuLmVuZHN3aXRoKCcuemlwJykgZWxzZSAxLAogICAgICAgICAgICAgICAgMCBpZiBub3QgcmVsLmdldCgncHJlcmVsZWFzZScsIEZhbHNlKSBlbHNlIDEpCiAgICBjYW5kaWRhdGVzLnNvcnQoa2V5PXNjb3JlKQogICAgaWYgbm90IGNhbmRpZGF0ZXM6CiAgICAgICAgZXh0cmEgPSAnLCAnLmpvaW4odmlzaWJsZSkgb3IgJyhubyBhcmNoaXZlIGFzc2V0cyByZXR1cm5lZCknCiAgICAgICAgaWYgYXBpX2Vycm9yczogZXh0cmEgKz0gJyB8IEFQSSBub3RlczogJyArICcgOyAnLmpvaW4oYXBpX2Vycm9yc1s6Ml0pCiAgICAgICAgcmFpc2UgUnVudGltZUVycm9yKCdObyBXaW5kb3dzIFpJUC9UQVIgYXJjaGl2ZSB3YXMgZm91bmQgaW4gcmVjZW50IGxsYW1hLmNwcCByZWxlYXNlcy4gQXNzZXRzIHNlZW46ICcgKyBleHRyYSArICcuIFRoZSByZWxlYXNlIEFQSSBtYXkgb25seSBwcm92aWRlIDd6L25pZ2h0bHkgZmlsZXMsIG9yIEdpdEh1YiBtYXkgYmUgYmxvY2tlZC4gVGhpcyBpbnN0YWxsZXIgbmVlZHMgYW4gYXJjaGl2ZSBjb250YWluaW5nIGxsYW1hLWNsaS5leGUuJykKICAgIGVycm9ycyA9IFtdCiAgICBSVU5USU1FX0RJUi5ta2RpcihwYXJlbnRzPVRydWUsIGV4aXN0X29rPVRydWUpCiAgICAjIExpbWl0IGF0dGVtcHRzIHNvIGEgYnJva2VuIGRvd25sb2FkIGRvZXNuJ3Qgd2FzdGUgdGhlIHVzZXIncyB0aW1lLgogICAgZm9yIHJlbCwgYXNzZXQgaW4gY2FuZGlkYXRlc1s6OF06CiAgICAgICAgc2F5KCdUcnlpbmcgJyArIHN0cihyZWwuZ2V0KCd0YWdfbmFtZScsICdyZWxlYXNlJykpICsgJyBhc3NldDogJyArIHN0cihhc3NldC5nZXQoJ25hbWUnLCAnKHVubmFtZWQpJykpKQogICAgICAgIHRyeToKICAgICAgICAgICAgd2l0aCB0ZW1wZmlsZS5UZW1wb3JhcnlEaXJlY3RvcnkocHJlZml4PSdtaW5pYWlfbGxhbWFfJykgYXMgdGQ6CiAgICAgICAgICAgICAgICBhcmNoaXZlID0gUGF0aCh0ZCkgLyBzdHIoYXNzZXQuZ2V0KCduYW1lJywgJ3J1bnRpbWUuemlwJykpCiAgICAgICAgICAgICAgICBkb3dubG9hZChhc3NldFsnYnJvd3Nlcl9kb3dubG9hZF91cmwnXSwgYXJjaGl2ZSwgJ0Rvd25sb2FkaW5nIHJ1bnRpbWUnKQogICAgICAgICAgICAgICAgc2FmZV9leHRyYWN0KGFyY2hpdmUsIFJVTlRJTUVfRElSKQogICAgICAgICAgICBjbGkgPSBmaW5kX2NsaShSVU5USU1FX0RJUikKICAgICAgICAgICAgaWYgY2xpOiByZXR1cm4gY2xpCiAgICAgICAgICAgIGVycm9ycy5hcHBlbmQoc3RyKGFzc2V0LmdldCgnbmFtZScsICc/JykpICsgJzogYXJjaGl2ZSBkaWQgbm90IGNvbnRhaW4gbGxhbWEtY2xpLmV4ZSBvciBtYWluLmV4ZScpCiAgICAgICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBlOgogICAgICAgICAgICBlcnJvcnMuYXBwZW5kKHN0cihhc3NldC5nZXQoJ25hbWUnLCAnPycpKSArICc6ICcgKyBzdHIoZSkpCiAgICByYWlzZSBSdW50aW1lRXJyb3IoJ1RyaWVkIHJlY2VudCBXaW5kb3dzIGFyY2hpdmVzIGJ1dCBub25lIHByb3ZpZGVkIGEgdXNhYmxlIENMSS4gJyArICcgfCAnLmpvaW4oZXJyb3JzWzo1XSkgKyAnLiBZb3VyIG9sZGVyIENQVSBtYXkgbmVlZCBhIGxlZ2FjeSBuby1BVlggYnVpbGQuJykKCmRlZiBtYWluKCk6CiAgICBBUFBfRElSLm1rZGlyKHBhcmVudHM9VHJ1ZSwgZXhpc3Rfb2s9VHJ1ZSk7IE1PREVMX0RJUi5ta2RpcihwYXJlbnRzPVRydWUsIGV4aXN0X29rPVRydWUpCiAgICBtb2RlbCA9IE1PREVMX0RJUiAvIE1PREVMX05BTUUKICAgIHRyeToKICAgICAgICBjbGkgPSBmaW5kX2NsaShSVU5USU1FX0RJUikgb3IgZ2V0X3J1bnRpbWUoKQogICAgICAgIGlmIG5vdCBtb2RlbC5leGlzdHMoKSBvciBtb2RlbC5zdGF0KCkuc3Rfc2l6ZSA8IDEwMF8wMDBfMDAwOgogICAgICAgICAgICBzYXkoJ0Rvd25sb2FkaW5nIFF3ZW4gMi41IDAuNUIgSW5zdHJ1Y3QgcXVhbnRpemVkIEdHVUYgbW9kZWwgKHNldmVyYWwgaHVuZHJlZCBNQikuJykKICAgICAgICAgICAgc2F5KCdLZWVwIHRoaXMgd2luZG93IG9wZW47IGRvIG5vdCB0dXJuIG9mZiB0aGUgY29tcHV0ZXIuJykKICAgICAgICAgICAgcGFydCA9IG1vZGVsLndpdGhfc3VmZml4KCcuZ2d1Zi5wYXJ0JykKICAgICAgICAgICAgdHJ5OgogICAgICAgICAgICAgICAgZG93bmxvYWQoTU9ERUxfVVJMLCBwYXJ0LCAnRG93bmxvYWRpbmcgbW9kZWwnKQogICAgICAgICAgICAgICAgaWYgcGFydC5zdGF0KCkuc3Rfc2l6ZSA8IDEwMF8wMDBfMDAwOgogICAgICAgICAgICAgICAgICAgIHJhaXNlIFJ1bnRpbWVFcnJvcignRG93bmxvYWRlZCBtb2RlbCBpcyB0b28gc21hbGw7IHRoZSBkb3dubG9hZCBtYXkgaGF2ZSByZXR1cm5lZCBhbiBlcnJvciBwYWdlLicpCiAgICAgICAgICAgICAgICBwYXJ0LnJlcGxhY2UobW9kZWwpCiAgICAgICAgICAgIGZpbmFsbHk6CiAgICAgICAgICAgICAgICBpZiBwYXJ0LmV4aXN0cygpOiBwYXJ0LnVubGluaygpCiAgICAgICAgc2V0dGluZ3MgPSB7fQogICAgICAgIGlmIFNFVFRJTkdTLmV4aXN0cygpOgogICAgICAgICAgICB0cnk6IHNldHRpbmdzID0ganNvbi5sb2FkcyhTRVRUSU5HUy5yZWFkX3RleHQoZW5jb2Rpbmc9J3V0Zi04JykpCiAgICAgICAgICAgIGV4Y2VwdCBFeGNlcHRpb246IHBhc3MKICAgICAgICBzZXR0aW5ncy51cGRhdGUoeydsbGFtYV9jbGlfcGF0aCc6IHN0cihjbGkpLCAnbW9kZWxfcGF0aCc6IHN0cihtb2RlbCl9KQogICAgICAgIFNFVFRJTkdTLndyaXRlX3RleHQoanNvbi5kdW1wcyhzZXR0aW5ncywgaW5kZW50PTIpLCBlbmNvZGluZz0ndXRmLTgnKQogICAgICAgIHNheSgnXG5TVUNDRVNTOiBsb2NhbCBMTE0gZmlsZXMgZG93bmxvYWRlZCBhbmQgcGF0aHMgc2F2ZWQuJykKICAgICAgICBzYXkoJ1J1bnRpbWU6ICcgKyBzdHIoY2xpKSk7IHNheSgnTW9kZWw6ICcgKyBzdHIobW9kZWwpKQogICAgICAgIHNheSgnQ2xvc2UgdGhpcyB3aW5kb3cgYW5kIHN0YXJ0IE1JTkkgQUkgTElURSBYIGFnYWluLiBJbml0aWFsIHNldHVwIG5lZWRzIGludGVybmV0OyBpbmZlcmVuY2UgaXMgbG9jYWwgYWZ0ZXJ3YXJkcy4nKQogICAgICAgIHNheSgnV2FybmluZzogNCBHQiBSQU0gYW5kIGFuIG9sZCBDZW50cmlubyAyIENQVSBtYXkgbWFrZSByZXBsaWVzIHZlcnkgc2xvdyBvciBwcmV2ZW50IG1vZGVybiBiaW5hcmllcyBmcm9tIHJ1bm5pbmcuJykKICAgICAgICByZXR1cm4gMAogICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBlOgogICAgICAgIHNheSgnXG5TRVRVUCBGQUlMRUQ6ICcgKyBzdHIoZSkpCiAgICAgICAgc2F5KCdUaGlzIGRpYWdub3N0aWMgaW5zdGFsbGVyIHNjYW5zIHJlY2VudCByZWxlYXNlcywgbm90IGp1c3QgdGhlIG1hcmtlci1vbmx5IGxhdGVzdCBuaWdodGx5LiBDb21wYXRpYmlsaXR5IHN0aWxsIGNhbm5vdCBiZSBndWFyYW50ZWVkIGZvciBXaW5kb3dzIDEwIHZlcnNpb24gMTYwNyBvciBDZW50cmlubyAyLicpCiAgICAgICAgcmV0dXJuIDEKCmlmIF9fbmFtZV9fID09ICdfX21haW5fXyc6IHN5cy5leGl0KG1haW4oKSkK"""
def _mini_run_embedded_setup():
    _source = _mini_base64.b64decode(_MINI_AI_SETUP_B64).decode("utf-8")
    _scope = {"__name__": "__main__", "__file__": __file__}
    exec(compile(_source, __file__ + " [embedded AI installer]", "exec"), _scope, _scope)

if __name__ == "__main__":
    if "--setup-ai" in _mini_sys.argv:
        _mini_run_embedded_setup()
    else:
        main()
