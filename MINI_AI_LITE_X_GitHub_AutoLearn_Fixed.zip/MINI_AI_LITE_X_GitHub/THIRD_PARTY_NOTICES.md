# Third-party notices

The core application source currently uses Python standard-library modules, including Tkinter, SQLite, urllib, and HTML parsing.

The optional local-model setup can download `llama.cpp` runtime files and a GGUF model from external providers. Those components are not bundled in this source repository. Review the applicable licenses, download terms, and model-card requirements for any runtime/model you install. This project is not affiliated with or endorsed by those providers.
