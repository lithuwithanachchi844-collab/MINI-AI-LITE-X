# Contributing

1. Open an issue describing the problem or proposed improvement.
2. Keep changes compatible with Windows and the Python standard library where practical.
3. Do not commit private databases, research files, credentials, model weights, or other large generated assets.
4. Run `py -m py_compile app\mini_ai_lite_x.py` before submitting a change.
5. Clearly state what was tested and what still needs testing on Windows.

For behavior changes, include steps to reproduce and the expected result.
