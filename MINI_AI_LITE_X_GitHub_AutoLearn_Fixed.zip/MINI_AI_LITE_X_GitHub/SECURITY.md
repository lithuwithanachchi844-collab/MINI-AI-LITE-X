# Security policy

Please do not publish sensitive vulnerability details in a public issue. Contact the repository maintainer privately through the contact method configured on the GitHub repository.

This project has not undergone a formal security audit. Treat webpage content and AI-generated output as untrusted. Do not store credentials or sensitive data in research prompts, downloaded pages, or shared database files.
