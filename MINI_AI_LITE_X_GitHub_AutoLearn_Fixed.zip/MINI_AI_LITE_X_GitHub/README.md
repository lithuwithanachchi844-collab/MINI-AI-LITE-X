# MINI AI LITE X

MINI AI LITE X is a lightweight Windows desktop AI chat and personal research assistant built with Python and Tkinter. It can save knowledge from accessible public webpages, search its locally saved knowledge, keep its database on your computer, and optionally use a local GGUF language model through a compatible `llama.cpp` command-line runtime.

> **Important:** This repository contains the application source and launchers. It does not include large model weights or a prebuilt Windows executable. The optional first-run local-AI setup needs an internet connection to download its runtime/model. On older computers, setup may fail or replies may be slow due to CPU/RAM limits. Without a working local model, responses may use the app's simpler built-in retrieval/fallback behavior.

## Features

- Windows desktop interface built with Python's standard-library Tkinter.
- Local SQLite knowledge database and JSON settings.
- Research/import of accessible public webpages when internet access is available.
- Offline access to previously saved local knowledge.
- Optional local GGUF model support through `llama.cpp` CLI.
- File review tools included in the application source.
- Configurable research behavior and storage limits.

Features depend on accessible websites, the selected settings, and whether the optional local model/runtime is installed and compatible.

## Requirements

- Windows 10 or later (older Windows builds may have compatibility issues).
- Python 3.10 or later with Tkinter available. Python 3.13 may work, but is not guaranteed on every Windows installation.
- Internet access for online research and optional local-model setup.
- Optional local model inference requires a compatible `llama.cpp` executable and GGUF model. The included setup workflow attempts to download these; it is not guaranteed to work on every CPU or network.

The project currently uses Python standard-library modules only; `requirements.txt` is intentionally empty.

## Quick start (Windows)

1. Install Python from [python.org](https://www.python.org/downloads/windows/). During installation, enable **Add Python to PATH** and make sure Tcl/Tk is included.
2. Download or clone this repository.
3. Open the `app` folder.
4. Double-click `Start_MINI_AI_LITE_X.bat`.
5. If Windows says Python cannot be found, open Command Prompt in the repository folder and run `py app\mini_ai_lite_x.py`.

### Set up the optional local language model

1. Ensure you have a reliable internet connection and enough free disk space.
2. Double-click `Setup_Local_AI.bat` inside the `app` folder, or run `py app\mini_ai_lite_x.py --setup-ai` from the repository folder.
3. Keep the setup window open while it works. The download may be several hundred megabytes or more.
4. If setup fails, you can still open the app without the model; check the error message and your CPU/runtime compatibility.

**Hardware note:** A Dell Latitude E6500 with 4 GB RAM is a constrained system. Local model inference may be very slow or fail if the downloaded runtime requires CPU features the machine does not support. This repository does not promise that every model/runtime will work on that hardware.

## Where data is stored

The app stores its database and settings under `%LOCALAPPDATA%\MiniAILiteX` on Windows. Research results and chat/knowledge data are local files on your computer. The app makes network requests when online research or the model setup is used. Review the Privacy section before using it with sensitive information.

## Repository layout

```text
MINI_AI_LITE_X/
├── README.md
├── CHANGELOG.md
├── CONTRIBUTING.md
├── LICENSE
├── PRIVACY.md
├── SECURITY.md
├── THIRD_PARTY_NOTICES.md
├── requirements.txt
├── .gitignore
└── app/
    ├── mini_ai_lite_x.py
    ├── Start_MINI_AI_LITE_X.bat
    ├── Setup_Local_AI.bat
    ├── MANUAL.txt
    ├── PRIVACY.txt
    ├── README.txt
    ├── LICENSE.txt
    └── THIRD_PARTY_NOTICES.txt
```

## Troubleshooting

- **`No module named tkinter` / Tcl/Tk error:** Reinstall Python from python.org and ensure Tcl/Tk is selected. Then test with `py -m tkinter`.
- **Python command not found:** Try `py app\mini_ai_lite_x.py`; reinstall Python with PATH enabled if necessary.
- **Local model setup fails:** Check internet access, free disk space, security software/network restrictions, and whether a compatible Windows `llama.cpp` build is available for your CPU.
- **Slow answers:** Older CPUs and 4 GB RAM can struggle with local language models. Close other programs and use a smaller compatible model if you configure one manually.
- **No internet:** The app can use knowledge saved previously, but online research and first-time model download will not work.

## Development and testing

The main source can be syntax-checked with:

```powershell
py -m py_compile app\mini_ai_lite_x.py
```

This is a source-code syntax check, not a full end-to-end test of GUI behavior, network research, or model inference. Those depend on the target Windows system and optional downloads.

## Publishing on GitHub

1. Create a repository named `MINI-AI-LITE-X` at <https://github.com/new>.
2. Upload the **contents** of this folder (not the outer ZIP file) to the repository.
3. Commit the files.
4. To publish a downloadable release, open **Releases → Create a new release**, use a tag such as `v1.0.3`, attach the portable ZIP you want users to download, and publish.

Do not commit private data, local databases, API keys, credentials, or personal research files.

## Disclaimer

This is a personal/community software project. It can make mistakes, and downloaded models or external websites have their own requirements and terms. Check generated information before relying on it. No guarantee is made that the app or optional model setup will work on every Windows PC.

## AutoLearn (v1.0.3)

AutoLearn can research a small number of accessible public webpages at startup and then on the configured schedule, even while Talk mode is selected. Use the **AutoLearn: ON/OFF** button to pause or resume it. Settings control the topic, interval, page count, per-page text limit, timeout, and total app storage cap. Duplicate URLs and identical page text are skipped. Saved text remains available offline, and Saved knowledge lets you inspect or delete it.

**What learning means:** AutoLearn grows a local, searchable knowledge library. It does not automatically train or alter the neural-network weights of a language model. A configured local model can use retrieved saved evidence in responses; without one, the built-in fallback is limited. It only attempts public URLs that are accessible without logging in and may be blocked by some sites. Research requires an internet connection; offline chat can still use material already saved.
