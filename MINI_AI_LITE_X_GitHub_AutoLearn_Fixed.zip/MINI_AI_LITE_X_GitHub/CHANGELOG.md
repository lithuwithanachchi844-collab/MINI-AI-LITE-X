# Changelog

## GitHub source package
- Packaged the current MINI AI LITE X Python source with Windows launch/setup scripts.
- Added setup instructions, privacy/security notes, and GitHub publishing guidance.
- Documented optional model/runtime requirements and constrained-hardware limitations.

The package version should be treated as a source-package revision rather than a guarantee that every optional AI feature has been end-to-end tested.

## v1.0.3 AutoLearn and reliability update
- Fixed AutoLearn being silently blocked whenever Talk mode was selected.
- Added an always-visible AutoLearn ON/OFF control; pausing stops the remaining automatic page queue after the current request.
- Automatic research now starts on launch when enabled, independently of chat mode, and follows the configured interval.
- Failed/offline startup attempts are throttled by the normal interval instead of retrying every minute.
- Storage display now reports total app-folder usage against the configured cap, rather than only the SQLite database file.
- Added regression tests for database initialization, saving/retrieving page text, duplicate detection, and storage-cap refusal.
- Clarified that internet learning stores searchable local knowledge; it does not retrain neural-network weights.
