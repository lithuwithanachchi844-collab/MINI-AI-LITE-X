# Privacy notes

MINI AI LITE X stores its settings and SQLite knowledge database locally under `%LOCALAPPDATA%\MiniAILiteX` on Windows.

The app can contact public websites when online research is enabled, and the optional first-run setup downloads a model/runtime from external hosting services. Those network requests disclose ordinary connection information to the services contacted. Saved research may contain text from the pages you choose to import.

- Do not import confidential information unless you understand where it will be stored and processed.
- Keep the local Windows account secure.
- Before sharing diagnostic logs or database files, inspect them for personal information.
- Disable automatic research in the app settings if you do not want it to run automatically.

This document describes intended behavior; it is not a formal security audit.
